<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

class NKG_Frontend {
	public static function init() {
		add_shortcode( 'nkg_game', array( __CLASS__, 'shortcode' ) );
		add_shortcode( 'nkg_player_profile', array( __CLASS__, 'profile_shortcode' ) );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'register_assets' ) );
	}


	public static function profile_shortcode() {
		wp_enqueue_style( 'nkg-games' );
		wp_enqueue_script( 'nkg-games' );
		ob_start();
		?>
		<div class="nkg-profile" data-nkg-profile>
			<div class="nkg-profile__empty"><?php esc_html_e( 'Start a game to create or load a player profile.', 'neo-kids-games' ); ?></div>
			<div class="nkg-profile__content" hidden>
				<h3 class="nkg-profile__name"></h3>
				<div class="nkg-profile__stats">
					<div><strong class="nkg-profile__level">1</strong><span><?php esc_html_e( 'Level', 'neo-kids-games' ); ?></span></div>
					<div><strong class="nkg-profile__xp">0</strong><span><?php esc_html_e( 'XP', 'neo-kids-games' ); ?></span></div>
					<div><strong class="nkg-profile__played">0</strong><span><?php esc_html_e( 'Games', 'neo-kids-games' ); ?></span></div>
					<div><strong class="nkg-profile__completed">0</strong><span><?php esc_html_e( 'Completed', 'neo-kids-games' ); ?></span></div>
				</div>
				<h4><?php esc_html_e( 'Recent Games', 'neo-kids-games' ); ?></h4>
				<div class="nkg-profile__recent"></div>
			</div>
		</div>
		<?php
		return ob_get_clean();
	}

	public static function register_assets() {
		wp_register_style( 'nkg-games', NKG_URL . 'assets/css/games.css', array(), NKG_VERSION );
		wp_register_script( 'nkg-games', NKG_URL . 'assets/js/games.js', array(), NKG_VERSION, true );
		wp_localize_script(
			'nkg-games',
			'NKG_DATA',
			array(
				'restUrl' => esc_url_raw( rest_url( 'nkg/v1/' ) ),
				'nonce' => wp_create_nonce( 'wp_rest' ),
			)
		);
	}

	public static function shortcode( $atts ) {
		$atts = shortcode_atts(
			array(
				'type' => 'memory',
				'difficulty' => 'easy',
				'theme' => 'default',
			),
			$atts,
			'nkg_game'
		);

		$type = sanitize_key( $atts['type'] );
		if ( ! NKG_Game_Registry::exists( $type ) ) {
			return '';
		}

		wp_enqueue_style( 'nkg-games' );
		wp_enqueue_script( 'nkg-games' );

		ob_start();
		?>
		<div class="nkg-game" data-game="<?php echo esc_attr( $type ); ?>" data-difficulty="<?php echo esc_attr( sanitize_key( $atts['difficulty'] ) ); ?>" data-theme="<?php echo esc_attr( sanitize_key( $atts['theme'] ) ); ?>">
			<div class="nkg-game__header">
				<strong class="nkg-game__title"><?php echo esc_html( NKG_Game_Registry::all()[ $type ]['name'] ); ?></strong>
				<span class="nkg-game__score" aria-live="polite">Score: 0</span>
			</div>
			<div class="nkg-player">
				<label for="nkg-player-name"><?php esc_html_e( 'Player name', 'neo-kids-games' ); ?></label>
				<div class="nkg-player__row">
					<input id="nkg-player-name" class="nkg-player__input" maxlength="100" type="text" autocomplete="nickname" />
					<button class="nkg-btn nkg-player__start" type="button"><?php esc_html_e( 'Start', 'neo-kids-games' ); ?></button>
				</div>
				<small class="nkg-player__message" aria-live="polite"></small>
			</div>
			<div class="nkg-board" hidden></div>
			<div class="nkg-result" hidden aria-live="polite"></div>
		</div>
		<?php
		return ob_get_clean();
	}
}
