<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

class NKG_Game_Registry {
	private static $games = array();

	public static function init() {
		self::$games = array(
			'memory' => array(
				'name' => __( 'Memory Match', 'neo-kids-games' ),
				'description' => __( 'Find matching pairs of cards.', 'neo-kids-games' ),
			),
			'quiz' => array(
				'name' => __( 'Quick Quiz', 'neo-kids-games' ),
				'description' => __( 'Answer a simple question by tapping the correct answer.', 'neo-kids-games' ),
			),
		);
		self::$games = apply_filters( 'nkg_registered_games', self::$games );
	}

	public static function all() {
		return self::$games;
	}

	public static function exists( $game ) {
		return isset( self::$games[ sanitize_key( $game ) ] );
	}
}
