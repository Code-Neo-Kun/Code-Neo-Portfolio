<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

class NKG_Database {
	public static function tables() {
		global $wpdb;
		$prefix = $wpdb->prefix . 'nkg_';
		return array(
			'players'      => $prefix . 'players',
			'sessions'     => $prefix . 'sessions',
			'achievements' => $prefix . 'achievements',
		);
	}

	public static function install() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$t = self::tables();
		$charset = $wpdb->get_charset_collate();

		$queries = array(
			"CREATE TABLE {$t['players']} (
				id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
				user_id bigint(20) unsigned NULL,
				identity_hash char(64) NOT NULL,
				nickname varchar(100) NOT NULL,
				avatar varchar(255) NULL,
				level int(10) unsigned NOT NULL DEFAULT 1,
				xp int(10) unsigned NOT NULL DEFAULT 0,
				created_at datetime NOT NULL,
				updated_at datetime NOT NULL,
				PRIMARY KEY (id),
				UNIQUE KEY identity_hash (identity_hash),
				KEY user_id (user_id),
				KEY nickname (nickname)
			) $charset;",
			"CREATE TABLE {$t['sessions']} (
				id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
				player_id bigint(20) unsigned NOT NULL,
				game_type varchar(50) NOT NULL,
				score int(11) NOT NULL DEFAULT 0,
				duration int(11) NOT NULL DEFAULT 0,
				completed tinyint(1) NOT NULL DEFAULT 0,
				metadata longtext NULL,
				created_at datetime NOT NULL,
				PRIMARY KEY (id),
				KEY player_id (player_id),
				KEY game_type (game_type),
				KEY created_at (created_at)
			) $charset;",
			"CREATE TABLE {$t['achievements']} (
				id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
				player_id bigint(20) unsigned NOT NULL,
				achievement_key varchar(100) NOT NULL,
				title varchar(150) NOT NULL,
				created_at datetime NOT NULL,
				PRIMARY KEY (id),
				UNIQUE KEY player_achievement (player_id, achievement_key),
				KEY player_id (player_id)
			) $charset;"
		);

		foreach ( $queries as $query ) {
			dbDelta( $query );
		}
		update_option( 'nkg_db_version', NKG_VERSION );
	}

	public static function maybe_upgrade() {
		$version = get_option( 'nkg_db_version', '0.0.0' );
		if ( version_compare( $version, NKG_VERSION, '<' ) ) {
			self::install();
		}
	}
}
