<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

class NKG_REST {
	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
	}

	public static function routes() {
		register_rest_route( 'nkg/v1', '/players', array(
			'methods' => WP_REST_Server::CREATABLE,
			'callback' => array( __CLASS__, 'create_player' ),
			'permission_callback' => '__return_true',
			'args' => array(
				'nickname' => array( 'required' => true, 'sanitize_callback' => 'sanitize_text_field' ),
				'identity' => array( 'required' => false, 'sanitize_callback' => 'sanitize_text_field' ),
			),
		) );

		register_rest_route( 'nkg/v1', '/players/(?P<id>\d+)', array(
			'methods' => WP_REST_Server::READABLE,
			'callback' => array( __CLASS__, 'get_player' ),
			'permission_callback' => '__return_true',
		) );

		register_rest_route( 'nkg/v1', '/sessions', array(
			'methods' => WP_REST_Server::CREATABLE,
			'callback' => array( __CLASS__, 'save_session' ),
			'permission_callback' => '__return_true',
		) );
	}

	public static function create_player( WP_REST_Request $request ) {
		$nickname = $request->get_param( 'nickname' );
		$identity = $request->get_param( 'identity' );

		if ( strlen( $nickname ) < 1 || strlen( $nickname ) > 100 ) {
			return new WP_Error( 'invalid_nickname', __( 'Please enter a valid player name.', 'neo-kids-games' ), array( 'status' => 400 ) );
		}

		$identity = $identity ? $identity : wp_generate_uuid4();
		if ( strlen( $identity ) > 100 ) {
			return new WP_Error( 'invalid_identity', __( 'Invalid player identity.', 'neo-kids-games' ), array( 'status' => 400 ) );
		}

		$id = NKG_Player::create( $nickname, $identity );
		if ( ! $id ) {
			return new WP_Error( 'player_create_failed', __( 'Could not create player.', 'neo-kids-games' ), array( 'status' => 500 ) );
		}

		return new WP_REST_Response(
			array(
				'id' => $id,
				'identity' => $identity,
				'player' => NKG_Player::get( $id ),
			),
			201
		);
	}

	public static function get_player( WP_REST_Request $request ) {
		$player = NKG_Player::get( absint( $request['id'] ) );
		if ( ! $player ) {
			return new WP_Error( 'player_not_found', __( 'Player not found.', 'neo-kids-games' ), array( 'status' => 404 ) );
		}

		return new WP_REST_Response(
			array(
				'player' => $player,
				'stats' => NKG_Player::stats( $player['id'] ),
				'recent' => NKG_Player::recent_sessions( $player['id'] ),
			),
			200
		);
	}

	public static function save_session( WP_REST_Request $request ) {
		$data = $request->get_json_params();
		$player_id = isset( $data['player_id'] ) ? absint( $data['player_id'] ) : 0;
		$game = isset( $data['game_type'] ) ? sanitize_key( $data['game_type'] ) : '';
		$score = isset( $data['score'] ) ? absint( $data['score'] ) : 0;
		$duration = isset( $data['duration'] ) ? absint( $data['duration'] ) : 0;
		$completed = ! empty( $data['completed'] );

		if ( ! $player_id || ! NKG_Game_Registry::exists( $game ) || ! NKG_Player::get( $player_id ) ) {
			return new WP_Error( 'invalid_session', __( 'Invalid game session.', 'neo-kids-games' ), array( 'status' => 400 ) );
		}

		NKG_Player::record_session( $player_id, $game, $score, $duration, $completed );

		if ( $completed ) {
			NKG_Player::achievement( $player_id, 'first-completion-' . $game, 'Game Completed' );
		}

		return new WP_REST_Response( array( 'success' => true ), 201 );
	}
}
