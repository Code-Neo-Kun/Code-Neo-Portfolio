<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

class NKG_Admin {
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_init', array( __CLASS__, 'settings' ) );
	}

	public static function menu() {
		add_menu_page(
			__( 'Kids Games', 'neo-kids-games' ),
			__( 'Kids Games', 'neo-kids-games' ),
			'manage_options',
			'nkg-dashboard',
			array( __CLASS__, 'dashboard' ),
			'dashicons-games',
			25
		);
		add_submenu_page( 'nkg-dashboard', __( 'Game Library', 'neo-kids-games' ), __( 'Game Library', 'neo-kids-games' ), 'manage_options', 'nkg-library', array( __CLASS__, 'library' ) );
		add_submenu_page( 'nkg-dashboard', __( 'Settings', 'neo-kids-games' ), __( 'Settings', 'neo-kids-games' ), 'manage_options', 'nkg-settings', array( __CLASS__, 'settings_page' ) );
	}

	public static function settings() {
		register_setting( 'nkg_settings', 'nkg_settings', array(
			'type' => 'array',
			'sanitize_callback' => function( $value ) {
				return array(
					'sound' => ! empty( $value['sound'] ) ? 1 : 0,
					'default_difficulty' => isset( $value['default_difficulty'] ) ? sanitize_key( $value['default_difficulty'] ) : 'easy',
				);
			},
			'default' => array( 'sound' => 1, 'default_difficulty' => 'easy' ),
		) );
	}

	public static function dashboard() {
		global $wpdb;
		$t = NKG_Database::tables();
		$players = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$t['players']}" );
		$sessions = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$t['sessions']}" );
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Kids Games', 'neo-kids-games' ); ?></h1>
			<p><?php esc_html_e( 'A lightweight interactive game engine for children.', 'neo-kids-games' ); ?></p>
			<p><strong><?php echo esc_html( $players ); ?></strong> <?php esc_html_e( 'players', 'neo-kids-games' ); ?> &nbsp; <strong><?php echo esc_html( $sessions ); ?></strong> <?php esc_html_e( 'game sessions', 'neo-kids-games' ); ?></p>
			<h2><?php esc_html_e( 'Available embeds', 'neo-kids-games' ); ?></h2>
			<code>[nkg_game type="memory"]</code>
			<p><?php esc_html_e( 'Use the Gutenberg block or Elementor widget for visual configuration.', 'neo-kids-games' ); ?></p>
		</div>
		<?php
	}

	public static function library() {
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Game Library', 'neo-kids-games' ); ?></h1>
			<table class="widefat striped">
				<thead><tr><th><?php esc_html_e( 'Game', 'neo-kids-games' ); ?></th><th><?php esc_html_e( 'Description', 'neo-kids-games' ); ?></th><th><?php esc_html_e( 'Shortcode', 'neo-kids-games' ); ?></th></tr></thead>
				<tbody>
				<?php foreach ( NKG_Game_Registry::all() as $key => $game ) : ?>
					<tr>
						<td><?php echo esc_html( $game['name'] ); ?></td>
						<td><?php echo esc_html( $game['description'] ); ?></td>
						<td><code>[nkg_game type="<?php echo esc_attr( $key ); ?>"]</code></td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
		</div>
		<?php
	}

	public static function settings_page() {
		$options = get_option( 'nkg_settings', array( 'sound' => 1, 'default_difficulty' => 'easy' ) );
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Kids Games Settings', 'neo-kids-games' ); ?></h1>
			<form method="post" action="options.php">
				<?php settings_fields( 'nkg_settings' ); ?>
				<table class="form-table">
					<tr>
						<th scope="row"><?php esc_html_e( 'Sound effects', 'neo-kids-games' ); ?></th>
						<td><label><input type="checkbox" name="nkg_settings[sound]" value="1" <?php checked( ! empty( $options['sound'] ) ); ?> /> <?php esc_html_e( 'Enable game sound effects', 'neo-kids-games' ); ?></label></td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'Default difficulty', 'neo-kids-games' ); ?></th>
						<td>
							<select name="nkg_settings[default_difficulty]">
								<option value="easy" <?php selected( $options['default_difficulty'] ?? 'easy', 'easy' ); ?>><?php esc_html_e( 'Easy', 'neo-kids-games' ); ?></option>
								<option value="medium" <?php selected( $options['default_difficulty'] ?? '', 'medium' ); ?>><?php esc_html_e( 'Medium', 'neo-kids-games' ); ?></option>
								<option value="hard" <?php selected( $options['default_difficulty'] ?? '', 'hard' ); ?>><?php esc_html_e( 'Hard', 'neo-kids-games' ); ?></option>
							</select>
						</td>
					</tr>
				</table>
				<?php submit_button(); ?>
			</form>
		</div>
		<?php
	}
}
