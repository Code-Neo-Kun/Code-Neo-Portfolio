<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

class NKG_Player {
	public static function init() {
		add_action( 'init', array( __CLASS__, 'upgrade' ) );
	}

	public static function upgrade() {
		if ( is_admin() && ! current_user_can( 'manage_options' ) ) {
			return;
		}
		NKG_Database::maybe_upgrade();
	}

	private static function hash_identity( $identity ) {
		return hash_hmac( 'sha256', (string) $identity, wp_salt( 'auth' ) );
	}

	public static function create( $nickname, $identity = '' ) {
		global $wpdb;
		$t = NKG_Database::tables();
		$nickname = sanitize_text_field( $nickname );

		if ( '' === $nickname || strlen( $nickname ) > 100 ) {
			return 0;
		}

		$identity = $identity ? sanitize_text_field( $identity ) : wp_generate_uuid4();
		$hash = self::hash_identity( $identity );

		$existing = $wpdb->get_var(
			$wpdb->prepare( "SELECT id FROM {$t['players']} WHERE identity_hash = %s", $hash )
		);

		if ( $existing ) {
			$wpdb->update(
				$t['players'],
				array( 'nickname' => $nickname, 'updated_at' => current_time( 'mysql' ) ),
				array( 'id' => absint( $existing ) ),
				array( '%s', '%s' ),
				array( '%d' )
			);
			return (int) $existing;
		}

		$now = current_time( 'mysql' );
		$wpdb->insert(
			$t['players'],
			array(
				'user_id' => get_current_user_id() ? absint( get_current_user_id() ) : null,
				'identity_hash' => $hash,
				'nickname' => $nickname,
				'avatar' => '',
				'level' => 1,
				'xp' => 0,
				'created_at' => $now,
				'updated_at' => $now,
			),
			array( '%d', '%s', '%s', '%s', '%d', '%d', '%s', '%s' )
		);
		return (int) $wpdb->insert_id;
	}

	public static function get( $id ) {
		global $wpdb;
		$t = NKG_Database::tables();
		return $wpdb->get_row(
			$wpdb->prepare( "SELECT id, user_id, nickname, avatar, level, xp, created_at, updated_at FROM {$t['players']} WHERE id = %d", absint( $id ) ),
			ARRAY_A
		);
	}

	public static function find_by_identity( $identity ) {
		global $wpdb;
		$t = NKG_Database::tables();
		$hash = self::hash_identity( $identity );
		$id = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$t['players']} WHERE identity_hash = %s", $hash ) );
		return $id ? self::get( $id ) : null;
	}

	public static function record_session( $player_id, $game_type, $score, $duration, $completed, $metadata = array() ) {
		global $wpdb;
		$t = NKG_Database::tables();
		$ok = $wpdb->insert(
			$t['sessions'],
			array(
				'player_id' => absint( $player_id ),
				'game_type' => sanitize_key( $game_type ),
				'score' => absint( $score ),
				'duration' => absint( $duration ),
				'completed' => $completed ? 1 : 0,
				'metadata' => wp_json_encode( is_array( $metadata ) ? $metadata : array() ),
				'created_at' => current_time( 'mysql' ),
			),
			array( '%d', '%s', '%d', '%d', '%d', '%s', '%s' )
		);

		if ( $ok && $completed ) {
			self::add_xp( $player_id, min( 100, max( 5, absint( $score ) ) ) );
		}
		return $ok;
	}

	public static function add_xp( $player_id, $amount ) {
		global $wpdb;
		$t = NKG_Database::tables();
		$player = self::get( $player_id );
		if ( ! $player ) {
			return false;
		}

		$xp = absint( $player['xp'] ) + absint( $amount );
		$level = max( 1, floor( $xp / 100 ) + 1 );

		return false !== $wpdb->update(
			$t['players'],
			array( 'xp' => $xp, 'level' => $level, 'updated_at' => current_time( 'mysql' ) ),
			array( 'id' => absint( $player_id ) ),
			array( '%d', '%d', '%s' ),
			array( '%d' )
		);
	}

	public static function stats( $player_id ) {
		global $wpdb;
		$t = NKG_Database::tables();
		$row = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT COUNT(*) games_played,
				COALESCE(SUM(score),0) total_score,
				COALESCE(SUM(completed),0) completed_games
				FROM {$t['sessions']} WHERE player_id = %d",
				absint( $player_id )
			),
			ARRAY_A
		);
		return $row ? $row : array( 'games_played' => 0, 'total_score' => 0, 'completed_games' => 0 );
	}

	public static function recent_sessions( $player_id, $limit = 10 ) {
		global $wpdb;
		$t = NKG_Database::tables();
		$limit = min( 20, max( 1, absint( $limit ) ) );
		return $wpdb->get_results(
			$wpdb->prepare(
				"SELECT game_type, score, duration, completed, created_at
				FROM {$t['sessions']} WHERE player_id = %d
				ORDER BY id DESC LIMIT %d",
				absint( $player_id ),
				$limit
			),
			ARRAY_A
		);
	}

	public static function achievement( $player_id, $key, $title ) {
		global $wpdb;
		$t = NKG_Database::tables();
		return $wpdb->query(
			$wpdb->prepare(
				"INSERT IGNORE INTO {$t['achievements']} (player_id, achievement_key, title, created_at)
				VALUES (%d, %s, %s, %s)",
				absint( $player_id ),
				sanitize_key( $key ),
				sanitize_text_field( $title ),
				current_time( 'mysql' )
			)
		);
	}
}
