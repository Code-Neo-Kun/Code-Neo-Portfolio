(function () {
	'use strict';

	const state = {
		playerId: Number(localStorage.getItem('nkg_player_id') || 0),
		identity: localStorage.getItem('nkg_identity') || '',
		score: 0,
		startedAt: 0
	};

	function postSession(gameType, completed) {
		if (!state.playerId) return;
		fetch(NKG_DATA.restUrl + 'sessions', {
			method: 'POST',
			headers: {
				'Content-Type': 'application/json',
				'X-WP-Nonce': NKG_DATA.nonce
			},
			body: JSON.stringify({
				player_id: state.playerId,
				game_type: gameType,
				score: state.score,
				duration: Math.max(0, Math.round((Date.now() - state.startedAt) / 1000)),
				completed: completed
			})
		}).catch(function () {});
	}

	function createPlayer(nickname) {
		return fetch(NKG_DATA.restUrl + 'players', {
			method: 'POST',
			headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': NKG_DATA.nonce },
			body: JSON.stringify({ nickname: nickname, identity: state.identity })
		}).then(function (r) {
			if (!r.ok) throw new Error('Could not create player');
			return r.json();
		});
	}

	function renderMemory(root) {
		const board = root.querySelector('.nkg-board');
		const result = root.querySelector('.nkg-result');
		const difficulty = root.dataset.difficulty;
		const pairs = difficulty === 'hard' ? 8 : (difficulty === 'medium' ? 6 : 4);
		const icons = ['🐶','🐱','🐸','🦁','🐼','🐵','🐰','🦊'];
		const deck = icons.slice(0, pairs).concat(icons.slice(0, pairs)).sort(function () { return Math.random() - 0.5; });
		let first = null, lock = false, matched = 0;
		state.score = 0;
		board.innerHTML = '';
		board.hidden = false;
		result.hidden = true;

		deck.forEach(function (icon, index) {
			const button = document.createElement('button');
			button.type = 'button';
			button.className = 'nkg-card';
			button.setAttribute('aria-label', 'Hidden card');
			button.dataset.icon = icon;
			button.dataset.index = index;
			button.textContent = '?';
			button.addEventListener('click', function () {
				if (lock || button.classList.contains('is-open') || button.classList.contains('is-match')) return;
				button.classList.add('is-open');
				button.textContent = icon;
				if (!first) { first = button; return; }
				if (first.dataset.icon === button.dataset.icon) {
					first.classList.add('is-match');
					button.classList.add('is-match');
					matched += 2;
					state.score += 10;
					updateScore(root);
					first = null;
					if (matched === deck.length) {
						result.textContent = '🎉 Great job! You matched them all!';
						result.hidden = false;
						postSession('memory', true);
					}
				} else {
					lock = true;
					state.score = Math.max(0, state.score - 1);
					updateScore(root);
					setTimeout(function () {
						first.classList.remove('is-open');
						button.classList.remove('is-open');
						first.textContent = '?';
						button.textContent = '?';
						first = null;
						lock = false;
					}, 700);
				}
			});
			board.appendChild(button);
		});
	}

	function renderQuiz(root) {
		const board = root.querySelector('.nkg-board');
		const result = root.querySelector('.nkg-result');
		const questions = [
			{ q: 'Which animal says “meow”?', a: ['🐶 Dog','🐱 Cat','🐮 Cow'], correct: 1 },
			{ q: 'Which one is a fruit?', a: ['🚗 Car','🍎 Apple','🏠 House'], correct: 1 },
			{ q: 'What color is the sun usually drawn as?', a: ['☀️ Yellow','🌊 Blue','🍃 Green'], correct: 0 }
		];
		let current = 0;
		state.score = 0;
		board.hidden = false;
		result.hidden = true;

		function question() {
			const item = questions[current];
			board.innerHTML = '<div class="nkg-question">' + item.q + '</div>';
			item.a.forEach(function (answer, i) {
				const b = document.createElement('button');
				b.type = 'button';
				b.className = 'nkg-answer';
				b.textContent = answer;
				b.addEventListener('click', function () {
					if (i === item.correct) state.score += 10;
					updateScore(root);
					current++;
					if (current >= questions.length) {
						result.textContent = '🎉 Quiz complete! Your score is ' + state.score + '.';
						result.hidden = false;
						board.innerHTML = '';
						postSession('quiz', true);
					} else {
						question();
					}
				});
				board.appendChild(b);
			});
		}
		question();
	}

	function updateScore(root) {
		root.querySelector('.nkg-game__score').textContent = 'Score: ' + state.score;
	}

	function init(root) {
		const start = root.querySelector('.nkg-player__start');
		const input = root.querySelector('.nkg-player__input');
		const message = root.querySelector('.nkg-player__message');

		start.addEventListener('click', function () {
			const nickname = input.value.trim();
			if (!nickname) {
				message.textContent = 'Please enter a player name.';
				return;
			}
			start.disabled = true;
			message.textContent = 'Starting…';
			createPlayer(nickname).then(function (data) {
				state.playerId = Number(data.id);
				state.identity = data.identity || state.identity;
				localStorage.setItem('nkg_player_id', String(state.playerId));
				localStorage.setItem('nkg_identity', state.identity);
				state.startedAt = Date.now();
				root.querySelector('.nkg-player').hidden = true;
				message.textContent = '';
				if (root.dataset.game === 'quiz') renderQuiz(root);
				else renderMemory(root);
			}).catch(function () {
				start.disabled = false;
				message.textContent = 'Something went wrong. Please try again.';
			});
		});
	}

	document.addEventListener('DOMContentLoaded', function () {
		document.querySelectorAll('.nkg-game').forEach(init);
	});
})();

	function loadProfile(root) {
		if (!state.playerId) return;
		fetch(NKG_DATA.restUrl + 'players/' + state.playerId, {
			headers: { 'X-WP-Nonce': NKG_DATA.nonce }
		}).then(function (r) {
			if (!r.ok) throw new Error('profile');
			return r.json();
		}).then(function (data) {
			root.querySelector('.nkg-profile__empty').hidden = true;
			root.querySelector('.nkg-profile__content').hidden = false;
			root.querySelector('.nkg-profile__name').textContent = data.player.nickname;
			root.querySelector('.nkg-profile__level').textContent = data.player.level;
			root.querySelector('.nkg-profile__xp').textContent = data.player.xp;
			root.querySelector('.nkg-profile__played').textContent = data.stats.games_played;
			root.querySelector('.nkg-profile__completed').textContent = data.stats.completed_games;
			const recent = root.querySelector('.nkg-profile__recent');
			recent.innerHTML = '';
			(data.recent || []).forEach(function (item) {
				const row = document.createElement('div');
				row.className = 'nkg-profile__row';
				row.textContent = item.game_type + ' — ' + item.score + ' points';
				recent.appendChild(row);
			});
		}).catch(function () {});
	}

	document.addEventListener('DOMContentLoaded', function () {
		document.querySelectorAll('[data-nkg-profile]').forEach(loadProfile);
	});
