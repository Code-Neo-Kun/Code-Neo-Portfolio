<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

class NKG_Elementor {
	public static function init() {
		add_action( 'elementor/widgets/register', array( __CLASS__, 'register' ) );
	}

	public static function register( $widgets_manager ) {
		if ( ! class_exists( '\Elementor\Widget_Base' ) ) {
			return;
		}
		$widgets_manager->register( new NKG_Elementor_Widget() );
	}
}

class NKG_Elementor_Widget extends \Elementor\Widget_Base {
	public function get_name() { return 'nkg_game'; }
	public function get_title() { return esc_html__( 'Kids Game', 'neo-kids-games' ); }
	public function get_icon() { return 'eicon-game-controller'; }
	public function get_categories() { return array( 'general' ); }

	protected function register_controls() {
		$this->start_controls_section( 'game', array( 'label' => esc_html__( 'Game', 'neo-kids-games' ) ) );
		$this->add_control( 'type', array(
			'label' => esc_html__( 'Game', 'neo-kids-games' ),
			'type' => \Elementor\Controls_Manager::SELECT,
			'default' => 'memory',
			'options' => array( 'memory' => esc_html__( 'Memory Match', 'neo-kids-games' ), 'quiz' => esc_html__( 'Quick Quiz', 'neo-kids-games' ) ),
		) );
		$this->add_control( 'difficulty', array(
			'label' => esc_html__( 'Difficulty', 'neo-kids-games' ),
			'type' => \Elementor\Controls_Manager::SELECT,
			'default' => 'easy',
			'options' => array( 'easy' => esc_html__( 'Easy', 'neo-kids-games' ), 'medium' => esc_html__( 'Medium', 'neo-kids-games' ), 'hard' => esc_html__( 'Hard', 'neo-kids-games' ) ),
		) );
		$this->end_controls_section();
	}

	protected function render() {
		$s = $this->get_settings_for_display();
		echo NKG_Frontend::shortcode( array( 'type' => $s['type'], 'difficulty' => $s['difficulty'] ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}
}
