<?php
/**
 * Plugin Name: Neo Kids Interactive Games
 * Plugin URI: https://code-neo-portfolio.vercel.app/
 * Description: Lightweight interactive mini-games for children with player profiles, progress tracking, Gutenberg, Elementor, and shortcode support.
 * Version: 0.2.0
 * Author: Neo
 * Author URI: https://code-neo-portfolio.vercel.app/
 * License: GPL-2.0-or-later
 * Text Domain: neo-kids-games
 * Requires at least: 6.3
 * Requires PHP: 8.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'NKG_VERSION', '0.2.0' );
define( 'NKG_FILE', __FILE__ );
define( 'NKG_PATH', plugin_dir_path( __FILE__ ) );
define( 'NKG_URL', plugin_dir_url( __FILE__ ) );

require_once NKG_PATH . 'includes/class-database.php';
require_once NKG_PATH . 'includes/class-game-registry.php';
require_once NKG_PATH . 'includes/class-player.php';
require_once NKG_PATH . 'includes/class-frontend.php';
require_once NKG_PATH . 'includes/class-admin.php';
require_once NKG_PATH . 'includes/class-rest.php';

if ( did_action( 'elementor/loaded' ) ) {
	require_once NKG_PATH . 'integrations/class-elementor.php';
}

function nkg_activate() {
	NKG_Database::install();
}
register_activation_hook( __FILE__, 'nkg_activate' );

function nkg_init() {
	NKG_Game_Registry::init();
	NKG_Player::init();
	NKG_Frontend::init();
	NKG_REST::init();
	NKG_Admin::init();

	if ( did_action( 'elementor/loaded' ) ) {
		NKG_Elementor::init();
	}
}
add_action( 'plugins_loaded', 'nkg_init' );
