=== Neo Kids Interactive Games ===
Contributors: neo
Tags: kids, games, education, children, interactive, gutenberg, elementor
Requires at least: 6.3
Tested up to: 6.9
Requires PHP: 8.0
Stable tag: 0.2.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Lightweight interactive mini-games for children with custom database storage, player profiles, Gutenberg, Elementor, and shortcode support.

== Description ==

Neo Kids Interactive Games provides small browser-based games for children. The initial release includes Memory Match and Quick Quiz.

Player profiles, game sessions, and achievements are stored in dedicated custom database tables. The plugin does not use custom post types for game/player storage.

== Features ==

* Memory Match game.
* Quick Quiz game.
* Persistent individual player records using a site-local identity token.
* Player profile shortcode with level, XP, and recent games.
* Game session and score tracking.
* Basic achievement recording.
* Gutenberg block.
* Elementor widget when Elementor is active.
* Shortcode support.
* Admin dashboard and settings.
* Scoped frontend assets.
* GPL-2.0-or-later.

== Shortcode ==

[nkg_game type="memory"]

[nkg_game type="quiz" difficulty="medium"]

[nkg_player_profile]

== Installation ==

1. Upload the plugin ZIP through Plugins > Add New > Upload Plugin.
2. Activate the plugin.
3. Open Kids Games in wp-admin.
4. Add a game with the Gutenberg block, Elementor widget, or shortcode.

== Privacy ==

The plugin stores player nickname, game sessions, scores, and achievement records in custom database tables. Site owners are responsible for providing any required privacy notices and obtaining any required consent for collecting children's data.

== Changelog ==

= 0.2.0 =
* Added persistent player identity and profile statistics.
* Added XP/level progression foundation.
* Added player profile shortcode.

= 0.1.0 =
* Initial MVP release.
