# Neo Kids Interactive Games — Architecture

## Layers

- Game Engine: `NKG_Game_Interface`, `NKG_Game_Registry`, `NKG_Game_Session`
- Player System: `NKG_Player`
- Reward System: `NKG_Reward`
- Content System: `NKG_Content`
- Rendering: shortcode + Gutenberg + Elementor
- Transport: WordPress REST API
- Persistence: custom `wp_nkg_*` tables

## Adding a game

1. Create a class implementing `NKG_Game_Interface`.
2. Register it in `NKG_Game_Registry::init()`.
3. Add its frontend renderer/JS.
4. Add its configuration/content rules.
5. Do not place shared player/scoring/database logic inside the game class.

## Data principle

Game logic is code. Questions, categories, difficulty and other editable game content are data stored in custom tables.

## Content Builder v1.2

The Content Builder is an admin-side data editor, not a new WordPress post type. Game content remains in `wp_nkg_content`.

Each item has:
- game key
- title
- question payload
- answer array
- correct-answer index
- difficulty
- category
- draft/published status
- display order
- optional image URL
- timestamps

The admin editor uses WordPress nonce protection, capability checks, sanitization, escaping, and the native Media Library. The game engine remains responsible for runtime behavior; editable content remains data.
