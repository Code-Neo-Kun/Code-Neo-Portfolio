<?php
/**
 * Stores API definitions.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class WP_API_Builder_API_Registry {

	private const OPTION = 'wp_api_builder_apis';

	public function all(): array {
		$apis = get_option( self::OPTION, array() );
		return is_array( $apis ) ? $apis : array();
	}

	public function get( string $id ): ?array {
		$apis = $this->all();

		return isset( $apis[ $id ] ) && is_array( $apis[ $id ] ) ? $apis[ $id ] : null;
	}

	public function save( array $api ): string {
		$apis = $this->all();

		$id = sanitize_key( $api['id'] ?? '' );
		if ( '' === $id ) {
			$id = wp_generate_uuid4();
			$id = sanitize_key( str_replace( '-', '', $id ) );
		}

		$api['id']         = $id;
		$api['updated_at'] = current_time( 'mysql' );
		$apis[ $id ]       = $api;

		update_option( self::OPTION, $apis, false );

		return $id;
	}

	public function delete( string $id ): bool {
		$apis = $this->all();

		if ( ! isset( $apis[ $id ] ) ) {
			return false;
		}

		unset( $apis[ $id ] );
		update_option( self::OPTION, $apis, false );

		return true;
	}
}
