<?php
/**
 * Plugin Name: Neo Kids Interactive Games
 * Plugin URI: https://code-neo-portfolio.vercel.app/
 * Description: A lightweight, extensible game engine for children's mini-games with custom player profiles, progress, rewards, Gutenberg, Elementor, and shortcode support.
 * Version: 1.6.0
 * Author: Neo
 * Author URI: https://code-neo-portfolio.vercel.app/
 * License: GPL-2.0-or-later
 * Text Domain: neo-kids-games
 * Requires at least: 6.3
 * Requires PHP: 8.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'NKG_VERSION', '1.6.0' );
define( 'NKG_FILE', __FILE__ );
define( 'NKG_PATH', plugin_dir_path( __FILE__ ) );
define( 'NKG_URL', plugin_dir_url( __FILE__ ) );

require_once NKG_PATH . 'includes/class-database.php';
require_once NKG_PATH . 'includes/interface-game.php';
require_once NKG_PATH . 'includes/class-game-registry.php';
require_once NKG_PATH . 'includes/class-game-session.php';
require_once NKG_PATH . 'includes/class-content.php';
require_once NKG_PATH . 'includes/class-institution.php';
require_once NKG_PATH . 'includes/class-teacher.php';
require_once NKG_PATH . 'includes/class-assignment.php';
require_once NKG_PATH . 'includes/class-player.php';
require_once NKG_PATH . 'includes/class-reward.php';
require_once NKG_PATH . 'includes/games/class-memory-game.php';
require_once NKG_PATH . 'includes/games/class-quiz-game.php';
require_once NKG_PATH . 'includes/class-rest.php';
require_once NKG_PATH . 'includes/class-frontend.php';
require_once NKG_PATH . 'includes/class-admin.php';
require_once NKG_PATH . 'includes/class-privacy.php';
require_once NKG_PATH . 'integrations/class-elementor.php';
require_once NKG_PATH . 'integrations/class-gutenberg.php';

register_activation_hook( __FILE__, array( 'NKG_Database', 'install' ) );
register_deactivation_hook( __FILE__, array( 'NKG_Database', 'deactivate' ) );

function nkg_bootstrap() {
	NKG_Database::maybe_upgrade();
	NKG_Institution::init();
	NKG_Game_Registry::init();
	NKG_Game_Session::init();
	NKG_Player::init();
	NKG_Reward::init();
	NKG_REST::init();
	NKG_Frontend::init();
	NKG_Admin::init();
	NKG_Privacy::init();
	NKG_Elementor::init();
	NKG_Gutenberg::init();
}
add_action( 'plugins_loaded', 'nkg_bootstrap' );
