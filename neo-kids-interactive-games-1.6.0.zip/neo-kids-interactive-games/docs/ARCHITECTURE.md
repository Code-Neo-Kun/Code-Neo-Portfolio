# Neo Kids Interactive Games — Engine Architecture

## v1.6.0

The plugin separates the institutional platform from browser-side gameplay.

```text
INSTITUTION PLATFORM
 Institution → Classes → Students → Assignments → Reports
        ↓
GAME APPLICATIONS
 Memory Match │ Quiz │ Future Games
        ↓
NKG GAME ENGINE
 Scenes │ Entities │ Components │ Systems │ Input │ Assets │ Audio │ Renderer
        ↓
ENGINE CORE
 Game Loop │ State │ Events │ Scene Manager │ Entity Manager │ System Manager
        ↓
WORDPRESS PLATFORM
 REST API │ Authentication │ Custom DB │ Admin │ Permissions
        ↓
BROWSER RUNTIME
 Canvas │ WebGL/WebGPU-ready │ Web Audio │ DOM │ Pointer/Keyboard APIs
```

## Engine responsibilities

### GameEngine
Owns the runtime lifecycle and exposes the public engine API:

- `registerScene()`
- `changeScene()`
- `addSystem()`
- `createEntity()`
- `start()`
- `stop()`
- `finish()`
- `destroy()`

### Scenes
A scene has:

- `enter(data)`
- `update(delta)`
- `render()`
- `exit()`

Game modules can register their own scene instead of hard-coding gameplay into the WordPress shortcode.

### Entities and components

Entities are plain runtime objects. Components are data-only objects:

```text
Entity
 ├─ transform
 ├─ sprite
 ├─ physics
 ├─ input
 └─ game-specific data
```

The entity manager supports creation, component mutation, queries, and cleanup.

### Systems

Systems are reusable engine services with optional:

- `init(engine)`
- `update(delta)`
- `render()`
- `destroy()`

The system manager provides deterministic registration and lifecycle handling.

### Renderer

v1.6 introduces a responsive Canvas renderer with:

- device-pixel-ratio scaling
- rectangle primitives
- rounded rectangles
- text rendering
- responsive resize
- pointer-friendly canvas sizing

The renderer is intentionally small so future WebGL/WebGPU render backends can replace it without changing game rules.

### Input

Pointer coordinates are normalized to Canvas coordinates. Keyboard input is exposed through `isDown()` and input events.

### Collision

`NKGCollision` provides reusable AABB rectangle intersection and point containment utilities.

## First engine-native game

Memory Match is now rendered directly by the engine:

- cards are entities
- card positions are transform components
- card state is a memory component
- pointer input is handled through the engine event bus
- Canvas renderer draws the complete board
- the game emits `game:finished`
- WordPress REST remains responsible for final server-side scoring

Quick Quiz remains a DOM-oriented application while the engine API stabilizes. It still uses the same `GameApplication` and scene lifecycle.

## WordPress boundary

PHP owns:

- institutions
- classes
- students
- teachers
- assignments
- sessions
- progress
- XP
- achievements
- permissions
- REST endpoints

JavaScript owns:

- game loop
- scenes
- entities
- game state
- rendering
- input
- animation/runtime behavior

Never move authoritative scoring or institution authorization into the browser.

## Extension pattern

A future game should follow:

```js
function MyGame(engine, options) {
    NKGGameApplication.call(this, engine, options);

    // register scene
    // create entities
    // subscribe to input/events
}

MyGame.prototype.start = function () {
    // initialize game state/entities
};

window.NKG_GAME_MODULES.register('my-game', function (engine, options) {
    return new MyGame(engine, options);
});
```

This keeps each game independent from WordPress page rendering while sharing one runtime.
