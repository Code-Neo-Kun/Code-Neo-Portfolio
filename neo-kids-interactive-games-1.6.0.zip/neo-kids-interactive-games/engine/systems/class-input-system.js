(function (window) {
	'use strict';

	function InputSystem(engine) {
		this.engine = engine;
		this.keys = {};
		this.pointer = { x: 0, y: 0, down: false };
		this.canvas = null;
		this.bound = false;
	}

	InputSystem.prototype.init = function () {
		this.bindKeyboard();
		this.bindCanvas();
	};

	InputSystem.prototype.bindKeyboard = function () {
		var self = this;
		if (this.keyboardBound) {
			return;
		}
		this.keyboardBound = true;

		window.addEventListener('keydown', function (event) {
			self.keys[event.key.toLowerCase()] = true;
			self.engine.events.emit('input:key', { key: event.key, type: 'down', originalEvent: event });
		});

		window.addEventListener('keyup', function (event) {
			self.keys[event.key.toLowerCase()] = false;
			self.engine.events.emit('input:key', { key: event.key, type: 'up', originalEvent: event });
		});
	};

	InputSystem.prototype.bindCanvas = function () {
		var self = this;
		this.canvas = this.engine.renderer ? this.engine.renderer.canvas : null;
		if (!this.canvas || this.bound) {
			return;
		}
		this.bound = true;

		function point(event) {
			var rect = self.canvas.getBoundingClientRect();
			var scaleX = self.canvas.width / Math.max(1, rect.width);
			var scaleY = self.canvas.height / Math.max(1, rect.height);
			return {
				x: (event.clientX - rect.left) * scaleX,
				y: (event.clientY - rect.top) * scaleY
			};
		}

		this.canvas.addEventListener('pointerdown', function (event) {
			var p = point(event);
			self.pointer = { x: p.x, y: p.y, down: true };
			self.engine.events.emit('input:pointer', { type: 'down', x: p.x, y: p.y, originalEvent: event });
		});

		this.canvas.addEventListener('pointerup', function (event) {
			var p = point(event);
			self.pointer = { x: p.x, y: p.y, down: false };
			self.engine.events.emit('input:pointer', { type: 'up', x: p.x, y: p.y, originalEvent: event });
		});

		this.canvas.addEventListener('pointercancel', function (event) {
			var p = point(event);
			self.pointer = { x: p.x, y: p.y, down: false };
			self.engine.events.emit('input:pointer', { type: 'cancel', x: p.x, y: p.y, originalEvent: event });
		});
	};

	InputSystem.prototype.isDown = function (key) {
		return !!this.keys[String(key).toLowerCase()];
	};

	InputSystem.prototype.destroy = function () {
		this.keys = {};
		this.pointer.down = false;
	};

	window.NKGInputSystem = InputSystem;
}(window));
