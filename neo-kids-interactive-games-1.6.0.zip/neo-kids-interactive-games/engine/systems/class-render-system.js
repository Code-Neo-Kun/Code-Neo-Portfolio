(function (window) {
	'use strict';

	function RenderSystem(engine, container) {
		this.engine = engine;
		this.container = container;
		this.canvas = document.createElement('canvas');
		this.canvas.className = 'nkg-engine-canvas';
		this.context = this.canvas.getContext('2d');
		this.dpr = Math.max(1, Math.min(2, window.devicePixelRatio || 1));
		this.width = 0;
		this.height = 0;
		this.resizeHandler = this.resize.bind(this);
		this.container.appendChild(this.canvas);
		this.resize();
		window.addEventListener('resize', this.resizeHandler);
	}

	RenderSystem.prototype.resize = function () {
		var width = Math.max(320, this.container.clientWidth || 800);
		var height = Math.max(300, this.container.clientHeight || Math.round(width * 0.72));
		this.width = width;
		this.height = height;
		this.canvas.style.width = width + 'px';
		this.canvas.style.height = height + 'px';
		this.canvas.width = Math.round(width * this.dpr);
		this.canvas.height = Math.round(height * this.dpr);
		this.context.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
	};

	RenderSystem.prototype.clear = function () {
		this.context.clearRect(0, 0, this.width, this.height);
	};

	RenderSystem.prototype.rect = function (x, y, width, height, fill, radius) {
		var ctx = this.context;
		var r = Math.max(0, Math.min(radius || 0, width / 2, height / 2));
		ctx.beginPath();
		if (r) {
			ctx.moveTo(x + r, y);
			ctx.arcTo(x + width, y, x + width, y + height, r);
			ctx.arcTo(x + width, y + height, x, y + height, r);
			ctx.arcTo(x, y + height, x, y, r);
			ctx.arcTo(x, y, x + width, y, r);
		} else {
			ctx.rect(x, y, width, height);
		}
		ctx.closePath();
		ctx.fillStyle = fill || '#ffffff';
		ctx.fill();
	};

	RenderSystem.prototype.text = function (text, x, y, options) {
		var ctx = this.context;
		var opts = options || {};
		ctx.font = opts.font || '600 20px system-ui, sans-serif';
		ctx.fillStyle = opts.fill || '#111827';
		ctx.textAlign = opts.align || 'left';
		ctx.textBaseline = opts.baseline || 'middle';
		ctx.fillText(String(text), x, y);
	};

	RenderSystem.prototype.destroy = function () {
		window.removeEventListener('resize', this.resizeHandler);
		if (this.canvas && this.canvas.parentNode) {
			this.canvas.parentNode.removeChild(this.canvas);
		}
	};

	window.NKGRenderSystem = RenderSystem;
}(window));
