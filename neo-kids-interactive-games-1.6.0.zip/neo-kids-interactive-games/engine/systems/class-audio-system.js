(function (window) {
	'use strict';

	function AudioSystem(engine) {
		this.engine = engine;
		this.enabled = true;
	}

	AudioSystem.prototype.setEnabled = function (enabled) {
		this.enabled = !!enabled;
	};

	AudioSystem.prototype.play = function (audio) {
		if (!this.enabled || !audio) {
			return;
		}
		audio.currentTime = 0;
		audio.play().catch(function () {});
	};

	window.NKGAudioSystem = AudioSystem;
}(window));
