(function (window) {
	'use strict';

	function EntityManager() {
		this.entities = {};
		this.nextId = 1;
	}

	EntityManager.prototype.create = function (components) {
		var id = this.nextId++;
		this.entities[id] = {
			id: id,
			components: Object.assign({}, components || {})
		};
		return this.entities[id];
	};

	EntityManager.prototype.get = function (id) {
		return this.entities[id] || null;
	};

	EntityManager.prototype.addComponent = function (id, name, value) {
		var entity = this.get(id);
		if (!entity) {
			return null;
		}
		entity.components[name] = value;
		return entity;
	};

	EntityManager.prototype.removeComponent = function (id, name) {
		var entity = this.get(id);
		if (entity) {
			delete entity.components[name];
		}
	};

	EntityManager.prototype.hasComponent = function (id, name) {
		var entity = this.get(id);
		return !!(entity && Object.prototype.hasOwnProperty.call(entity.components, name));
	};

	EntityManager.prototype.remove = function (id) {
		delete this.entities[id];
	};

	EntityManager.prototype.clear = function () {
		this.entities = {};
		this.nextId = 1;
	};

	EntityManager.prototype.all = function () {
		return Object.keys(this.entities).map(function (id) {
			return this.entities[id];
		});
	};

	EntityManager.prototype.query = function (componentNames) {
		return this.all().filter(function (entity) {
			return componentNames.every(function (name) {
				return Object.prototype.hasOwnProperty.call(entity.components, name);
			});
		});
	};

	window.NKGEntityManager = EntityManager;
}(window));
