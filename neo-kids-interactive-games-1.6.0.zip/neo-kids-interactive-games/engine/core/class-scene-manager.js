(function (window) {
	'use strict';

	function SceneManager(engine) {
		this.engine = engine;
		this.scenes = {};
		this.current = null;
		this.currentName = '';
	}

	SceneManager.prototype.register = function (name, scene) {
		this.scenes[name] = scene;
		return scene;
	};

	SceneManager.prototype.change = function (name, data) {
		var next = this.scenes[name];
		if (!next) {
			throw new Error('NKG scene not registered: ' + name);
		}

		if (this.current && typeof this.current.exit === 'function') {
			this.current.exit();
		}

		this.current = next;
		this.currentName = name;
		if (typeof this.current.enter === 'function') {
			this.current.enter(data || {});
		}
		this.engine.events.emit('scene:changed', { name: name, data: data || {} });
	};

	SceneManager.prototype.update = function (delta) {
		if (this.current && typeof this.current.update === 'function') {
			this.current.update(delta);
		}
	};

	SceneManager.prototype.render = function () {
		if (this.current && typeof this.current.render === 'function') {
			this.current.render();
		}
	};

	window.NKGSceneManager = SceneManager;
}(window));
