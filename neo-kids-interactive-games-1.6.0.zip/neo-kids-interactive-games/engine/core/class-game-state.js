(function (window) {
	'use strict';

	function GameState(initial) {
		this.data = Object.assign({}, initial || {});
		this.listeners = [];
	}

	GameState.prototype.get = function (key) {
		return this.data[key];
	};

	GameState.prototype.set = function (key, value) {
		this.data[key] = value;
		this.listeners.slice().forEach(function (listener) {
			listener(key, value);
		});
	};

	GameState.prototype.update = function (values) {
		var self = this;
		Object.keys(values || {}).forEach(function (key) {
			self.set(key, values[key]);
		});
	};

	GameState.prototype.subscribe = function (listener) {
		this.listeners.push(listener);
		return listener;
	};

	window.NKGGameState = GameState;
}(window));
