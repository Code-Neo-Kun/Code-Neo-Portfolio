(function (window) {
	'use strict';

	function EventBus() {
		this.events = {};
	}

	EventBus.prototype.on = function (name, callback) {
		if (!this.events[name]) {
			this.events[name] = [];
		}
		this.events[name].push(callback);
		return callback;
	};

	EventBus.prototype.off = function (name, callback) {
		if (!this.events[name]) {
			return;
		}
		this.events[name] = this.events[name].filter(function (fn) {
			return fn !== callback;
		});
	};

	EventBus.prototype.emit = function (name, payload) {
		var listeners = this.events[name] || [];
		listeners.slice().forEach(function (callback) {
			callback(payload);
		});
	};

	window.NKGEventBus = EventBus;
}(window));
