(function (window) {
	'use strict';

	function SystemManager(engine) {
		this.engine = engine;
		this.systems = [];
	}

	SystemManager.prototype.add = function (system) {
		if (!system) {
			return system;
		}
		this.systems.push(system);
		if (typeof system.init === 'function') {
			system.init(this.engine);
		}
		return system;
	};

	SystemManager.prototype.remove = function (system) {
		this.systems = this.systems.filter(function (item) {
			return item !== system;
		});
	};

	SystemManager.prototype.update = function (delta) {
		this.systems.forEach(function (system) {
			if (typeof system.update === 'function') {
				system.update(delta);
			}
		});
	};

	SystemManager.prototype.render = function () {
		this.systems.forEach(function (system) {
			if (typeof system.render === 'function') {
				system.render();
			}
		});
	};

	SystemManager.prototype.clear = function () {
		this.systems.forEach(function (system) {
			if (typeof system.destroy === 'function') {
				system.destroy();
			}
		});
		this.systems = [];
	};

	window.NKGSystemManager = SystemManager;
}(window));
