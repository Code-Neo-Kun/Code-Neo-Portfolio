(function (window) {
	'use strict';

	function intersects(a, b) {
		return !!a && !!b &&
			a.x < b.x + b.width &&
			a.x + a.width > b.x &&
			a.y < b.y + b.height &&
			a.y + a.height > b.y;
	}

	function containsPoint(rect, x, y) {
		return !!rect &&
			x >= rect.x &&
			x <= rect.x + rect.width &&
			y >= rect.y &&
			y <= rect.y + rect.height;
	}

	window.NKGCollision = {
		intersects: intersects,
		containsPoint: containsPoint
	};
}(window));
