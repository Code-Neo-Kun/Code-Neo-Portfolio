(function (window) {
	'use strict';

	function AssetManager() {
		this.images = {};
		this.audio = {};
	}

	AssetManager.prototype.loadImage = function (key, url) {
		var self = this;
		return new Promise(function (resolve, reject) {
			var image = new Image();
			image.onload = function () {
				self.images[key] = image;
				resolve(image);
			};
			image.onerror = reject;
			image.src = url;
		});
	};

	AssetManager.prototype.getImage = function (key) {
		return this.images[key] || null;
	};

	AssetManager.prototype.loadAudio = function (key, url) {
		var audio = new Audio(url);
		this.audio[key] = audio;
		return Promise.resolve(audio);
	};

	AssetManager.prototype.playAudio = function (key) {
		if (this.audio[key]) {
			this.audio[key].currentTime = 0;
			this.audio[key].play().catch(function () {});
		}
	};

	window.NKGAssetManager = AssetManager;
}(window));
