(function (window) {
	'use strict';

	function Scene(engine, name, handlers) {
		this.engine = engine;
		this.name = name || 'scene';
		this.handlers = handlers || {};
	}

	Scene.prototype.enter = function (data) {
		if (typeof this.handlers.enter === 'function') {
			this.handlers.enter.call(this, data || {});
		}
	};

	Scene.prototype.update = function (delta) {
		if (typeof this.handlers.update === 'function') {
			this.handlers.update.call(this, delta);
		}
	};

	Scene.prototype.render = function () {
		if (typeof this.handlers.render === 'function') {
			this.handlers.render.call(this);
		}
	};

	Scene.prototype.exit = function () {
		if (typeof this.handlers.exit === 'function') {
			this.handlers.exit.call(this);
		}
	};

	window.NKGScene = Scene;
}(window));
