(function (window) {
	'use strict';

	function GameEngine(container, config) {
		this.container = container;
		this.config = config || {};
		this.events = new NKGEventBus();
		this.state = new NKGGameState({
			status: 'idle',
			score: 0,
			level: 1,
			startedAt: null
		});
		this.entities = new NKGEntityManager();
		this.scenes = new NKGSceneManager(this);
		this.systems = new NKGSystemManager(this);
		this.assets = new NKGAssetManager();
		this.renderer = new NKGRenderSystem(this, container);
		this.input = new NKGInputSystem(this);
		this.audio = new NKGAudioSystem(this);
		this.systems.add(this.input);
		this.running = false;
		this.finished = false;
		this.lastTime = 0;
		this.frame = 0;
	}

	GameEngine.prototype.registerScene = function (name, scene) {
		this.scenes.register(name, scene);
		return scene;
	};

	GameEngine.prototype.addSystem = function (system) {
		return this.systems.add(system);
	};

	GameEngine.prototype.createEntity = function (components) {
		return this.entities.create(components);
	};

	GameEngine.prototype.changeScene = function (name, data) {
		this.scenes.change(name, data || {});
	};

	GameEngine.prototype.start = function (scene, data) {
		if (this.running) {
			return;
		}
		if (scene && !this.scenes.scenes[scene]) {
			throw new Error('NKG scene not registered: ' + scene);
		}
		this.running = true;
		this.finished = false;
		this.state.update({
			status: 'running',
			startedAt: Date.now()
		});
		if (scene) {
			this.scenes.change(scene, data || {});
		}
		this.lastTime = performance.now();
		this.events.emit('engine:start', { scene: scene || null });
		this.loop(this.lastTime);
	};

	GameEngine.prototype.loop = function (timestamp) {
		if (!this.running) {
			return;
		}

		var delta = Math.min(0.1, Math.max(0, (timestamp - this.lastTime) / 1000));
		this.lastTime = timestamp;
		this.frame += 1;
		this.systems.update(delta);
		this.scenes.update(delta);
		this.renderer.clear();
		this.systems.render();
		this.scenes.render();
		window.requestAnimationFrame(this.loop.bind(this));
	};

	GameEngine.prototype.stop = function () {
		this.running = false;
		this.state.set('status', 'stopped');
		this.events.emit('engine:stop', {});
	};

	GameEngine.prototype.finish = function (result) {
		if (this.finished) {
			return;
		}
		this.finished = true;
		this.running = false;
		this.state.update({
			status: 'finished',
			score: Number(result && result.score ? result.score : this.state.get('score') || 0)
		});
		this.events.emit('game:finished', result || {});
	};

	GameEngine.prototype.destroy = function () {
		this.stop();
		this.systems.clear();
		this.entities.clear();
		this.scenes.change = function () {};
		if (this.renderer) {
			this.renderer.destroy();
		}
		this.events = new NKGEventBus();
	};

	window.NKGGameEngine = GameEngine;
}(window));
