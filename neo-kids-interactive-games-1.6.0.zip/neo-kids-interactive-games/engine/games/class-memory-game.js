(function (window) {
	'use strict';

	function MemoryGame(engine, options) {
		NKGGameApplication.call(this, engine, options);
		this.difficulty = options.difficulty || 'easy';
		this.pairs = this.difficulty === 'hard' ? 8 : (this.difficulty === 'medium' ? 6 : 4);
		this.icons = ['🐶','🐱','🐸','🦁','🐼','🐵','🐰','🦊'].slice(0, this.pairs);
		this.cards = [];
		this.matches = 0;
		this.mistakes = 0;
		this.firstId = 0;
		this.locked = false;
		this.startedAt = 0;
		this.flipTimer = null;
		this.cardSize = 0;
		this.gap = 12;
		this.columns = 4;

		var self = this;
		this.scene = new NKGScene(engine, 'memory', {
			enter: function () {
				self.layout();
			},
			update: function () {},
			render: function () {
				self.renderCanvas();
			},
			exit: function () {
				self.clearTimer();
			}
		});
		engine.registerScene('game', this.scene);
		engine.events.on('input:pointer', function (event) {
			if ('up' === event.type) {
				self.handlePointer(event.x, event.y);
			}
		});
	}

	MemoryGame.prototype = Object.create(NKGGameApplication.prototype);
	MemoryGame.prototype.constructor = MemoryGame;

	MemoryGame.prototype.start = function () {
		NKGGameApplication.prototype.start.call(this);
		this.startedAt = Date.now();
		this.matches = 0;
		this.mistakes = 0;
		this.firstId = 0;
		this.locked = false;
		this.clearTimer();
		this.engine.entities.clear();

		var deck = this.icons.concat(this.icons);
		for (var i = deck.length - 1; i > 0; i -= 1) {
			var j = Math.floor(Math.random() * (i + 1));
			var temp = deck[i];
			deck[i] = deck[j];
			deck[j] = temp;
		}

		var self = this;
		this.cards = deck.map(function (icon, index) {
			return self.engine.createEntity({
				transform: { x: 0, y: 0, width: 80, height: 80 },
				memory: {
					icon: icon,
					index: index,
					open: false,
					matched: false
				}
			});
		});

		this.layout();
		this.engine.state.set('score', 0);
	};

	MemoryGame.prototype.layout = function () {
		if (!this.cards.length || !this.engine.renderer) {
			return;
		}
		var width = this.engine.renderer.width;
		var height = this.engine.renderer.height;
		this.columns = width < 520 ? 4 : 4;
		this.gap = width < 520 ? 8 : 12;
		var marginX = 24;
		var top = 88;
		var available = width - marginX * 2 - this.gap * (this.columns - 1);
		this.cardSize = Math.max(52, Math.min(110, available / this.columns));
		var rows = Math.ceil(this.cards.length / this.columns);
		var totalHeight = rows * this.cardSize + (rows - 1) * this.gap;
		var startY = Math.max(top, (height - totalHeight) / 2 + 28);

		this.cards.forEach(function (entity, index) {
			var row = Math.floor(index / this.columns);
			var col = index % this.columns;
			entity.components.transform.x = marginX + col * (this.cardSize + this.gap);
			entity.components.transform.y = startY + row * (this.cardSize + this.gap);
			entity.components.transform.width = this.cardSize;
			entity.components.transform.height = this.cardSize;
		});
	};

	MemoryGame.prototype.handlePointer = function (x, y) {
		var self = this;
		if (this.locked || this.finished) {
			return;
		}

		var hit = this.cards.find(function (entity) {
			var t = entity.components.transform;
			var m = entity.components.memory;
			return !m.open && !m.matched && NKGCollision.containsPoint(t, x, y);
		});

		if (!hit) {
			return;
		}

		hit.components.memory.open = true;

		if (!this.firstId) {
			this.firstId = hit.id;
			return;
		}

		var first = this.engine.entities.get(this.firstId);
		if (!first) {
			this.firstId = 0;
			return;
		}

		if (first.components.memory.icon === hit.components.memory.icon) {
			first.components.memory.matched = true;
			hit.components.memory.matched = true;
			this.firstId = 0;
			this.matches += 1;
			this.updateScore();

			if (this.matches === this.pairs) {
				this.finish({
					completed: true,
					matches: this.matches,
					mistakes: this.mistakes,
					duration: Math.round((Date.now() - this.startedAt) / 1000)
				});
			}
			return;
		}

		this.mistakes += 1;
		this.locked = true;
		this.updateScore();
		this.clearTimer();
		this.flipTimer = window.setTimeout(function () {
			first.components.memory.open = false;
			hit.components.memory.open = false;
			self.firstId = 0;
			self.locked = false;
			self.updateScore();
		}, 700);
	};

	MemoryGame.prototype.updateScore = function () {
		this.engine.state.set('score', Math.max(0, this.matches * 10 - this.mistakes));
	};

	MemoryGame.prototype.clearTimer = function () {
		if (this.flipTimer) {
			window.clearTimeout(this.flipTimer);
			this.flipTimer = null;
		}
	};

	MemoryGame.prototype.renderCanvas = function () {
		var renderer = this.engine.renderer;
		var ctx = renderer.context;
		var width = renderer.width;
		var height = renderer.height;

		ctx.save();
		renderer.rect(0, 0, width, height, '#f8fafc', 0);
		renderer.text('Memory Match', width / 2, 28, {
			font: '800 22px system-ui, sans-serif',
			fill: '#111827',
			align: 'center'
		});
		renderer.text('Find all matching pairs', width / 2, 56, {
			font: '500 14px system-ui, sans-serif',
			fill: '#64748b',
			align: 'center'
		});

		this.cards.forEach(function (entity) {
			var t = entity.components.transform;
			var m = entity.components.memory;
			renderer.rect(t.x, t.y, t.width, t.height, m.matched ? '#dcfce7' : (m.open ? '#fef3c7' : '#e0e7ff'), 16);
			renderer.rect(t.x + 3, t.y + 3, t.width - 6, t.height - 6, m.matched ? '#f0fdf4' : (m.open ? '#fffbeb' : '#eef2ff'), 13);
			renderer.text(m.open || m.matched ? m.icon : '?', t.x + t.width / 2, t.y + t.height / 2, {
				font: '700 ' + Math.max(26, Math.round(t.width * 0.38)) + 'px system-ui, sans-serif',
				fill: '#111827',
				align: 'center'
			});
		});

		renderer.text('Pairs: ' + this.matches + '/' + this.pairs, 24, height - 24, {
			font: '600 14px system-ui, sans-serif',
			fill: '#475569'
		});
		renderer.text('Mistakes: ' + this.mistakes, width - 24, height - 24, {
			font: '600 14px system-ui, sans-serif',
			fill: '#475569',
			align: 'right'
		});
		ctx.restore();
	};

	MemoryGame.prototype.destroy = function () {
		this.clearTimer();
		NKGGameApplication.prototype.destroy.call(this);
	};

	window.NKGMemoryGame = MemoryGame;
	window.NKG_GAME_MODULES.register('memory', function (engine, options) {
		return new MemoryGame(engine, options);
	});
}(window));
