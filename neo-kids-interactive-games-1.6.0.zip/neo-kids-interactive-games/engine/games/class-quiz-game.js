(function (window) {
	'use strict';

	function QuizGame(engine, options) {
		NKGGameApplication.call(this, engine, options);
		this.difficulty = options.difficulty || 'easy';
		this.sessionId = options.sessionId || 0;
		this.items = options.items || [
			{ q: 'Which animal says “meow”?', a: ['🐶 Dog', '🐱 Cat', '🐮 Cow'], correct: 1 },
			{ q: 'Which one is a fruit?', a: ['🚗 Car', '🍎 Apple', '🏠 House'], correct: 1 },
			{ q: 'Which color is usually associated with grass?', a: ['🍃 Green', '🌊 Blue', '🍋 Yellow'], correct: 0 }
		];
		if (this.difficulty === 'medium' || this.difficulty === 'hard') {
			this.items.push({ q: 'How many legs does a dog usually have?', a: ['2', '4', '6'], correct: 1 });
		}
		if (this.difficulty === 'hard') {
			this.items.push({ q: 'Which planet do we live on?', a: ['Mars', 'Earth', 'Jupiter'], correct: 1 });
		}
		this.index = 0;
		this.correct = 0;
		this.startedAt = 0;
	}

	QuizGame.prototype = Object.create(NKGGameApplication.prototype);
	QuizGame.prototype.constructor = QuizGame;

	QuizGame.prototype.start = function () {
		NKGGameApplication.prototype.start.call(this);
		this.startedAt = Date.now();
		this.showQuestion();
	};

	QuizGame.prototype.showQuestion = function () {
		var self = this;
		var item = this.items[this.index];
		this.board.innerHTML = '';
		this.board.className = 'nkg-board nkg-quiz-board';

		var progress = document.createElement('div');
		progress.className = 'nkg-quiz-progress';
		progress.textContent = 'Question ' + (this.index + 1) + ' of ' + this.items.length;
		this.board.appendChild(progress);

		var question = document.createElement('div');
		question.className = 'nkg-question';
		question.textContent = item.q;
		this.board.appendChild(question);

		item.a.forEach(function (answer, answerIndex) {
			var button = document.createElement('button');
			button.type = 'button';
			button.className = 'nkg-answer';
			button.textContent = answer;
			button.addEventListener('click', function () {
				if (answerIndex === item.correct) {
					self.correct++;
				}
				self.index++;

				if (self.index === self.items.length) {
					self.finish({
						completed: true,
						correct: self.correct,
						duration: Math.round((Date.now() - self.startedAt) / 1000)
					});
					return;
				}
				self.showQuestion();
			});
			self.board.appendChild(button);
		});
	};

	window.NKGQuizGame = QuizGame;
	window.NKG_GAME_MODULES.register('quiz', function (engine, options) {
		return new QuizGame(engine, options);
	});
}(window));
