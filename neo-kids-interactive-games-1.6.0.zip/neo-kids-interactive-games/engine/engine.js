(function (window) {
	'use strict';

	window.NKGEngine = {
		version: '1.6.0',
		create: function (container, config) {
			return new NKGGameEngine(container, config || {});
		},
		modules: window.NKG_GAME_MODULES
	};
}(window));
