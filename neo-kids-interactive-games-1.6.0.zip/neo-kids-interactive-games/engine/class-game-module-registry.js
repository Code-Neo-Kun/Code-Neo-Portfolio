(function (window) {
	'use strict';

	function GameModuleRegistry() {
		this.modules = {};
	}

	GameModuleRegistry.prototype.register = function (key, factory) {
		this.modules[key] = factory;
	};

	GameModuleRegistry.prototype.has = function (key) {
		return typeof this.modules[key] === 'function';
	};

	GameModuleRegistry.prototype.create = function (key, engine, options) {
		if (!this.has(key)) {
			throw new Error('NKG game module not registered: ' + key);
		}
		return this.modules[key](engine, options || {});
	};

	window.NKGGameModuleRegistry = GameModuleRegistry;
	window.NKG_GAME_MODULES = new GameModuleRegistry();
}(window));
