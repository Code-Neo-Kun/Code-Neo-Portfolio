(function (window) {
	'use strict';

	function GameApplication(engine, options) {
		this.engine = engine;
		this.options = options || {};
		this.root = this.options.root || engine.container;
		this.board = this.options.board || this.root.querySelector('.nkg-board');
		this.started = false;
		this.finished = false;
	}

	GameApplication.prototype.start = function (data) {
		this.started = true;
		this.engine.events.emit('application:start', { data: data || {} });
	};

	GameApplication.prototype.update = function (delta) {
		this.engine.events.emit('application:update', { delta: delta });
	};

	GameApplication.prototype.render = function () {};

	GameApplication.prototype.finish = function (result) {
		if (this.finished) {
			return;
		}
		this.finished = true;
		this.engine.finish(result || {});
	};

	GameApplication.prototype.destroy = function () {
		this.engine.stop();
		if (this.board) {
			this.board.innerHTML = '';
		}
	};

	window.NKGGameApplication = GameApplication;
}(window));
