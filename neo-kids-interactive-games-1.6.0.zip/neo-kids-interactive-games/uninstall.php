<?php
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

if ( ! get_option( 'nkg_delete_data_on_uninstall', false ) ) {
	return;
}

global $wpdb;
$tables = array(
	$wpdb->prefix . 'nkg_player_badges',
	$wpdb->prefix . 'nkg_institutions',
	$wpdb->prefix . 'nkg_teachers',
	$wpdb->prefix . 'nkg_assignments',
	$wpdb->prefix . 'nkg_content',
	$wpdb->prefix . 'nkg_achievements',
	$wpdb->prefix . 'nkg_progress',
	$wpdb->prefix . 'nkg_sessions',
	$wpdb->prefix . 'nkg_games',
	$wpdb->prefix . 'nkg_players',
);

foreach ( $tables as $table ) {
	$wpdb->query( "DROP TABLE IF EXISTS {$table}" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.PreparedSQL.NotPrepared
}

delete_option( 'nkg_db_version' );
delete_option( 'nkg_settings' );
delete_option( 'nkg_delete_data_on_uninstall' );
