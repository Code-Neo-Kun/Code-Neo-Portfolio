<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

class NKG_Gutenberg {
	public static function init() {
		add_action( 'init', array( __CLASS__, 'register' ) );
	}

	public static function register() {
		register_block_type( NKG_PATH . 'integrations/gutenberg' );
	}
}
