(function (blocks, blockEditor, components, element, serverSideRender) {
	'use strict';
	const el = element.createElement;
	const useBlockProps = blockEditor.useBlockProps;
	const InspectorControls = blockEditor.InspectorControls;
	const PanelBody = components.PanelBody;
	const SelectControl = components.SelectControl;

	blocks.registerBlockType('neo-kids-games/game', {
		edit: function (props) {
			return el('div', useBlockProps(),
				el(InspectorControls, {},
					el(PanelBody, { title: 'Game Settings', initialOpen: true },
						el(SelectControl, {
							label: 'Game',
							value: props.attributes.type,
							options: [
								{ label: 'Memory Match', value: 'memory' },
								{ label: 'Quick Quiz', value: 'quiz' }
							],
							onChange: function (value) { props.setAttributes({ type: value }); }
						}),
						el(SelectControl, {
							label: 'Difficulty',
							value: props.attributes.difficulty,
							options: [
								{ label: 'Easy', value: 'easy' },
								{ label: 'Medium', value: 'medium' },
								{ label: 'Hard', value: 'hard' }
							],
							onChange: function (value) { props.setAttributes({ difficulty: value }); }
						})
					)
				),
				el(serverSideRender, { block: 'neo-kids-games/game', attributes: props.attributes })
			);
		},
		save: function () { return null; }
	});
})(window.wp.blocks, window.wp.blockEditor, window.wp.components, window.wp.element, window.wp.serverSideRender);
