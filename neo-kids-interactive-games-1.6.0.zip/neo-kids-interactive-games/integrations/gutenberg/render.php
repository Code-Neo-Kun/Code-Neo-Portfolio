<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
$type = isset( $attributes['type'] ) ? sanitize_key( $attributes['type'] ) : 'memory';
$difficulty = isset( $attributes['difficulty'] ) ? sanitize_key( $attributes['difficulty'] ) : 'easy';
echo NKG_Frontend::game_shortcode( array( 'type' => $type, 'difficulty' => $difficulty ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
