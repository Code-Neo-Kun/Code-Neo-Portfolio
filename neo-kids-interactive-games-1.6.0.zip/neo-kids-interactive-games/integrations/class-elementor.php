<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

class NKG_Elementor {
	public static function init() {
		add_action( 'elementor/widgets/register', array( __CLASS__, 'register' ) );
	}

	public static function register( $widgets_manager ) {
		if ( class_exists( '\Elementor\Widget_Base' ) ) {
			$widgets_manager->register( new NKG_Elementor_Widget() );
		}
	}
}

if ( class_exists( '\Elementor\Widget_Base' ) ) {
	class NKG_Elementor_Widget extends \Elementor\Widget_Base {
		public function get_name() { return 'neo-kids-game'; }
		public function get_title() { return esc_html__( 'Neo Kids Game', 'neo-kids-games' ); }
		public function get_icon() { return 'eicon-game-controller'; }
		public function get_categories() { return array( 'general' ); }

		protected function register_controls() {
			$this->start_controls_section( 'game_section', array( 'label' => esc_html__( 'Game', 'neo-kids-games' ) ) );
			$this->add_control( 'type', array(
				'label' => esc_html__( 'Game', 'neo-kids-games' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'memory',
				'options' => array( 'memory' => esc_html__( 'Memory Match', 'neo-kids-games' ), 'quiz' => esc_html__( 'Quick Quiz', 'neo-kids-games' ) ),
			) );
			$this->add_control( 'difficulty', array(
				'label' => esc_html__( 'Difficulty', 'neo-kids-games' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'easy',
				'options' => array( 'easy' => 'Easy', 'medium' => 'Medium', 'hard' => 'Hard' ),
			) );
			$this->end_controls_section();
		}

		protected function render() {
			$settings = $this->get_settings_for_display();
			echo NKG_Frontend::game_shortcode( array( 'type' => $settings['type'], 'difficulty' => $settings['difficulty'] ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
	}
}
