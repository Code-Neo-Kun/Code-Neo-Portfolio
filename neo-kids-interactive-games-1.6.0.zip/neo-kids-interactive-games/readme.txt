=== Neo Kids Interactive Games ===
Contributors: neo
Tags: kids, games, education, children, interactive, gutenberg, elementor
Requires at least: 6.3
Requires PHP: 8.0
Stable tag: 1.6.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Tested up to: 6.9

A lightweight, extensible WordPress game engine for children's mini-games with custom player profiles, progress, XP, achievements, Gutenberg, Elementor, and shortcode support.

== Description ==

Neo Kids Interactive Games provides a reusable game engine rather than a collection of unrelated games. The first release includes Memory Match and Quick Quiz.

Player records, game sessions, progress, achievements, and game definitions are stored in dedicated custom database tables.

Guest players receive a random local player token stored by the browser. The raw token is not stored in the database; only a salted hash is stored.

== Features ==

* Custom database tables for plugin data.
* Admin Content Builder for game questions.
* Quiz content can be managed from the database-backed builder.
* Individual player profiles.
* Guest player identity with persistent browser token.
* WordPress user association when a logged-in user creates a profile.
* Game Registry and Game Interface architecture.
* Engine-native scenes, entities, components, systems, input, collision, and Canvas rendering.
* Memory Match game rendered directly by the browser game engine.
* Quick Quiz game.
* Difficulty levels.
* Server-side result validation.
* Game sessions and progress tracking.
* XP and level progression.
* Achievement/badge foundation.
* Gutenberg block.
* Elementor widget when Elementor is active.
* Shortcodes.
* WordPress Privacy exporter and eraser integration.
* No external tracking or executable remote code.
* GPL-2.0-or-later.

== Shortcodes ==

[nkg_game type="memory" difficulty="easy"]

[nkg_game type="quiz" difficulty="medium"]

[nkg_player_profile]

== Database ==

The plugin creates:

* wp_nkg_players
* wp_nkg_games
* wp_nkg_sessions
* wp_nkg_progress
* wp_nkg_achievements
* wp_nkg_player_badges

The wp_ prefix is replaced by the site's actual WordPress database prefix.

== Privacy ==

The plugin stores player nickname, a hashed guest token, optional WordPress user association, game sessions, progress, scores, XP, levels, and achievements.

Site owners should provide appropriate privacy information for their site and should only collect information necessary for their use case. WordPress privacy exporter/eraser hooks are included for profiles associated with WordPress user accounts.

Guest profiles are browser-local identities. Clearing browser storage or changing browsers will not automatically recover a guest profile.

== Compatibility ==

Elementor is optional. Gutenberg support is included through the WordPress Block API. The plugin uses WordPress APIs and does not require a page builder.

== Development ==

Author: Neo
Author URL: https://code-neo-portfolio.vercel.app/

The plugin source is intentionally human-readable. It does not download or execute remote code.

== Installation ==

1. Upload the ZIP through Plugins > Add New > Upload Plugin.
2. Activate the plugin.
3. Open Kids Games in wp-admin.
4. Add a Gutenberg block, Elementor widget, or shortcode.

== Changelog ==

= 1.0.0 =
* Rebuilt around a game-engine architecture.
* Added custom player, game, session, progress, achievement, and badge tables.
* Added persistent guest player profiles.
* Added server-side game result validation.
* Added XP and level progression.
* Added achievements.
* Added privacy exporter and eraser hooks.
* Added Gutenberg and Elementor integrations.
* Added Memory Match and Quick Quiz reference games.

== 1.2.0 ==
* Added a visual Content Builder with create/edit/duplicate/delete workflows.
* Added draft/publish status, categories, difficulty, ordering, and image support.
* Added WordPress Media Library image selection.
* Added live question preview in the admin.
* Added content library filters and status controls.
* Migrated content table with `sort_order` and `image_url` fields.

== 1.2.1 ==
* Added standalone player profile creation before gameplay.
* Games no longer create a player automatically.
* Start Game is disabled until an authenticated player profile exists.
* Added stale profile-token recovery so users can create a new profile if their local profile is invalid.

== 1.3.0 ==
* Added institution-based player profiles.
* Added institution directory and institution codes.
* Added class/group assignment and student ID fields.
* Players must verify an active institution before profile creation.
* Games require an authenticated institution-linked player profile.
* Added institution lookup REST endpoint.

== 1.4.0 ==
* Added the browser-side NKG Game Engine foundation.
* Added engine core: game state, event bus, entity manager, scene manager, asset manager, and game loop.
* Added input, audio, and Canvas rendering systems.
* Added institution game assignments.
* Added teacher-to-institution linking.
* Added institution assignment dashboard shortcode.

== 1.6.0 ==
* Added the NKG browser Game Application API and game module registry.
* Added the first engine-native Memory and Quiz game modules.
* Game lifecycle now runs through the engine event bus and state system.
* Kept result submission server-authoritative through the existing REST session endpoint.
* Added engine runtime container and Canvas renderer foundation for future WebGL/WebGPU systems.
