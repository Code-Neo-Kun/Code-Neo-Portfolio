<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

class NKG_Privacy {
	public static function init() {
		add_filter( 'wp_privacy_personal_data_exporters', array( __CLASS__, 'exporter' ) );
		add_filter( 'wp_privacy_personal_data_erasers', array( __CLASS__, 'eraser' ) );
	}

	public static function exporter( $exporters ) {
		$exporters['neo-kids-games'] = array(
			'exporter_friendly_name' => __( 'Neo Kids Games Player Data', 'neo-kids-games' ),
			'callback' => array( __CLASS__, 'export' ),
		);
		return $exporters;
	}

	public static function eraser( $erasers ) {
		$erasers['neo-kids-games'] = array(
			'eraser_friendly_name' => __( 'Neo Kids Games Player Data', 'neo-kids-games' ),
			'callback' => array( __CLASS__, 'erase' ),
		);
		return $erasers;
	}

	public static function export( $email, $page = 1 ) {
		$user = get_user_by( 'email', $email );
		if ( ! $user ) {
			return array( 'data' => array(), 'done' => true );
		}
		global $wpdb;
		$t = NKG_Database::tables();
		$players = $wpdb->get_results( $wpdb->prepare( "SELECT id, nickname, level, xp, created_at FROM {$t['players']} WHERE user_id = %d", $user->ID ), ARRAY_A );
		$data = array();
		foreach ( $players as $player ) {
			$data[] = array(
				'group_id' => 'neo-kids-games',
				'group_label' => __( 'Neo Kids Games', 'neo-kids-games' ),
				'item_id' => 'player-' . $player['id'],
				'data' => array(
					array( 'name' => __( 'Nickname', 'neo-kids-games' ), 'value' => $player['nickname'] ),
					array( 'name' => __( 'Level', 'neo-kids-games' ), 'value' => $player['level'] ),
					array( 'name' => __( 'XP', 'neo-kids-games' ), 'value' => $player['xp'] ),
					array( 'name' => __( 'Created', 'neo-kids-games' ), 'value' => $player['created_at'] ),
				),
			);
		}
		return array( 'data' => $data, 'done' => true );
	}

	public static function erase( $email, $page = 1 ) {
		$user = get_user_by( 'email', $email );
		if ( ! $user ) {
			return array( 'items_removed' => false, 'items_retained' => false, 'messages' => array(), 'done' => true );
		}
		global $wpdb;
		$t = NKG_Database::tables();
		$players = $wpdb->get_col( $wpdb->prepare( "SELECT id FROM {$t['players']} WHERE user_id = %d", $user->ID ) );
		foreach ( $players as $player_id ) {
			$wpdb->delete( $t['player_badges'], array( 'player_id' => absint( $player_id ) ), array( '%d' ) );
			$wpdb->delete( $t['progress'], array( 'player_id' => absint( $player_id ) ), array( '%d' ) );
			$wpdb->delete( $t['sessions'], array( 'player_id' => absint( $player_id ) ), array( '%d' ) );
			$wpdb->delete( $t['players'], array( 'id' => absint( $player_id ) ), array( '%d' ) );
		}
		return array( 'items_removed' => (bool) $players, 'items_retained' => false, 'messages' => array(), 'done' => true );
	}
}
