<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

class NKG_Institution {
	public static function init() {}

	public static function normalize_code( $code ) {
		return strtoupper( preg_replace( '/[^A-Z0-9_-]/', '', sanitize_text_field( $code ) ) );
	}

	public static function create( array $data ) {
		global $wpdb;
		$t = NKG_Database::tables();
		$name = sanitize_text_field( $data['name'] ?? '' );
		$code = self::normalize_code( $data['code'] ?? '' );
		$contact_name = sanitize_text_field( $data['contact_name'] ?? '' );
		$contact_email = sanitize_email( $data['contact_email'] ?? '' );
		$classes = array();

		if ( ! empty( $data['classes'] ) ) {
			$raw = is_array( $data['classes'] ) ? $data['classes'] : preg_split( '/[\r\n,]+/', (string) $data['classes'] );
			foreach ( $raw as $class ) {
				$class = sanitize_text_field( $class );
				if ( $class && ! in_array( $class, $classes, true ) ) {
					$classes[] = $class;
				}
			}
		}

		if ( '' === $name || '' === $code ) {
			return new WP_Error( 'invalid_institution', __( 'Institution name and code are required.', 'neo-kids-games' ) );
		}

		if ( $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$t['institutions']} WHERE code = %s", $code ) ) ) {
			return new WP_Error( 'institution_exists', __( 'That institution code is already in use.', 'neo-kids-games' ) );
		}

		$ok = $wpdb->insert(
			$t['institutions'],
			array(
				'name' => $name,
				'code' => $code,
				'contact_name' => $contact_name,
				'contact_email' => $contact_email,
				'classes' => wp_json_encode( $classes ),
				'status' => 'active',
				'created_at' => current_time( 'mysql' ),
				'updated_at' => current_time( 'mysql' ),
			),
			array( '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s' )
		);

		return $ok ? (int) $wpdb->insert_id : new WP_Error( 'institution_create_failed', __( 'Could not create institution.', 'neo-kids-games' ) );
	}

	public static function all( $status = '' ) {
		global $wpdb;
		$t = NKG_Database::tables();
		$where = 'WHERE 1=1';
		$args = array();
		if ( $status ) {
			$where .= ' AND status = %s';
			$args[] = sanitize_key( $status );
		}
		$sql = "SELECT * FROM {$t['institutions']} {$where} ORDER BY name ASC";
		if ( $args ) {
			$sql = $wpdb->prepare( $sql, $args );
		}
		$rows = $wpdb->get_results( $sql, ARRAY_A );
		foreach ( $rows as &$row ) {
			$row['classes'] = json_decode( $row['classes'], true );
			if ( ! is_array( $row['classes'] ) ) {
				$row['classes'] = array();
			}
		}
		return $rows;
	}

	public static function get( $id ) {
		global $wpdb;
		$t = NKG_Database::tables();
		$row = $wpdb->get_row(
			$wpdb->prepare( "SELECT * FROM {$t['institutions']} WHERE id = %d", absint( $id ) ),
			ARRAY_A
		);
		return self::decode( $row );
	}

	public static function get_by_code( $code ) {
		global $wpdb;
		$t = NKG_Database::tables();
		$code = self::normalize_code( $code );
		$row = $wpdb->get_row(
			$wpdb->prepare( "SELECT * FROM {$t['institutions']} WHERE code = %s AND status = 'active'", $code ),
			ARRAY_A
		);
		return self::decode( $row );
	}

	public static function decode( $row ) {
		if ( ! $row ) {
			return null;
		}
		$row['classes'] = json_decode( $row['classes'], true );
		if ( ! is_array( $row['classes'] ) ) {
			$row['classes'] = array();
		}
		return $row;
	}

	public static function update_status( $id, $status ) {
		global $wpdb;
		$t = NKG_Database::tables();
		$status = 'active' === $status ? 'active' : 'inactive';
		return false !== $wpdb->update(
			$t['institutions'],
			array( 'status' => $status, 'updated_at' => current_time( 'mysql' ) ),
			array( 'id' => absint( $id ) ),
			array( '%s', '%s' ),
			array( '%d' )
		);
	}
}
