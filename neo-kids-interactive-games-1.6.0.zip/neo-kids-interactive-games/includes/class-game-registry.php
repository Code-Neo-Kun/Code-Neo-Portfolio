<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

class NKG_Game_Registry {
	private static $games = array();

	public static function init() {
		self::register( new NKG_Memory_Game() );
		self::register( new NKG_Quiz_Game() );
	}

	public static function register( NKG_Game_Interface $game ) {
		self::$games[ $game->get_key() ] = $game;
	}

	public static function get( $key ) {
		$key = sanitize_key( $key );
		return isset( self::$games[ $key ] ) ? self::$games[ $key ] : null;
	}

	public static function all() {
		return self::$games;
	}

	public static function keys() {
		return array_keys( self::$games );
	}
}
