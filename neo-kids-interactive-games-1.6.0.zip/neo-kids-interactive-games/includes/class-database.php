<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

class NKG_Database {
	const DB_VERSION = '1.6.0';

	public static function tables() {
		global $wpdb;
		$p = $wpdb->prefix . 'nkg_';
		return array(
			'institutions' => $p . 'institutions',
			'teachers'     => $p . 'teachers',
			'assignments'  => $p . 'assignments',
			'players'      => $p . 'players',
			'games'        => $p . 'games',
			'sessions'     => $p . 'sessions',
			'progress'     => $p . 'progress',
			'achievements' => $p . 'achievements',
			'player_badges'=> $p . 'player_badges',
			'content'      => $p . 'content',
		);
	}

	public static function install() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$t = self::tables();
		$c = $wpdb->get_charset_collate();

		$queries = array(
			"CREATE TABLE {$t['teachers']} (
				id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
				institution_id bigint(20) unsigned NOT NULL,
				user_id bigint(20) unsigned NOT NULL,
				role varchar(30) NOT NULL DEFAULT 'teacher',
				created_at datetime NOT NULL,
				PRIMARY KEY (id),
				UNIQUE KEY institution_user (institution_id, user_id),
				KEY user_id (user_id)
			) {$c};",
			"CREATE TABLE {$t['assignments']} (
				id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
				institution_id bigint(20) unsigned NOT NULL,
				game_key varchar(60) NOT NULL,
				title varchar(200) NOT NULL,
				class_name varchar(100) NOT NULL DEFAULT '',
				difficulty varchar(20) NOT NULL DEFAULT 'easy',
				status varchar(20) NOT NULL DEFAULT 'active',
				starts_at datetime NULL,
				due_at datetime NULL,
				created_by bigint(20) unsigned NOT NULL DEFAULT 0,
				created_at datetime NOT NULL,
				updated_at datetime NOT NULL,
				PRIMARY KEY (id),
				KEY institution_id (institution_id),
				KEY game_key (game_key),
				KEY class_name (class_name),
				KEY status (status)
			) {$c};",

			"CREATE TABLE {$t['institutions']} (
				id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
				name varchar(200) NOT NULL,
				code varchar(60) NOT NULL,
				contact_name varchar(150) NOT NULL DEFAULT '',
				contact_email varchar(190) NOT NULL DEFAULT '',
				classes longtext NULL,
				status varchar(20) NOT NULL DEFAULT 'active',
				created_at datetime NOT NULL,
				updated_at datetime NOT NULL,
				PRIMARY KEY (id),
				UNIQUE KEY code (code),
				KEY status (status)
			) {$c};",
			"CREATE TABLE {$t['players']} (
				id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
				institution_id bigint(20) unsigned NOT NULL DEFAULT 0,
				user_id bigint(20) unsigned NULL,
				player_token_hash char(64) NOT NULL,
				nickname varchar(100) NOT NULL,
				student_code varchar(100) NOT NULL DEFAULT '',
				class_name varchar(100) NOT NULL DEFAULT '',
				avatar varchar(255) NOT NULL DEFAULT '',
				level int(10) unsigned NOT NULL DEFAULT 1,
				xp int(10) unsigned NOT NULL DEFAULT 0,
				created_at datetime NOT NULL,
				updated_at datetime NOT NULL,
				PRIMARY KEY (id),
				UNIQUE KEY token_hash (player_token_hash),
				KEY institution_id (institution_id),
				KEY user_id (user_id),
				KEY nickname (nickname),
				KEY institution_student (institution_id, student_code)
			) {$c};",

			"CREATE TABLE {$t['games']} (
				id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
				game_key varchar(60) NOT NULL,
				name varchar(150) NOT NULL,
				description text NULL,
				status varchar(20) NOT NULL DEFAULT 'active',
				settings longtext NULL,
				created_at datetime NOT NULL,
				updated_at datetime NOT NULL,
				PRIMARY KEY (id),
				UNIQUE KEY game_key (game_key),
				KEY status (status)
			) {$c};",

			"CREATE TABLE {$t['sessions']} (
				id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
				player_id bigint(20) unsigned NOT NULL,
				game_key varchar(60) NOT NULL,
				difficulty varchar(20) NOT NULL DEFAULT 'easy',
				status varchar(20) NOT NULL DEFAULT 'started',
				score int(11) NOT NULL DEFAULT 0,
				duration int(11) NOT NULL DEFAULT 0,
				mistakes int(11) NOT NULL DEFAULT 0,
				metadata longtext NULL,
				started_at datetime NOT NULL,
				completed_at datetime NULL,
				PRIMARY KEY (id),
				KEY player_id (player_id),
				KEY game_key (game_key),
				KEY status (status),
				KEY started_at (started_at)
			) {$c};",

			"CREATE TABLE {$t['progress']} (
				id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
				player_id bigint(20) unsigned NOT NULL,
				game_key varchar(60) NOT NULL,
				plays int(10) unsigned NOT NULL DEFAULT 0,
				completions int(10) unsigned NOT NULL DEFAULT 0,
				best_score int(11) NOT NULL DEFAULT 0,
				total_score int(11) NOT NULL DEFAULT 0,
				best_time int(10) unsigned NOT NULL DEFAULT 0,
				updated_at datetime NOT NULL,
				PRIMARY KEY (id),
				UNIQUE KEY player_game (player_id, game_key),
				KEY player_id (player_id)
			) {$c};",

			"CREATE TABLE {$t['achievements']} (
				id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
				achievement_key varchar(100) NOT NULL,
				title varchar(150) NOT NULL,
				description text NULL,
				xp_reward int(10) unsigned NOT NULL DEFAULT 0,
				created_at datetime NOT NULL,
				PRIMARY KEY (id),
				UNIQUE KEY achievement_key (achievement_key)
			) {$c};",

			"CREATE TABLE {$t['player_badges']} (
				id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
				player_id bigint(20) unsigned NOT NULL,
				achievement_key varchar(100) NOT NULL,
				earned_at datetime NOT NULL,
				PRIMARY KEY (id),
				UNIQUE KEY player_achievement (player_id, achievement_key),
				KEY player_id (player_id)
			) {$c};",
			"CREATE TABLE {$t['content']} (
				id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
				game_key varchar(60) NOT NULL,
				title varchar(200) NOT NULL,
				content longtext NOT NULL,
				difficulty varchar(20) NOT NULL DEFAULT 'easy',
				category varchar(100) NOT NULL DEFAULT '',
				status varchar(20) NOT NULL DEFAULT 'active',
				sort_order int(11) NOT NULL DEFAULT 0,
				image_url varchar(500) NOT NULL DEFAULT '',
				created_at datetime NOT NULL,
				updated_at datetime NOT NULL,
				PRIMARY KEY (id),
				KEY game_key (game_key),
				KEY difficulty (difficulty),
				KEY status (status),
				KEY sort_order (sort_order)
			) {$c};",
		);

		foreach ( $queries as $query ) {
			dbDelta( $query );
		}

		self::seed_games();
		self::seed_achievements();
		update_option( 'nkg_db_version', self::DB_VERSION );
	}

	public static function maybe_upgrade() {
		$version = get_option( 'nkg_db_version', '0.0.0' );
		if ( version_compare( $version, self::DB_VERSION, '<' ) ) {
			self::install();
		}
	}

	private static function seed_games() {
		global $wpdb;
		$t = self::tables();
		$games = array(
			'memory' => array(
				'name' => __( 'Memory Match', 'neo-kids-games' ),
				'description' => __( 'Find matching pairs of cards.', 'neo-kids-games' ),
				'settings' => array( 'difficulty' => array( 'easy', 'medium', 'hard' ), 'timer' => true ),
			),
			'quiz' => array(
				'name' => __( 'Quick Quiz', 'neo-kids-games' ),
				'description' => __( 'Answer short educational questions.', 'neo-kids-games' ),
				'settings' => array( 'difficulty' => array( 'easy', 'medium', 'hard' ), 'timer' => false ),
			),
		);

		foreach ( $games as $key => $game ) {
			$exists = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$t['games']} WHERE game_key = %s", $key ) );
			if ( ! $exists ) {
				$wpdb->insert(
					$t['games'],
					array(
						'game_key' => $key,
						'name' => $game['name'],
						'description' => $game['description'],
						'status' => 'active',
						'settings' => wp_json_encode( $game['settings'] ),
						'created_at' => current_time( 'mysql' ),
						'updated_at' => current_time( 'mysql' ),
					),
					array( '%s', '%s', '%s', '%s', '%s', '%s', '%s' )
				);
			}
		}
	}

	private static function seed_achievements() {
		global $wpdb;
		$t = self::tables();
		$items = array(
			array( 'first_game', __( 'First Game', 'neo-kids-games' ), __( 'Complete your first game.', 'neo-kids-games' ), 25 ),
			array( 'five_games', __( 'Game Explorer', 'neo-kids-games' ), __( 'Complete five games.', 'neo-kids-games' ), 50 ),
			array( 'perfect_score', __( 'Perfect Score', 'neo-kids-games' ), __( 'Finish a game with a perfect score.', 'neo-kids-games' ), 50 ),
		);
		foreach ( $items as $item ) {
			$exists = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$t['achievements']} WHERE achievement_key = %s", $item[0] ) );
			if ( ! $exists ) {
				$wpdb->insert(
					$t['achievements'],
					array(
						'achievement_key' => $item[0],
						'title' => $item[1],
						'description' => $item[2],
						'xp_reward' => $item[3],
						'created_at' => current_time( 'mysql' ),
					),
					array( '%s', '%s', '%s', '%d', '%s' )
				);
			}
		}
	}

	public static function deactivate() {
		// Data is intentionally preserved on deactivation.
	}
}
