<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

class NKG_Frontend {
	public static function init() {
		add_shortcode( 'nkg_game', array( __CLASS__, 'game_shortcode' ) );
		add_shortcode( 'nkg_player_profile', array( __CLASS__, 'profile_shortcode' ) );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'register_assets' ) );
		wp_register_script( 'nkg-engine-event-bus', NKG_URL . 'engine/core/class-event-bus.js', array(), NKG_VERSION, true );
		wp_register_script( 'nkg-engine-state', NKG_URL . 'engine/core/class-game-state.js', array(), NKG_VERSION, true );
		wp_register_script( 'nkg-engine-entities', NKG_URL . 'engine/core/class-entity-manager.js', array(), NKG_VERSION, true );
		wp_register_script( 'nkg-engine-scenes', NKG_URL . 'engine/core/class-scene-manager.js', array(), NKG_VERSION, true );
		wp_register_script( 'nkg-engine-scene', NKG_URL . 'engine/core/class-scene.js', array(), NKG_VERSION, true );
		wp_register_script( 'nkg-engine-system-manager', NKG_URL . 'engine/core/class-system-manager.js', array(), NKG_VERSION, true );
		wp_register_script( 'nkg-engine-collision', NKG_URL . 'engine/core/class-collision.js', array(), NKG_VERSION, true );
		wp_register_script( 'nkg-engine-assets', NKG_URL . 'engine/core/class-asset-manager.js', array(), NKG_VERSION, true );
		wp_register_script( 'nkg-engine-input', NKG_URL . 'engine/systems/class-input-system.js', array(), NKG_VERSION, true );
		wp_register_script( 'nkg-engine-audio', NKG_URL . 'engine/systems/class-audio-system.js', array(), NKG_VERSION, true );
		wp_register_script( 'nkg-engine-render', NKG_URL . 'engine/systems/class-render-system.js', array(), NKG_VERSION, true );
		wp_register_script( 'nkg-engine-application', NKG_URL . 'engine/class-game-application.js', array(), NKG_VERSION, true );
		wp_register_script( 'nkg-engine-module-registry', NKG_URL . 'engine/class-game-module-registry.js', array(), NKG_VERSION, true );
		wp_register_script(
			'nkg-engine',
			NKG_URL . 'engine/class-game-engine.js',
			array( 'nkg-engine-event-bus', 'nkg-engine-state', 'nkg-engine-entities', 'nkg-engine-scenes', 'nkg-engine-scene', 'nkg-engine-system-manager', 'nkg-engine-collision', 'nkg-engine-assets', 'nkg-engine-render', 'nkg-engine-input', 'nkg-engine-audio', 'nkg-engine-application', 'nkg-engine-module-registry' ),
			NKG_VERSION,
			true
		);

	}

	public static function register_assets() {
		wp_register_style( 'nkg-games', NKG_URL . 'assets/css/games.css', array(), NKG_VERSION );
		wp_register_script( 'nkg-games', NKG_URL . 'assets/js/games.js', array( 'nkg-engine' ), NKG_VERSION, true );
		wp_localize_script(
			'nkg-games',
			'NKG_DATA',
			array(
				'restUrl' => esc_url_raw( rest_url( 'nkg/v1/' ) ),
				'nonce' => wp_create_nonce( 'wp_rest' ),
			)
		);
	}

	public static function game_shortcode( $atts ) {
		$atts = shortcode_atts(
			array( 'type' => 'memory', 'difficulty' => 'easy' ),
			$atts,
			'nkg_game'
		);
		$key = sanitize_key( $atts['type'] );
		$game = NKG_Game_Registry::get( $key );
		if ( ! $game ) { return ''; }

		$difficulty = sanitize_key( $atts['difficulty'] );
		if ( ! in_array( $difficulty, $game->get_difficulties(), true ) ) { $difficulty = 'easy'; }

		wp_enqueue_style( 'nkg-games' );
		wp_enqueue_script( 'nkg-engine' );
		wp_enqueue_script( 'nkg-games' );
		wp_enqueue_script( 'nkg-engine-memory', NKG_URL . 'engine/games/class-memory-game.js', array( 'nkg-engine' ), NKG_VERSION, true );
		wp_enqueue_script( 'nkg-engine-quiz', NKG_URL . 'engine/games/class-quiz-game.js', array( 'nkg-engine' ), NKG_VERSION, true );

		ob_start();
		?>
		<section class="nkg-game" data-nkg-game="<?php echo esc_attr( $key ); ?>" data-nkg-difficulty="<?php echo esc_attr( $difficulty ); ?>">
			<header class="nkg-game__header">
				<div>
					<h3 class="nkg-game__title"><?php echo esc_html( $game->get_name() ); ?></h3>
					<p><?php echo esc_html( $game->get_description() ); ?></p>
				</div>
				<div class="nkg-game__score" aria-live="polite">0</div>
			</header>

			<div class="nkg-player-start">
				<p class="nkg-profile-required"><?php esc_html_e( 'A player profile is required before you can play.', 'neo-kids-games' ); ?></p>
				<div class="nkg-player-start__row">
					<button class="nkg-button nkg-start" type="button" disabled><?php esc_html_e( 'Start Game', 'neo-kids-games' ); ?></button>
				</div>
				<p class="nkg-message" aria-live="polite"></p>
			</div>

			<div class="nkg-engine-runtime" aria-hidden="true"></div>
			<div class="nkg-board" hidden></div>
			<div class="nkg-result" hidden aria-live="polite"></div>
		</section>
		<?php
		return ob_get_clean();
	}

	public static function profile_shortcode() {
		wp_enqueue_style( 'nkg-games' );
		wp_enqueue_script( 'nkg-games' );
		ob_start();
		?>
		<section class="nkg-profile" data-nkg-profile>
			<h3><?php esc_html_e( 'Player Profile', 'neo-kids-games' ); ?></h3>
			<div class="nkg-profile__create">
				<p><?php esc_html_e( 'First enter your institution code. Your game profile belongs to your institution.', 'neo-kids-games' ); ?></p>
				<div class="nkg-profile__create-row">
					<label class="screen-reader-text" for="nkg-institution-code"><?php esc_html_e( 'Institution code', 'neo-kids-games' ); ?></label>
					<input id="nkg-institution-code" class="nkg-institution-code" maxlength="60" type="text" autocomplete="organization" placeholder="<?php echo esc_attr__( 'Institution code', 'neo-kids-games' ); ?>">
					<button class="nkg-button nkg-find-institution" type="button"><?php esc_html_e( 'Find Institution', 'neo-kids-games' ); ?></button>
				</div>
				<div class="nkg-institution-confirm" hidden>
					<strong class="nkg-institution-name"></strong>
					<span class="nkg-institution-code-label"></span>
				</div>
				<div class="nkg-student-fields" hidden>
					<p><?php esc_html_e( 'Now create your student profile.', 'neo-kids-games' ); ?></p>
					<div class="nkg-profile__create-row">
						<label class="screen-reader-text" for="nkg-profile-name"><?php esc_html_e( 'Player name', 'neo-kids-games' ); ?></label>
						<input id="nkg-profile-name" class="nkg-profile-name" maxlength="100" type="text" autocomplete="nickname" placeholder="<?php echo esc_attr__( 'Student name', 'neo-kids-games' ); ?>">
						<label class="screen-reader-text" for="nkg-student-code"><?php esc_html_e( 'Student ID', 'neo-kids-games' ); ?></label>
						<input id="nkg-student-code" class="nkg-student-code" maxlength="100" type="text" placeholder="<?php echo esc_attr__( 'Student ID', 'neo-kids-games' ); ?>">
						<select id="nkg-class-name" class="nkg-class-name"><option value=""><?php esc_html_e( 'Select class', 'neo-kids-games' ); ?></option></select>
						<button class="nkg-button nkg-create-profile" type="button"><?php esc_html_e( 'Create Profile', 'neo-kids-games' ); ?></button>
					</div>
				</div>
				<p class="nkg-profile__message nkg-message" aria-live="polite"></p>
			</div>
			<div class="nkg-profile__empty" hidden><?php esc_html_e( 'Create a profile above to start playing.', 'neo-kids-games' ); ?></div>
			<div class="nkg-profile__content" hidden>
				<div class="nkg-profile__identity">
					<strong class="nkg-profile__name"></strong>
					<span class="nkg-profile__institution"></span>
					<span class="nkg-profile__class"></span>
					<span class="nkg-profile__level"></span>
				</div>
				<div class="nkg-profile__stats">
					<div><strong class="nkg-xp">0</strong><span>XP</span></div>
					<div><strong class="nkg-played">0</strong><span><?php esc_html_e( 'Games', 'neo-kids-games' ); ?></span></div>
					<div><strong class="nkg-completed">0</strong><span><?php esc_html_e( 'Completed', 'neo-kids-games' ); ?></span></div>
					<div><strong class="nkg-score">0</strong><span><?php esc_html_e( 'Score', 'neo-kids-games' ); ?></span></div>
				</div>
				<h4><?php esc_html_e( 'Achievements', 'neo-kids-games' ); ?></h4>
				<div class="nkg-badges"></div>
				<h4><?php esc_html_e( 'Recent Games', 'neo-kids-games' ); ?></h4>
				<div class="nkg-recent"></div>
			</div>
		</section>
		<?php
		return ob_get_clean();
	}
	public static function institution_dashboard_shortcode() {
		wp_enqueue_style( 'nkg-games' );
		wp_enqueue_script( 'nkg-engine' );
		wp_enqueue_script( 'nkg-games' );
		ob_start();
		?>
		<section class="nkg-institution-dashboard" data-nkg-institution-dashboard>
			<h3><?php esc_html_e( 'Institution Game Dashboard', 'neo-kids-games' ); ?></h3>
			<div class="nkg-assignment-list">
				<p><?php esc_html_e( 'Your assigned games will appear here after your institution is verified.', 'neo-kids-games' ); ?></p>
			</div>
		</section>
		<?php
		return ob_get_clean();
	}

}
