<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

class NKG_Admin {
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_init', array( __CLASS__, 'settings' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
	}

	public static function menu() {
		add_menu_page( __( 'Kids Games', 'neo-kids-games' ), __( 'Kids Games', 'neo-kids-games' ), 'manage_options', 'nkg-dashboard', array( __CLASS__, 'dashboard' ), 'dashicons-games', 25 );
		add_submenu_page( 'nkg-dashboard', __( 'Games', 'neo-kids-games' ), __( 'Games', 'neo-kids-games' ), 'manage_options', 'nkg-games', array( __CLASS__, 'games' ) );
		add_submenu_page( 'nkg-dashboard', __( 'Institutions', 'neo-kids-games' ), __( 'Institutions', 'neo-kids-games' ), 'manage_options', 'nkg-institutions', array( __CLASS__, 'institutions' ) );
		add_submenu_page( 'nkg-dashboard', __( 'Assignments', 'neo-kids-games' ), __( 'Assignments', 'neo-kids-games' ), 'manage_options', 'nkg-assignments', array( __CLASS__, 'assignments' ) );
		add_submenu_page( 'nkg-dashboard', __( 'Teachers', 'neo-kids-games' ), __( 'Teachers', 'neo-kids-games' ), 'manage_options', 'nkg-teachers', array( __CLASS__, 'teachers' ) );
		add_submenu_page( 'nkg-dashboard', __( 'Players', 'neo-kids-games' ), __( 'Players', 'neo-kids-games' ), 'manage_options', 'nkg-players', array( __CLASS__, 'players' ) );
		add_submenu_page( 'nkg-dashboard', __( 'Content Builder', 'neo-kids-games' ), __( 'Content Builder', 'neo-kids-games' ), 'manage_options', 'nkg-content', array( __CLASS__, 'content' ) );
		add_submenu_page( 'nkg-dashboard', __( 'Settings', 'neo-kids-games' ), __( 'Settings', 'neo-kids-games' ), 'manage_options', 'nkg-settings', array( __CLASS__, 'settings_page' ) );
	}

	public static function assets( $hook ) {
		if ( false === strpos( $hook, 'nkg-content' ) ) {
			return;
		}
		wp_enqueue_media();
		wp_register_style( 'nkg-admin', NKG_URL . 'assets/css/admin.css', array(), NKG_VERSION );
		wp_enqueue_style( 'nkg-admin' );
		wp_register_script( 'nkg-admin', NKG_URL . 'assets/js/admin-content.js', array( 'jquery' ), NKG_VERSION, true );
		wp_enqueue_script( 'nkg-admin' );
	}

	public static function settings() {
		register_setting(
			'nkg_settings',
			'nkg_settings',
			array(
				'type' => 'array',
				'sanitize_callback' => function( $value ) {
					return array(
						'sound' => ! empty( $value['sound'] ) ? 1 : 0,
						'default_difficulty' => isset( $value['default_difficulty'] ) ? sanitize_key( $value['default_difficulty'] ) : 'easy',
					);
				},
				'default' => array( 'sound' => 1, 'default_difficulty' => 'easy' ),
			)
		);
	}

	public static function dashboard() {
		global $wpdb;
		$t = NKG_Database::tables();
		$players = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$t['players']}" );
		$sessions = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$t['sessions']}" );
		$completed = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$t['sessions']} WHERE status = 'completed'" );
		$content = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$t['content']}" );
		$institutions = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$t['institutions']}" );
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Neo Kids Interactive Games', 'neo-kids-games' ); ?></h1>
			<p><?php esc_html_e( 'Game engine dashboard.', 'neo-kids-games' ); ?></p>
			<div class="nkg-admin-stats">
				<div><strong><?php echo esc_html( $players ); ?></strong><span><?php esc_html_e( 'Players', 'neo-kids-games' ); ?></span></div>
				<div><strong><?php echo esc_html( $sessions ); ?></strong><span><?php esc_html_e( 'Sessions', 'neo-kids-games' ); ?></span></div>
				<div><strong><?php echo esc_html( $completed ); ?></strong><span><?php esc_html_e( 'Completed', 'neo-kids-games' ); ?></span></div>
				<div><strong><?php echo esc_html( $content ); ?></strong><span><?php esc_html_e( 'Content Items', 'neo-kids-games' ); ?></span></div>
				<div><strong><?php echo esc_html( $institutions ); ?></strong><span><?php esc_html_e( 'Institutions', 'neo-kids-games' ); ?></span></div>
			</div>
			<h2><?php esc_html_e( 'Embedding', 'neo-kids-games' ); ?></h2>
			<p><code>[nkg_game type="memory" difficulty="easy"]</code></p>
			<p><code>[nkg_game type="quiz" difficulty="medium"]</code></p>
			<p><code>[nkg_player_profile]</code></p>
		</div>
		<?php
	}

	public static function games() {
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Game Library', 'neo-kids-games' ); ?></h1>
			<table class="widefat striped">
				<thead><tr><th><?php esc_html_e( 'Game', 'neo-kids-games' ); ?></th><th><?php esc_html_e( 'Description', 'neo-kids-games' ); ?></th><th><?php esc_html_e( 'Difficulties', 'neo-kids-games' ); ?></th></tr></thead>
				<tbody>
				<?php foreach ( NKG_Game_Registry::all() as $game ) : ?>
					<tr>
						<td><strong><?php echo esc_html( $game->get_name() ); ?></strong><br><code><?php echo esc_html( $game->get_key() ); ?></code></td>
						<td><?php echo esc_html( $game->get_description() ); ?></td>
						<td><?php echo esc_html( implode( ', ', $game->get_difficulties() ) ); ?></td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
		</div>
		<?php
	}

	public static function institutions() {
		if ( ! current_user_can( 'manage_options' ) ) { return; }
		$message = '';
		if ( isset( $_POST['nkg_institution_action'] ) && 'create' === sanitize_key( wp_unslash( $_POST['nkg_institution_action'] ) ) ) {
			check_admin_referer( 'nkg_create_institution' );
			$result = NKG_Institution::create(
				array(
					'name' => wp_unslash( $_POST['name'] ?? '' ),
					'code' => wp_unslash( $_POST['code'] ?? '' ),
					'contact_name' => wp_unslash( $_POST['contact_name'] ?? '' ),
					'contact_email' => wp_unslash( $_POST['contact_email'] ?? '' ),
					'classes' => wp_unslash( $_POST['classes'] ?? '' ),
				)
			);
			$message = is_wp_error( $result ) ? $result->get_error_message() : __( 'Institution created.', 'neo-kids-games' );
		}
		if ( isset( $_GET['toggle'] ) ) {
			$id = absint( $_GET['toggle'] );
			check_admin_referer( 'nkg_toggle_institution_' . $id );
			$item = NKG_Institution::get( $id );
			if ( $item ) {
				NKG_Institution::update_status( $id, 'active' === $item['status'] ? 'inactive' : 'active' );
				$message = __( 'Institution status updated.', 'neo-kids-games' );
			}
		}
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Institutions', 'neo-kids-games' ); ?></h1>
			<p class="description"><?php esc_html_e( 'Create an institution first. Students must verify its code before they can create a player profile or play games.', 'neo-kids-games' ); ?></p>
			<?php if ( $message ) : ?><div class="notice notice-info is-dismissible"><p><?php echo esc_html( $message ); ?></p></div><?php endif; ?>
			<div class="nkg-builder-card">
				<h2><?php esc_html_e( 'Add Institution', 'neo-kids-games' ); ?></h2>
				<form method="post">
					<?php wp_nonce_field( 'nkg_create_institution' ); ?>
					<input type="hidden" name="nkg_institution_action" value="create">
					<table class="form-table">
						<tr><th><label for="nkg-inst-name"><?php esc_html_e( 'Institution name', 'neo-kids-games' ); ?></label></th><td><input id="nkg-inst-name" class="regular-text" name="name" required placeholder="Sunrise Academy"></td></tr>
						<tr><th><label for="nkg-inst-code"><?php esc_html_e( 'Institution code', 'neo-kids-games' ); ?></label></th><td><input id="nkg-inst-code" class="regular-text" name="code" required placeholder="SUNRISE01"><p class="description"><?php esc_html_e( 'Give this code to students. Keep it short and unique.', 'neo-kids-games' ); ?></p></td></tr>
						<tr><th><?php esc_html_e( 'Contact', 'neo-kids-games' ); ?></th><td><input class="regular-text" name="contact_name" placeholder="Coordinator name"><br><br><input class="regular-text" type="email" name="contact_email" placeholder="coordinator@example.com"></td></tr>
						<tr><th><label for="nkg-inst-classes"><?php esc_html_e( 'Classes / groups', 'neo-kids-games' ); ?></label></th><td><textarea id="nkg-inst-classes" class="large-text" name="classes" rows="4" placeholder="Grade 1&#10;Grade 2&#10;Grade 3"></textarea><p class="description"><?php esc_html_e( 'One class per line or separate with commas.', 'neo-kids-games' ); ?></p></td></tr>
					</table>
					<?php submit_button( __( 'Create Institution', 'neo-kids-games' ) ); ?>
				</form>
			</div>
			<div class="nkg-builder-card">
				<h2><?php esc_html_e( 'Institution Directory', 'neo-kids-games' ); ?></h2>
				<table class="widefat striped">
					<thead><tr><th><?php esc_html_e( 'Institution', 'neo-kids-games' ); ?></th><th><?php esc_html_e( 'Code', 'neo-kids-games' ); ?></th><th><?php esc_html_e( 'Classes', 'neo-kids-games' ); ?></th><th><?php esc_html_e( 'Status', 'neo-kids-games' ); ?></th><th><?php esc_html_e( 'Action', 'neo-kids-games' ); ?></th></tr></thead>
					<tbody>
					<?php foreach ( NKG_Institution::all() as $item ) : ?>
						<tr>
							<td><strong><?php echo esc_html( $item['name'] ); ?></strong><br><?php echo esc_html( $item['contact_name'] ); ?></td>
							<td><code><?php echo esc_html( $item['code'] ); ?></code></td>
							<td><?php echo esc_html( implode( ', ', $item['classes'] ) ); ?></td>
							<td><?php echo 'active' === $item['status'] ? esc_html__( 'Active', 'neo-kids-games' ) : esc_html__( 'Inactive', 'neo-kids-games' ); ?></td>
							<td><a class="button button-small" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin.php?page=nkg-institutions&toggle=' . absint( $item['id'] ) ), 'nkg_toggle_institution_' . absint( $item['id'] ) ) ); ?>"><?php echo 'active' === $item['status'] ? esc_html__( 'Deactivate', 'neo-kids-games' ) : esc_html__( 'Activate', 'neo-kids-games' ); ?></a></td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
			</div>
		</div>
		<?php
	}

	public static function players() {
		global $wpdb;
		$t = NKG_Database::tables();
		$rows = $wpdb->get_results( "SELECT id, institution_id, nickname, student_code, class_name, level, xp, created_at FROM {$t['players']} ORDER BY id DESC LIMIT 100", ARRAY_A );
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Players', 'neo-kids-games' ); ?></h1>
			<table class="widefat striped">
				<thead><tr><th>ID</th><th><?php esc_html_e( 'Institution', 'neo-kids-games' ); ?></th><th><?php esc_html_e( 'Student', 'neo-kids-games' ); ?></th><th><?php esc_html_e( 'Level', 'neo-kids-games' ); ?></th><th>XP</th><th><?php esc_html_e( 'Created', 'neo-kids-games' ); ?></th></tr></thead>
				<tbody>
				<?php foreach ( $rows as $row ) : ?>
					<tr>
						<td><?php echo esc_html( $row['id'] ); ?></td>
						<td><?php $inst = NKG_Institution::get( $row['institution_id'] ); echo $inst ? esc_html( $inst['name'] ) : esc_html__( 'Unknown', 'neo-kids-games' ); ?></td>
						<td><?php echo esc_html( $row['nickname'] ); ?><br><small><?php echo esc_html( $row['student_code'] ); ?><?php echo $row['class_name'] ? ' · ' . esc_html( $row['class_name'] ) : ''; ?></small></td>
						<td><?php echo esc_html( $row['level'] ); ?></td>
						<td><?php echo esc_html( $row['xp'] ); ?></td>
						<td><?php echo esc_html( $row['created_at'] ); ?></td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
		</div>
		<?php
	}

	public static function content() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$editing_id = isset( $_GET['edit'] ) ? absint( $_GET['edit'] ) : 0;
		$editing = $editing_id ? NKG_Content::get( $editing_id ) : null;
		$message = '';

		if ( isset( $_POST['nkg_content_action'] ) ) {
			$action = sanitize_key( wp_unslash( $_POST['nkg_content_action'] ) );
			if ( 'save' === $action ) {
				check_admin_referer( 'nkg_save_content' );
				$answers_raw = isset( $_POST['answers'] ) && is_array( $_POST['answers'] ) ? wp_unslash( $_POST['answers'] ) : array();
				$answers = array();
				foreach ( $answers_raw as $answer ) {
					$answer = sanitize_text_field( $answer );
					if ( '' !== $answer ) {
						$answers[] = $answer;
					}
				}
				$correct = isset( $_POST['correct'] ) ? absint( $_POST['correct'] ) : 0;
				if ( $correct >= count( $answers ) ) {
					$correct = 0;
				}

				$data = array(
					'game_key'   => isset( $_POST['game_key'] ) ? sanitize_key( wp_unslash( $_POST['game_key'] ) ) : '',
					'title'      => isset( $_POST['title'] ) ? sanitize_text_field( wp_unslash( $_POST['title'] ) ) : '',
					'difficulty' => isset( $_POST['difficulty'] ) ? sanitize_key( wp_unslash( $_POST['difficulty'] ) ) : 'easy',
					'category'   => isset( $_POST['category'] ) ? sanitize_text_field( wp_unslash( $_POST['category'] ) ) : '',
					'status'     => isset( $_POST['status'] ) ? sanitize_key( wp_unslash( $_POST['status'] ) ) : 'draft',
					'sort_order' => isset( $_POST['sort_order'] ) ? intval( $_POST['sort_order'] ) : 0,
					'image_url'  => isset( $_POST['image_url'] ) ? esc_url_raw( wp_unslash( $_POST['image_url'] ) ) : '',
					'content'    => array(
						'question' => isset( $_POST['question'] ) ? sanitize_textarea_field( wp_unslash( $_POST['question'] ) ) : '',
						'answers'  => array_values( $answers ),
						'correct'  => $correct,
					),
				);
				$id = isset( $_POST['content_id'] ) ? absint( $_POST['content_id'] ) : 0;
				if ( NKG_Game_Registry::get( $data['game_key'] ) && $data['title'] && $data['content']['question'] && count( $data['content']['answers'] ) >= 2 ) {
					$saved = NKG_Content::save( $data, $id );
					$message = $saved ? __( 'Content item saved.', 'neo-kids-games' ) : __( 'Could not save content.', 'neo-kids-games' );
					if ( $saved ) {
						$editing = NKG_Content::get( $saved );
						$editing_id = $saved;
					}
				} else {
					$message = __( 'Choose a valid game and provide a title, question, and at least two answers.', 'neo-kids-games' );
				}
			} elseif ( 'duplicate' === $action ) {
				check_admin_referer( 'nkg_duplicate_content' );
				$id = absint( $_POST['content_id'] ?? 0 );
				$item = NKG_Content::get( $id );
				if ( $item ) {
					unset( $item['id'], $item['created_at'], $item['updated_at'] );
					$item['title'] .= ' (Copy)';
					$item['status'] = 'draft';
					$copy_id = NKG_Content::save( $item );
					$message = $copy_id ? __( 'Content duplicated as a draft.', 'neo-kids-games' ) : __( 'Could not duplicate content.', 'neo-kids-games' );
				}
			}
		}

		if ( isset( $_GET['delete'] ) ) {
			$id = absint( $_GET['delete'] );
			check_admin_referer( 'nkg_delete_content_' . $id );
			NKG_Content::delete( $id );
			$message = __( 'Content item deleted.', 'neo-kids-games' );
			$editing = null;
			$editing_id = 0;
		}

		if ( isset( $_GET['toggle'] ) ) {
			$id = absint( $_GET['toggle'] );
			check_admin_referer( 'nkg_toggle_content_' . $id );
			$item = NKG_Content::get( $id );
			if ( $item ) {
				NKG_Content::set_status( $id, 'active' === $item['status'] ? 'draft' : 'active' );
				$message = __( 'Content status updated.', 'neo-kids-games' );
			}
		}

		$filter_game = isset( $_GET['game_filter'] ) ? sanitize_key( wp_unslash( $_GET['game_filter'] ) ) : '';
		$filter_status = isset( $_GET['status_filter'] ) ? sanitize_key( wp_unslash( $_GET['status_filter'] ) ) : '';
		$items = NKG_Content::all( $filter_game, $filter_status );
		$edit_content = $editing['content'] ?? array();
		$edit_answers = ! empty( $edit_content['answers'] ) && is_array( $edit_content['answers'] ) ? $edit_content['answers'] : array( '', '', '' );
		?>
		<div class="wrap nkg-builder">
			<h1><?php esc_html_e( 'Content Builder', 'neo-kids-games' ); ?></h1>
			<p class="description"><?php esc_html_e( 'Create, edit, duplicate, reorder, categorize, image-tag, and publish game content. All content is stored in the plugin custom table.', 'neo-kids-games' ); ?></p>
			<?php if ( $message ) : ?><div class="notice notice-success is-dismissible"><p><?php echo esc_html( $message ); ?></p></div><?php endif; ?>

			<div class="nkg-builder-grid">
				<div class="nkg-builder-card">
					<div class="nkg-card-head">
						<h2><?php echo $editing_id ? esc_html__( 'Edit Content', 'neo-kids-games' ) : esc_html__( 'Create Content', 'neo-kids-games' ); ?></h2>
						<?php if ( $editing_id ) : ?><a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=nkg-content' ) ); ?>"><?php esc_html_e( 'New Item', 'neo-kids-games' ); ?></a><?php endif; ?>
					</div>
					<form method="post" id="nkg-content-form">
						<?php wp_nonce_field( 'nkg_save_content' ); ?>
						<input type="hidden" name="nkg_content_action" value="save">
						<input type="hidden" name="content_id" value="<?php echo esc_attr( $editing_id ); ?>">
						<div class="nkg-form-grid">
							<p><label><?php esc_html_e( 'Game', 'neo-kids-games' ); ?></label>
								<select name="game_key" required>
									<?php foreach ( NKG_Game_Registry::all() as $game ) : ?>
										<option value="<?php echo esc_attr( $game->get_key() ); ?>" <?php selected( $editing['game_key'] ?? 'quiz', $game->get_key() ); ?>><?php echo esc_html( $game->get_name() ); ?></option>
									<?php endforeach; ?>
								</select>
							</p>
							<p><label><?php esc_html_e( 'Difficulty', 'neo-kids-games' ); ?></label>
								<select name="difficulty">
									<?php foreach ( array( 'easy', 'medium', 'hard' ) as $difficulty ) : ?>
										<option value="<?php echo esc_attr( $difficulty ); ?>" <?php selected( $editing['difficulty'] ?? 'easy', $difficulty ); ?>><?php echo esc_html( ucfirst( $difficulty ) ); ?></option>
									<?php endforeach; ?>
								</select>
							</p>
							<p class="nkg-wide"><label><?php esc_html_e( 'Title', 'neo-kids-games' ); ?></label><input class="widefat" name="title" value="<?php echo esc_attr( $editing['title'] ?? '' ); ?>" required></p>
							<p class="nkg-wide"><label><?php esc_html_e( 'Question', 'neo-kids-games' ); ?></label><textarea class="widefat" name="question" rows="4" required><?php echo esc_textarea( $edit_content['question'] ?? '' ); ?></textarea></p>
							<div class="nkg-wide">
								<label><?php esc_html_e( 'Answers', 'neo-kids-games' ); ?></label>
								<div id="nkg-answer-list">
								<?php foreach ( $edit_answers as $index => $answer ) : ?>
									<div class="nkg-answer-row">
										<span class="nkg-drag">☷</span>
										<input class="widefat" name="answers[]" value="<?php echo esc_attr( $answer ); ?>" placeholder="<?php echo esc_attr( sprintf( __( 'Answer %d', 'neo-kids-games' ), $index + 1 ) ); ?>">
										<button type="button" class="button-link-delete nkg-remove-answer" aria-label="<?php esc_attr_e( 'Remove answer', 'neo-kids-games' ); ?>">×</button>
									</div>
								<?php endforeach; ?>
								</div>
								<button type="button" class="button" id="nkg-add-answer"><?php esc_html_e( '+ Add Answer', 'neo-kids-games' ); ?></button>
							</div>
							<p><label><?php esc_html_e( 'Correct answer', 'neo-kids-games' ); ?></label>
								<select name="correct" id="nkg-correct">
									<?php foreach ( $edit_answers as $index => $answer ) : ?><option value="<?php echo esc_attr( $index ); ?>" <?php selected( absint( $edit_content['correct'] ?? 0 ), $index ); ?>><?php echo esc_html( sprintf( __( 'Answer %d', 'neo-kids-games' ), $index + 1 ) ); ?></option><?php endforeach; ?>
								</select>
							</p>
							<p><label><?php esc_html_e( 'Category', 'neo-kids-games' ); ?></label><input class="widefat" name="category" value="<?php echo esc_attr( $editing['category'] ?? '' ); ?>" placeholder="Animals"></p>
							<p><label><?php esc_html_e( 'Order', 'neo-kids-games' ); ?></label><input class="small-text" type="number" name="sort_order" value="<?php echo esc_attr( $editing['sort_order'] ?? 0 ); ?>"><span class="description"><?php esc_html_e( 'Lower appears first.', 'neo-kids-games' ); ?></span></p>
							<p class="nkg-wide"><label><?php esc_html_e( 'Image URL', 'neo-kids-games' ); ?></label>
								<div class="nkg-image-row">
									<input class="widefat" id="nkg-image-url" name="image_url" value="<?php echo esc_attr( $editing['image_url'] ?? '' ); ?>" placeholder="https://example.com/image.jpg">
									<button type="button" class="button" id="nkg-select-image"><?php esc_html_e( 'Choose Image', 'neo-kids-games' ); ?></button>
								</div>
								<?php if ( ! empty( $editing['image_url'] ) ) : ?><img class="nkg-image-preview" src="<?php echo esc_url( $editing['image_url'] ); ?>" alt=""><?php endif; ?>
							</p>
							<p><label><?php esc_html_e( 'Status', 'neo-kids-games' ); ?></label>
								<select name="status"><option value="active" <?php selected( $editing['status'] ?? 'draft', 'active' ); ?>><?php esc_html_e( 'Published', 'neo-kids-games' ); ?></option><option value="draft" <?php selected( $editing['status'] ?? 'draft', 'draft' ); ?>><?php esc_html_e( 'Draft', 'neo-kids-games' ); ?></option></select>
							</p>
						</div>
						<?php submit_button( $editing_id ? __( 'Update Content', 'neo-kids-games' ) : __( 'Create Content', 'neo-kids-games' ), 'primary', 'submit', false ); ?>
					</form>
				</div>

				<div class="nkg-builder-card nkg-preview-card">
					<h2><?php esc_html_e( 'Live Preview', 'neo-kids-games' ); ?></h2>
					<div class="nkg-preview">
						<div class="nkg-preview-image" id="nkg-preview-image"></div>
						<div class="nkg-preview-category" id="nkg-preview-category"></div>
						<h3 id="nkg-preview-title"><?php echo esc_html( $editing['title'] ?? __( 'Untitled Question', 'neo-kids-games' ) ); ?></h3>
						<p id="nkg-preview-question"><?php echo esc_html( $edit_content['question'] ?? __( 'Your question will appear here.', 'neo-kids-games' ) ); ?></p>
						<div id="nkg-preview-answers"></div>
					</div>
				</div>
			</div>

			<div class="nkg-builder-card nkg-library-card">
				<div class="nkg-card-head">
					<h2><?php esc_html_e( 'Content Library', 'neo-kids-games' ); ?></h2>
					<form method="get" class="nkg-filters">
						<input type="hidden" name="page" value="nkg-content">
						<select name="game_filter"><option value=""><?php esc_html_e( 'All games', 'neo-kids-games' ); ?></option><?php foreach ( NKG_Game_Registry::all() as $game ) : ?><option value="<?php echo esc_attr( $game->get_key() ); ?>" <?php selected( $filter_game, $game->get_key() ); ?>><?php echo esc_html( $game->get_name() ); ?></option><?php endforeach; ?></select>
						<select name="status_filter"><option value=""><?php esc_html_e( 'All statuses', 'neo-kids-games' ); ?></option><option value="active" <?php selected( $filter_status, 'active' ); ?>><?php esc_html_e( 'Published', 'neo-kids-games' ); ?></option><option value="draft" <?php selected( $filter_status, 'draft' ); ?>><?php esc_html_e( 'Draft', 'neo-kids-games' ); ?></option></select>
						<button class="button"><?php esc_html_e( 'Filter', 'neo-kids-games' ); ?></button>
					</form>
				</div>
				<table class="widefat striped nkg-content-table">
					<thead><tr><th><?php esc_html_e( 'Preview', 'neo-kids-games' ); ?></th><th><?php esc_html_e( 'Content', 'neo-kids-games' ); ?></th><th><?php esc_html_e( 'Game', 'neo-kids-games' ); ?></th><th><?php esc_html_e( 'Difficulty', 'neo-kids-games' ); ?></th><th><?php esc_html_e( 'Order', 'neo-kids-games' ); ?></th><th><?php esc_html_e( 'Status', 'neo-kids-games' ); ?></th><th><?php esc_html_e( 'Actions', 'neo-kids-games' ); ?></th></tr></thead>
					<tbody>
					<?php if ( ! $items ) : ?><tr><td colspan="7"><?php esc_html_e( 'No content items found.', 'neo-kids-games' ); ?></td></tr><?php endif; ?>
					<?php foreach ( $items as $item ) :
						$data = NKG_Content::decode( $item );
						$game = NKG_Game_Registry::get( $item['game_key'] );
						$toggle_url = wp_nonce_url( admin_url( 'admin.php?page=nkg-content&toggle=' . absint( $item['id'] ) ), 'nkg_toggle_content_' . absint( $item['id'] ) );
						$delete_url = wp_nonce_url( admin_url( 'admin.php?page=nkg-content&delete=' . absint( $item['id'] ) ), 'nkg_delete_content_' . absint( $item['id'] ) );
						?>
						<tr>
							<td><?php if ( ! empty( $item['image_url'] ) ) : ?><img class="nkg-table-thumb" src="<?php echo esc_url( $item['image_url'] ); ?>" alt=""><?php else : ?><span class="nkg-table-placeholder">?</span><?php endif; ?></td>
							<td><strong><?php echo esc_html( $item['title'] ); ?></strong><p><?php echo esc_html( wp_trim_words( $data['content']['question'] ?? '', 14 ) ); ?></p><?php if ( $item['category'] ) : ?><span class="nkg-tag"><?php echo esc_html( $item['category'] ); ?></span><?php endif; ?></td>
							<td><?php echo $game ? esc_html( $game->get_name() ) : esc_html( $item['game_key'] ); ?></td>
							<td><?php echo esc_html( ucfirst( $item['difficulty'] ) ); ?></td>
							<td><?php echo esc_html( $item['sort_order'] ); ?></td>
							<td><span class="nkg-status nkg-status--<?php echo esc_attr( $item['status'] ); ?>"><?php echo 'active' === $item['status'] ? esc_html__( 'Published', 'neo-kids-games' ) : esc_html__( 'Draft', 'neo-kids-games' ); ?></span></td>
							<td class="nkg-actions">
								<a class="button button-small" href="<?php echo esc_url( admin_url( 'admin.php?page=nkg-content&edit=' . absint( $item['id'] ) ) ); ?>"><?php esc_html_e( 'Edit', 'neo-kids-games' ); ?></a>
								<a class="button button-small" href="<?php echo esc_url( $toggle_url ); ?>"><?php echo 'active' === $item['status'] ? esc_html__( 'Draft', 'neo-kids-games' ) : esc_html__( 'Publish', 'neo-kids-games' ); ?></a>
								<form method="post" class="nkg-inline-form"><?php wp_nonce_field( 'nkg_duplicate_content' ); ?><input type="hidden" name="nkg_content_action" value="duplicate"><input type="hidden" name="content_id" value="<?php echo esc_attr( $item['id'] ); ?>"><button class="button button-small"><?php esc_html_e( 'Duplicate', 'neo-kids-games' ); ?></button></form>
								<a class="button button-small button-link-delete" href="<?php echo esc_url( $delete_url ); ?>" onclick="return confirm('<?php echo esc_js( __( 'Delete this content item?', 'neo-kids-games' ) ); ?>');"><?php esc_html_e( 'Delete', 'neo-kids-games' ); ?></a>
							</td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
			</div>
		</div>
		<?php
	}

	public static function settings_page() {
		$options = get_option( 'nkg_settings', array( 'sound' => 1, 'default_difficulty' => 'easy' ) );
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Kids Games Settings', 'neo-kids-games' ); ?></h1>
			<form method="post" action="options.php">
				<?php settings_fields( 'nkg_settings' ); ?>
				<table class="form-table">
					<tr><th><?php esc_html_e( 'Sound effects', 'neo-kids-games' ); ?></th><td><label><input type="checkbox" name="nkg_settings[sound]" value="1" <?php checked( ! empty( $options['sound'] ) ); ?>> <?php esc_html_e( 'Enable sound effects where supported.', 'neo-kids-games' ); ?></label></td></tr>
					<tr><th><?php esc_html_e( 'Default difficulty', 'neo-kids-games' ); ?></th><td><select name="nkg_settings[default_difficulty]"><option value="easy" <?php selected( $options['default_difficulty'] ?? 'easy', 'easy' ); ?>>Easy</option><option value="medium" <?php selected( $options['default_difficulty'] ?? '', 'medium' ); ?>>Medium</option><option value="hard" <?php selected( $options['default_difficulty'] ?? '', 'hard' ); ?>>Hard</option></select></td></tr>
				</table>
				<?php submit_button(); ?>
			</form>
		</div>
		<?php
	}
	public static function assignments() {
		if ( ! current_user_can( 'manage_options' ) ) { return; }
		$message = '';
		if ( isset( $_POST['nkg_assignment_action'] ) && 'create' === sanitize_key( wp_unslash( $_POST['nkg_assignment_action'] ) ) ) {
			check_admin_referer( 'nkg_create_assignment' );
			$result = NKG_Assignment::create( array(
				'institution_id' => absint( $_POST['institution_id'] ?? 0 ),
				'game_key' => sanitize_key( wp_unslash( $_POST['game_key'] ?? '' ) ),
				'title' => sanitize_text_field( wp_unslash( $_POST['title'] ?? '' ) ),
				'class_name' => sanitize_text_field( wp_unslash( $_POST['class_name'] ?? '' ) ),
				'difficulty' => sanitize_key( wp_unslash( $_POST['difficulty'] ?? 'easy' ) ),
				'starts_at' => sanitize_text_field( wp_unslash( $_POST['starts_at'] ?? '' ) ),
				'due_at' => sanitize_text_field( wp_unslash( $_POST['due_at'] ?? '' ) ),
			) );
			$message = is_wp_error( $result ) ? $result->get_error_message() : __( 'Assignment created.', 'neo-kids-games' );
		}
		$institutions = NKG_Institution::all( 'active' );
		$assignments = NKG_Assignment::all();
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Game Assignments', 'neo-kids-games' ); ?></h1>
			<p class="description"><?php esc_html_e( 'Assign games to an institution and optionally target a class/group.', 'neo-kids-games' ); ?></p>
			<?php if ( $message ) : ?><div class="notice notice-info is-dismissible"><p><?php echo esc_html( $message ); ?></p></div><?php endif; ?>
			<div class="nkg-builder-card">
				<h2><?php esc_html_e( 'Create Assignment', 'neo-kids-games' ); ?></h2>
				<form method="post">
					<?php wp_nonce_field( 'nkg_create_assignment' ); ?>
					<input type="hidden" name="nkg_assignment_action" value="create">
					<table class="form-table">
						<tr><th><?php esc_html_e( 'Institution', 'neo-kids-games' ); ?></th><td><select name="institution_id" required><option value="">Select institution</option><?php foreach ( $institutions as $item ) : ?><option value="<?php echo esc_attr( $item['id'] ); ?>"><?php echo esc_html( $item['name'] . ' (' . $item['code'] . ')' ); ?></option><?php endforeach; ?></select></td></tr>
						<tr><th><?php esc_html_e( 'Game', 'neo-kids-games' ); ?></th><td><select name="game_key" required><?php foreach ( NKG_Game_Registry::all() as $game ) : ?><option value="<?php echo esc_attr( $game->get_key() ); ?>"><?php echo esc_html( $game->get_name() ); ?></option><?php endforeach; ?></select></td></tr>
						<tr><th><?php esc_html_e( 'Assignment title', 'neo-kids-games' ); ?></th><td><input class="regular-text" name="title" required placeholder="Week 1 Memory Challenge"></td></tr>
						<tr><th><?php esc_html_e( 'Class / group', 'neo-kids-games' ); ?></th><td><input class="regular-text" name="class_name" placeholder="Grade 2"><p class="description"><?php esc_html_e( 'Leave blank to assign to the whole institution.', 'neo-kids-games' ); ?></p></td></tr>
						<tr><th><?php esc_html_e( 'Difficulty', 'neo-kids-games' ); ?></th><td><select name="difficulty"><option value="easy">Easy</option><option value="medium">Medium</option><option value="hard">Hard</option></select></td></tr>
					</table>
					<?php submit_button( __( 'Create Assignment', 'neo-kids-games' ) ); ?>
				</form>
			</div>
			<div class="nkg-builder-card">
				<h2><?php esc_html_e( 'Assignments', 'neo-kids-games' ); ?></h2>
				<table class="widefat striped"><thead><tr><th><?php esc_html_e( 'Title', 'neo-kids-games' ); ?></th><th><?php esc_html_e( 'Institution', 'neo-kids-games' ); ?></th><th><?php esc_html_e( 'Game', 'neo-kids-games' ); ?></th><th><?php esc_html_e( 'Class', 'neo-kids-games' ); ?></th><th><?php esc_html_e( 'Status', 'neo-kids-games' ); ?></th></tr></thead><tbody>
				<?php foreach ( $assignments as $item ) : $institution = NKG_Institution::get( $item['institution_id'] ); ?>
					<tr><td><?php echo esc_html( $item['title'] ); ?></td><td><?php echo $institution ? esc_html( $institution['name'] ) : esc_html__( 'Unknown', 'neo-kids-games' ); ?></td><td><?php echo esc_html( $item['game_key'] ); ?></td><td><?php echo $item['class_name'] ? esc_html( $item['class_name'] ) : esc_html__( 'All', 'neo-kids-games' ); ?></td><td><?php echo esc_html( ucfirst( $item['status'] ) ); ?></td></tr>
				<?php endforeach; ?>
				</tbody></table>
			</div>
		</div>
		<?php
	}

	public static function teachers() {
		if ( ! current_user_can( 'manage_options' ) ) { return; }
		$message = '';
		if ( isset( $_POST['nkg_teacher_action'] ) && 'add' === sanitize_key( wp_unslash( $_POST['nkg_teacher_action'] ) ) ) {
			check_admin_referer( 'nkg_add_teacher' );
			$user_id = absint( $_POST['user_id'] ?? 0 );
			$institution_id = absint( $_POST['institution_id'] ?? 0 );
			$message = NKG_Teacher::add( $institution_id, $user_id, sanitize_key( wp_unslash( $_POST['role'] ?? 'teacher' ) ) ) ? __( 'Teacher linked to institution.', 'neo-kids-games' ) : __( 'Could not link teacher.', 'neo-kids-games' );
		}
		$users = get_users( array( 'fields' => array( 'ID', 'display_name', 'user_email' ), 'number' => 500 ) );
		$institutions = NKG_Institution::all( 'active' );
		$teachers = NKG_Teacher::all();
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Teachers', 'neo-kids-games' ); ?></h1>
			<p class="description"><?php esc_html_e( 'Link existing WordPress users to an institution as teachers. Institution-scoped permissions can be expanded in the next phase.', 'neo-kids-games' ); ?></p>
			<?php if ( $message ) : ?><div class="notice notice-info is-dismissible"><p><?php echo esc_html( $message ); ?></p></div><?php endif; ?>
			<div class="nkg-builder-card">
				<form method="post">
					<?php wp_nonce_field( 'nkg_add_teacher' ); ?><input type="hidden" name="nkg_teacher_action" value="add">
					<table class="form-table">
						<tr><th><?php esc_html_e( 'WordPress user', 'neo-kids-games' ); ?></th><td><select name="user_id" required><option value="">Select user</option><?php foreach ( $users as $user ) : ?><option value="<?php echo esc_attr( $user->ID ); ?>"><?php echo esc_html( $user->display_name . ' — ' . $user->user_email ); ?></option><?php endforeach; ?></select></td></tr>
						<tr><th><?php esc_html_e( 'Institution', 'neo-kids-games' ); ?></th><td><select name="institution_id" required><option value="">Select institution</option><?php foreach ( $institutions as $item ) : ?><option value="<?php echo esc_attr( $item['id'] ); ?>"><?php echo esc_html( $item['name'] ); ?></option><?php endforeach; ?></select></td></tr>
						<tr><th><?php esc_html_e( 'Role', 'neo-kids-games' ); ?></th><td><select name="role"><option value="teacher">Teacher</option><option value="admin">Institution Admin</option></select></td></tr>
					</table>
					<?php submit_button( __( 'Link Teacher', 'neo-kids-games' ) ); ?>
				</form>
			</div>
			<div class="nkg-builder-card">
				<table class="widefat striped"><thead><tr><th>User ID</th><th>Institution</th><th>Role</th></tr></thead><tbody>
				<?php foreach ( $teachers as $teacher ) : $institution = NKG_Institution::get( $teacher['institution_id'] ); $user = get_user_by( 'id', $teacher['user_id'] ); ?>
					<tr><td><?php echo $user ? esc_html( $user->display_name ) : esc_html( $teacher['user_id'] ); ?></td><td><?php echo $institution ? esc_html( $institution['name'] ) : esc_html__( 'Unknown', 'neo-kids-games' ); ?></td><td><?php echo esc_html( ucfirst( $teacher['role'] ) ); ?></td></tr>
				<?php endforeach; ?>
				</tbody></table>
			</div>
		</div>
		<?php
	}

}
