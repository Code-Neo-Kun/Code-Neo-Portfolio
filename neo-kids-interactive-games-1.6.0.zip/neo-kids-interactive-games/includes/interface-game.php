<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

interface NKG_Game_Interface {
	public function get_key();
	public function get_name();
	public function get_description();
	public function get_difficulties();
	public function get_frontend_config( $difficulty );
	public function validate_result( array $result, $difficulty );
}
