<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

class NKG_Assignment {
	public static function all( $institution_id = 0, $status = '' ) {
		global $wpdb;
		$t = NKG_Database::tables();
		$where = 'WHERE 1=1';
		$args = array();
		if ( $institution_id ) {
			$where .= ' AND institution_id = %d';
			$args[] = absint( $institution_id );
		}
		if ( $status ) {
			$where .= ' AND status = %s';
			$args[] = sanitize_key( $status );
		}
		$sql = "SELECT * FROM {$t['assignments']} {$where} ORDER BY created_at DESC";
		if ( $args ) {
			$sql = $wpdb->prepare( $sql, $args );
		}
		return $wpdb->get_results( $sql, ARRAY_A );
	}

	public static function create( array $data ) {
		global $wpdb;
		$t = NKG_Database::tables();
		$institution_id = absint( $data['institution_id'] ?? 0 );
		$game_key = sanitize_key( $data['game_key'] ?? '' );
		$title = sanitize_text_field( $data['title'] ?? '' );
		$class_name = sanitize_text_field( $data['class_name'] ?? '' );
		$difficulty = sanitize_key( $data['difficulty'] ?? 'easy' );

		if ( ! $institution_id || ! NKG_Institution::get( $institution_id ) || ! NKG_Game_Registry::get( $game_key ) || '' === $title ) {
			return new WP_Error( 'invalid_assignment', __( 'Institution, game, and title are required.', 'neo-kids-games' ) );
		}

		$ok = $wpdb->insert(
			$t['assignments'],
			array(
				'institution_id' => $institution_id,
				'game_key' => $game_key,
				'title' => $title,
				'class_name' => $class_name,
				'difficulty' => $difficulty,
				'status' => 'active',
				'starts_at' => ! empty( $data['starts_at'] ) ? sanitize_text_field( $data['starts_at'] ) : null,
				'due_at' => ! empty( $data['due_at'] ) ? sanitize_text_field( $data['due_at'] ) : null,
				'created_by' => get_current_user_id(),
				'created_at' => current_time( 'mysql' ),
				'updated_at' => current_time( 'mysql' ),
			),
			array( '%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%d', '%s', '%s' )
		);

		return $ok ? (int) $wpdb->insert_id : new WP_Error( 'assignment_create_failed', __( 'Could not create assignment.', 'neo-kids-games' ) );
	}

	public static function set_status( $id, $status ) {
		global $wpdb;
		$t = NKG_Database::tables();
		$status = 'active' === $status ? 'active' : 'inactive';
		return false !== $wpdb->update(
			$t['assignments'],
			array( 'status' => $status, 'updated_at' => current_time( 'mysql' ) ),
			array( 'id' => absint( $id ) ),
			array( '%s', '%s' ),
			array( '%d' )
		);
	}
}
