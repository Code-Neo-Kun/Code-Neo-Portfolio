<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

class NKG_Reward {
	public static function init() {}

	public static function evaluate( $player_id, $score ) {
		global $wpdb;
		$t = NKG_Database::tables();
		$stats = NKG_Player::stats( $player_id );

		if ( 1 === (int) $stats['completed_games'] ) {
			self::award( $player_id, 'first_game' );
		}
		if ( (int) $stats['completed_games'] >= 5 ) {
			self::award( $player_id, 'five_games' );
		}
		if ( absint( $score ) >= 40 ) {
			self::award( $player_id, 'perfect_score' );
		}
	}

	public static function award( $player_id, $key ) {
		global $wpdb;
		$t = NKG_Database::tables();
		$achievement = $wpdb->get_row(
			$wpdb->prepare( "SELECT * FROM {$t['achievements']} WHERE achievement_key = %s", sanitize_key( $key ) ),
			ARRAY_A
		);
		if ( ! $achievement ) { return false; }

		$exists = $wpdb->get_var(
			$wpdb->prepare( "SELECT id FROM {$t['player_badges']} WHERE player_id = %d AND achievement_key = %s", absint( $player_id ), sanitize_key( $key ) )
		);
		if ( $exists ) { return false; }

		$ok = $wpdb->insert(
			$t['player_badges'],
			array(
				'player_id' => absint( $player_id ),
				'achievement_key' => sanitize_key( $key ),
				'earned_at' => current_time( 'mysql' ),
			),
			array( '%d', '%s', '%s' )
		);
		if ( $ok && absint( $achievement['xp_reward'] ) ) {
			NKG_Player::add_xp( $player_id, absint( $achievement['xp_reward'] ) );
		}
		return $ok;
	}

	public static function badges( $player_id ) {
		global $wpdb;
		$t = NKG_Database::tables();
		return $wpdb->get_results(
			$wpdb->prepare(
				"SELECT a.achievement_key, a.title, a.description, pb.earned_at
				FROM {$t['player_badges']} pb
				INNER JOIN {$t['achievements']} a ON a.achievement_key = pb.achievement_key
				WHERE pb.player_id = %d ORDER BY pb.id DESC",
				absint( $player_id )
			),
			ARRAY_A
		);
	}
}
