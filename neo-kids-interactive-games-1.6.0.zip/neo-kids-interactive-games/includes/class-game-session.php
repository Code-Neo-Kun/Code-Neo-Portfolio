<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

class NKG_Game_Session {
	public static function init() {}

	public static function start( $player_id, $game_key, $difficulty ) {
		global $wpdb;
		$t = NKG_Database::tables();
		$game = NKG_Game_Registry::get( $game_key );
		if ( ! $game ) {
			return new WP_Error( 'invalid_game', __( 'Game not found.', 'neo-kids-games' ) );
		}
		$difficulty = sanitize_key( $difficulty );
		if ( ! in_array( $difficulty, $game->get_difficulties(), true ) ) {
			$difficulty = 'easy';
		}
		$ok = $wpdb->insert(
			$t['sessions'],
			array(
				'player_id' => absint( $player_id ),
				'game_key' => sanitize_key( $game_key ),
				'difficulty' => $difficulty,
				'status' => 'started',
				'started_at' => current_time( 'mysql' ),
			),
			array( '%d', '%s', '%s', '%s', '%s' )
		);
		if ( ! $ok ) {
			return new WP_Error( 'session_create_failed', __( 'Could not start the game.', 'neo-kids-games' ) );
		}
		return (int) $wpdb->insert_id;
	}

	public static function finish( $session_id, $player_id, array $result ) {
		global $wpdb;
		$t = NKG_Database::tables();
		$session = $wpdb->get_row(
			$wpdb->prepare( "SELECT * FROM {$t['sessions']} WHERE id = %d AND player_id = %d", absint( $session_id ), absint( $player_id ) ),
			ARRAY_A
		);
		if ( ! $session || 'started' !== $session['status'] ) {
			return new WP_Error( 'invalid_session', __( 'This game session is invalid or already finished.', 'neo-kids-games' ) );
		}

		$game = NKG_Game_Registry::get( $session['game_key'] );
		$validated = $game->validate_result( $result, $session['difficulty'] );
		$duration = isset( $result['duration'] ) ? min( 3600, max( 0, absint( $result['duration'] ) ) ) : 0;

		$status = $validated['completed'] ? 'completed' : 'abandoned';
		$wpdb->update(
			$t['sessions'],
			array(
				'status' => $status,
				'score' => absint( $validated['score'] ),
				'duration' => $duration,
				'mistakes' => absint( $validated['mistakes'] ),
				'metadata' => wp_json_encode( $validated['metadata'] ),
				'completed_at' => current_time( 'mysql' ),
			),
			array( 'id' => absint( $session_id ) ),
			array( '%s', '%d', '%d', '%d', '%s', '%s' ),
			array( '%d' )
		);

		self::update_progress( $player_id, $session['game_key'], $validated, $duration );

		if ( $validated['completed'] ) {
			$xp = max( 5, min( 100, absint( $validated['score'] ) ) );
			NKG_Player::add_xp( $player_id, $xp );
			NKG_Reward::evaluate( $player_id, $validated['score'] );
		}

		return $validated;
	}

	private static function update_progress( $player_id, $game_key, array $result, $duration ) {
		global $wpdb;
		$t = NKG_Database::tables();
		$current = $wpdb->get_row(
			$wpdb->prepare( "SELECT * FROM {$t['progress']} WHERE player_id = %d AND game_key = %s", absint( $player_id ), sanitize_key( $game_key ) ),
			ARRAY_A
		);

		$now = current_time( 'mysql' );
		if ( $current ) {
			$wpdb->update(
				$t['progress'],
				array(
					'plays' => absint( $current['plays'] ) + 1,
					'completions' => absint( $current['completions'] ) + ( $result['completed'] ? 1 : 0 ),
					'best_score' => max( absint( $current['best_score'] ), absint( $result['score'] ) ),
					'total_score' => absint( $current['total_score'] ) + absint( $result['score'] ),
					'best_time' => ( $duration > 0 && ( 0 === absint( $current['best_time'] ) || $duration < absint( $current['best_time'] ) ) ) ? $duration : absint( $current['best_time'] ),
					'updated_at' => $now,
				),
				array( 'id' => absint( $current['id'] ) ),
				array( '%d', '%d', '%d', '%d', '%d', '%s' ),
				array( '%d' )
			);
		} else {
			$wpdb->insert(
				$t['progress'],
				array(
					'player_id' => absint( $player_id ),
					'game_key' => sanitize_key( $game_key ),
					'plays' => 1,
					'completions' => $result['completed'] ? 1 : 0,
					'best_score' => absint( $result['score'] ),
					'total_score' => absint( $result['score'] ),
					'best_time' => absint( $duration ),
					'updated_at' => $now,
				),
				array( '%d', '%s', '%d', '%d', '%d', '%d', '%d', '%s' )
			);
		}
	}
}
