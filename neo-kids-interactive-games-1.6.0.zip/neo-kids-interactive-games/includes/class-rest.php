<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

class NKG_REST {
	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
	}

	public static function routes() {
		register_rest_route( 'nkg/v1', '/content', array(
			'methods' => WP_REST_Server::READABLE,
			'callback' => array( __CLASS__, 'content' ),
			'permission_callback' => function() {
				return current_user_can( 'manage_options' );
			},
		) );



		register_rest_route( 'nkg/v1', '/assignments', array(
			'methods' => WP_REST_Server::READABLE,
			'callback' => array( __CLASS__, 'get_assignments' ),
			'permission_callback' => '__return_true',
			'args' => array(
				'institution_id' => array( 'required' => true, 'sanitize_callback' => 'absint' ),
				'class_name' => array( 'required' => false, 'sanitize_callback' => 'sanitize_text_field' ),
			),
		) );

		register_rest_route( 'nkg/v1', '/assignments', array(
			'methods' => WP_REST_Server::CREATABLE,
			'callback' => array( __CLASS__, 'create_assignment' ),
			'permission_callback' => function() { return current_user_can( 'manage_options' ); },
		) );

		register_rest_route( 'nkg/v1', '/institutions/lookup', array(
			'methods' => WP_REST_Server::READABLE,
			'callback' => array( __CLASS__, 'lookup_institution' ),
			'permission_callback' => '__return_true',
			'args' => array(
				'code' => array( 'required' => true, 'sanitize_callback' => 'sanitize_text_field' ),
			),
		) );

		register_rest_route( 'nkg/v1', '/players', array(
			'methods' => WP_REST_Server::CREATABLE,
			'callback' => array( __CLASS__, 'create_player' ),
			'permission_callback' => '__return_true',
			'args' => array(
				'nickname' => array( 'required' => true, 'sanitize_callback' => 'sanitize_text_field' ),
				'institution_id' => array( 'required' => true, 'sanitize_callback' => 'absint' ),
				'student_code' => array( 'required' => true, 'sanitize_callback' => 'sanitize_text_field' ),
				'class_name' => array( 'required' => false, 'sanitize_callback' => 'sanitize_text_field' ),
				'token' => array( 'required' => false, 'sanitize_callback' => 'sanitize_text_field' ),
			),
		) );

		register_rest_route( 'nkg/v1', '/players/(?P<id>\d+)', array(
			'methods' => WP_REST_Server::READABLE,
			'callback' => array( __CLASS__, 'get_player' ),
			'permission_callback' => '__return_true',
		) );

		register_rest_route( 'nkg/v1', '/sessions/start', array(
			'methods' => WP_REST_Server::CREATABLE,
			'callback' => array( __CLASS__, 'start_session' ),
			'permission_callback' => '__return_true',
		) );

		register_rest_route( 'nkg/v1', '/sessions/(?P<id>\d+)/finish', array(
			'methods' => WP_REST_Server::CREATABLE,
			'callback' => array( __CLASS__, 'finish_session' ),
			'permission_callback' => '__return_true',
		) );
	}

	private static function token_from_request( WP_REST_Request $request ) {
		$token = $request->get_header( 'X-NKG-Player-Token' );
		if ( ! $token ) {
			$body = $request->get_json_params();
			$token = isset( $body['token'] ) ? sanitize_text_field( $body['token'] ) : '';
		}
		return $token;
	}

	public static function content() {
		return new WP_REST_Response(
			array_map( array( 'NKG_Content', 'decode' ), NKG_Content::all() ),
			200
		);
	}

	public static function lookup_institution( WP_REST_Request $request ) {
		$institution = NKG_Institution::get_by_code( $request->get_param( 'code' ) );
		if ( ! $institution ) {
			return new WP_Error( 'institution_not_found', __( 'Institution code not found or inactive.', 'neo-kids-games' ), array( 'status' => 404 ) );
		}
		return new WP_REST_Response( array( 'institution' => array( 'id' => (int) $institution['id'], 'name' => $institution['name'], 'code' => $institution['code'], 'classes' => $institution['classes'] ) ), 200 );
	}

	public static function create_player( WP_REST_Request $request ) {
		$nickname = $request->get_param( 'nickname' );
		$token = $request->get_param( 'token' );
		$result = NKG_Player::create( $nickname, $token, get_current_user_id(), absint( $request->get_param( 'institution_id' ) ), $request->get_param( 'student_code' ), $request->get_param( 'class_name' ) );
		if ( is_wp_error( $result ) ) {
			return $result;
		}
		return new WP_REST_Response(
			array(
				'id' => $result['id'],
				'token' => $result['token'],
				'player' => NKG_Player::get( $result['id'] ),
				'institution' => NKG_Player::institution( $result['id'] ),
			),
			201
		);
	}

	public static function get_player( WP_REST_Request $request ) {
		$id = absint( $request['id'] );
		$token = self::token_from_request( $request );
		if ( ! $token || ! NKG_Player::authenticate( $id, $token ) ) {
			return new WP_Error( 'forbidden', __( 'Player authentication failed.', 'neo-kids-games' ), array( 'status' => 403 ) );
		}
		return new WP_REST_Response(
			array(
				'player' => NKG_Player::get( $id ),
				'institution' => NKG_Player::institution( $id ),
				'stats' => NKG_Player::stats( $id ),
				'recent' => NKG_Player::recent_sessions( $id ),
				'badges' => NKG_Reward::badges( $id ),
			),
			200
		);
	}

	public static function start_session( WP_REST_Request $request ) {
		$data = $request->get_json_params();
		$player_id = isset( $data['player_id'] ) ? absint( $data['player_id'] ) : 0;
		$token = self::token_from_request( $request );
		$game = isset( $data['game_key'] ) ? sanitize_key( $data['game_key'] ) : '';
		$difficulty = isset( $data['difficulty'] ) ? sanitize_key( $data['difficulty'] ) : 'easy';

		if ( ! $player_id || ! $token || ! NKG_Player::authenticate( $player_id, $token ) ) {
			return new WP_Error( 'forbidden', __( 'Player authentication failed.', 'neo-kids-games' ), array( 'status' => 403 ) );
		}

		$session = NKG_Game_Session::start( $player_id, $game, $difficulty );
		if ( is_wp_error( $session ) ) {
			return $session;
		}
		return new WP_REST_Response( array( 'session_id' => $session ), 201 );
	}

	public static function finish_session( WP_REST_Request $request ) {
		$data = $request->get_json_params();
		$session_id = absint( $request['id'] );
		$player_id = isset( $data['player_id'] ) ? absint( $data['player_id'] ) : 0;
		$token = self::token_from_request( $request );

		if ( ! $player_id || ! $token || ! NKG_Player::authenticate( $player_id, $token ) ) {
			return new WP_Error( 'forbidden', __( 'Player authentication failed.', 'neo-kids-games' ), array( 'status' => 403 ) );
		}

		$result = NKG_Game_Session::finish( $session_id, $player_id, $data );
		if ( is_wp_error( $result ) ) {
			return $result;
		}
		return new WP_REST_Response( $result, 200 );
	}
	public static function get_assignments( WP_REST_Request $request ) {
		$items = NKG_Assignment::all( absint( $request->get_param( 'institution_id' ) ), 'active' );
		$class_name = $request->get_param( 'class_name' );
		if ( $class_name ) {
			$items = array_values( array_filter( $items, function( $item ) use ( $class_name ) {
				return '' === $item['class_name'] || $item['class_name'] === $class_name;
			} ) );
		}
		return new WP_REST_Response( array( 'assignments' => $items ), 200 );
	}

	public static function create_assignment( WP_REST_Request $request ) {
		$result = NKG_Assignment::create( array(
			'institution_id' => $request->get_param( 'institution_id' ),
			'game_key' => $request->get_param( 'game_key' ),
			'title' => $request->get_param( 'title' ),
			'class_name' => $request->get_param( 'class_name' ),
			'difficulty' => $request->get_param( 'difficulty' ),
			'starts_at' => $request->get_param( 'starts_at' ),
			'due_at' => $request->get_param( 'due_at' ),
		) );
		if ( is_wp_error( $result ) ) {
			return $result;
		}
		return new WP_REST_Response( array( 'id' => $result ), 201 );
	}


}
