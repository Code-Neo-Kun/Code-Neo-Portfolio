<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

class NKG_Teacher {
	public static function all( $institution_id = 0 ) {
		global $wpdb;
		$t = NKG_Database::tables();
		if ( $institution_id ) {
			return $wpdb->get_results(
				$wpdb->prepare( "SELECT * FROM {$t['teachers']} WHERE institution_id = %d ORDER BY id DESC", absint( $institution_id ) ),
				ARRAY_A
			);
		}
		return $wpdb->get_results( "SELECT * FROM {$t['teachers']} ORDER BY id DESC", ARRAY_A );
	}

	public static function add( $institution_id, $user_id, $role = 'teacher' ) {
		global $wpdb;
		$t = NKG_Database::tables();
		$role = in_array( $role, array( 'teacher', 'admin' ), true ) ? $role : 'teacher';
		$ok = $wpdb->replace(
			$t['teachers'],
			array(
				'institution_id' => absint( $institution_id ),
				'user_id' => absint( $user_id ),
				'role' => $role,
				'created_at' => current_time( 'mysql' ),
			),
			array( '%d', '%d', '%s', '%s' )
		);
		return false !== $ok;
	}
}
