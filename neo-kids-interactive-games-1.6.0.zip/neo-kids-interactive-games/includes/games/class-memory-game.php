<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

class NKG_Memory_Game implements NKG_Game_Interface {
	public function get_key() { return 'memory'; }
	public function get_name() { return __( 'Memory Match', 'neo-kids-games' ); }
	public function get_description() { return __( 'Find matching pairs of cards.', 'neo-kids-games' ); }
	public function get_difficulties() { return array( 'easy', 'medium', 'hard' ); }

	public function get_frontend_config( $difficulty ) {
		$pairs = array( 'easy' => 4, 'medium' => 6, 'hard' => 8 );
		return array(
			'pairs' => isset( $pairs[ $difficulty ] ) ? $pairs[ $difficulty ] : 4,
			'icons' => array( '🐶', '🐱', '🐸', '🦁', '🐼', '🐵', '🐰', '🦊' ),
		);
	}

	public function validate_result( array $result, $difficulty ) {
		$config = $this->get_frontend_config( $difficulty );
		$pairs = (int) $config['pairs'];
		$matches = isset( $result['matches'] ) ? min( $pairs, max( 0, absint( $result['matches'] ) ) ) : 0;
		$mistakes = isset( $result['mistakes'] ) ? min( 999, max( 0, absint( $result['mistakes'] ) ) ) : 0;
		$completed = ! empty( $result['completed'] ) && $matches === $pairs;
		$score = $completed ? max( 0, ( $pairs * 10 ) - $mistakes ) : 0;

		return array(
			'completed' => $completed,
			'score' => $score,
			'mistakes' => $mistakes,
			'metadata' => array( 'matches' => $matches ),
		);
	}
}
