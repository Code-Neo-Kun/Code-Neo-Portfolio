<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

class NKG_Content {
	public static function all( $game_key = '', $status = '' ) {
		global $wpdb;
		$t = NKG_Database::tables();
		$where = 'WHERE 1=1';
		$args = array();

		if ( $game_key ) {
			$where .= ' AND game_key = %s';
			$args[] = sanitize_key( $game_key );
		}
		if ( $status ) {
			$where .= ' AND status = %s';
			$args[] = sanitize_key( $status );
		}

		$sql = "SELECT * FROM {$t['content']} {$where} ORDER BY sort_order ASC, id DESC";
		if ( $args ) {
			$sql = $wpdb->prepare( $sql, $args );
		}
		return $wpdb->get_results( $sql, ARRAY_A );
	}

	public static function get( $id ) {
		global $wpdb;
		$t = NKG_Database::tables();
		$row = $wpdb->get_row(
			$wpdb->prepare( "SELECT * FROM {$t['content']} WHERE id = %d", absint( $id ) ),
			ARRAY_A
		);
		return $row ? self::decode( $row ) : null;
	}

	public static function save( array $data, $id = 0 ) {
		global $wpdb;
		$t = NKG_Database::tables();

		$game_key = sanitize_key( $data['game_key'] ?? '' );
		$title    = sanitize_text_field( $data['title'] ?? '' );
		$status   = in_array( ( $data['status'] ?? 'draft' ), array( 'active', 'draft' ), true ) ? $data['status'] : 'draft';
		$sort     = isset( $data['sort_order'] ) ? (int) $data['sort_order'] : 0;
		$image    = isset( $data['image_url'] ) ? esc_url_raw( $data['image_url'] ) : '';
		$payload  = array(
			'game_key'   => $game_key,
			'title'      => $title,
			'content'    => wp_json_encode( $data['content'] ?? array() ),
			'difficulty' => sanitize_key( $data['difficulty'] ?? 'easy' ),
			'category'   => sanitize_text_field( $data['category'] ?? '' ),
			'status'     => $status,
			'sort_order' => $sort,
			'image_url'  => $image,
			'updated_at' => current_time( 'mysql' ),
		);

		$formats = array( '%s', '%s', '%s', '%s', '%s', '%s', '%d', '%s', '%s' );

		if ( $id ) {
			$ok = $wpdb->update(
				$t['content'],
				$payload,
				array( 'id' => absint( $id ) ),
				$formats,
				array( '%d' )
			);
			return false === $ok ? 0 : absint( $id );
		}

		$payload['created_at'] = current_time( 'mysql' );
		$ok = $wpdb->insert(
			$t['content'],
			$payload,
			$format = array( '%s', '%s', '%s', '%s', '%s', '%s', '%d', '%s', '%s', '%s' )
		);
		return $ok ? (int) $wpdb->insert_id : 0;
	}

	public static function delete( $id ) {
		global $wpdb;
		$t = NKG_Database::tables();
		return false !== $wpdb->delete( $t['content'], array( 'id' => absint( $id ) ), array( '%d' ) );
	}

	public static function set_status( $id, $status ) {
		global $wpdb;
		$t = NKG_Database::tables();
		$status = in_array( $status, array( 'active', 'draft' ), true ) ? $status : 'draft';
		return false !== $wpdb->update(
			$t['content'],
			array(
				'status'     => $status,
				'updated_at' => current_time( 'mysql' ),
			),
			array( 'id' => absint( $id ) ),
			array( '%s', '%s' ),
			array( '%d' )
		);
	}

	public static function decode( $row ) {
		if ( ! $row ) {
			return null;
		}
		$row['content'] = json_decode( $row['content'], true );
		return $row;
	}
}
