jQuery(function ($) {
	'use strict';

	function rebuildCorrectOptions() {
		var $select = $('#nkg-correct');
		var current = parseInt($select.val(), 10) || 0;
		$select.empty();
		$('#nkg-answer-list .nkg-answer-row').each(function (index) {
			$select.append($('<option>', { value: index, text: 'Answer ' + (index + 1) }));
		});
		if (current < $select.find('option').length) {
			$select.val(current);
		}
	}

	function updatePreview() {
		$('#nkg-preview-title').text($('input[name="title"]').val() || 'Untitled Question');
		$('#nkg-preview-question').text($('textarea[name="question"]').val() || 'Your question will appear here.');
		$('#nkg-preview-category').text($('input[name="category"]').val() || '');
		var $answers = $('#nkg-preview-answers').empty();
		$('#nkg-answer-list input[name="answers[]"]').each(function () {
			var value = $(this).val();
			if (value) {
				$answers.append($('<div class="nkg-preview-answer">').text(value));
			}
		});
		var image = $('#nkg-image-url').val();
		var $image = $('#nkg-preview-image').empty();
		if (image) {
			$image.css('background-image', 'url("' + image.replace(/"/g, '\\"') + '")').addClass('has-image');
		} else {
			$image.css('background-image', '').removeClass('has-image');
		}
	}

	$('#nkg-add-answer').on('click', function () {
		var count = $('#nkg-answer-list .nkg-answer-row').length + 1;
		$('#nkg-answer-list').append(
			'<div class="nkg-answer-row"><span class="nkg-drag">☷</span>' +
			'<input class="widefat" name="answers[]" placeholder="Answer ' + count + '">' +
			'<button type="button" class="button-link-delete nkg-remove-answer" aria-label="Remove answer">×</button></div>'
		);
		rebuildCorrectOptions();
		updatePreview();
	});

	$(document).on('click', '.nkg-remove-answer', function () {
		if ($('#nkg-answer-list .nkg-answer-row').length <= 2) {
			return;
		}
		$(this).closest('.nkg-answer-row').remove();
		rebuildCorrectOptions();
		updatePreview();
	});

	$(document).on('input', '#nkg-content-form input, #nkg-content-form textarea', updatePreview);

	$('#nkg-select-image').on('click', function (e) {
		e.preventDefault();
		var frame = wp.media({
			title: 'Select game image',
			button: { text: 'Use this image' },
			multiple: false
		});
		frame.on('select', function () {
			var attachment = frame.state().get('selection').first().toJSON();
			$('#nkg-image-url').val(attachment.url).trigger('input');
		});
		frame.open();
	});

	rebuildCorrectOptions();
	updatePreview();
});
