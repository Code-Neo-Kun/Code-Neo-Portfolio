(function () {
	'use strict';

	const state = {
		id: Number(localStorage.getItem('nkg_player_id') || 0),
		token: localStorage.getItem('nkg_player_token') || '',
		institutionId: Number(localStorage.getItem('nkg_institution_id') || 0),
		institutionCode: localStorage.getItem('nkg_institution_code') || ''
	};

	function headers() {
		return {
			'Content-Type': 'application/json',
			'X-WP-Nonce': NKG_DATA.nonce,
			'X-NKG-Player-Token': state.token
		};
	}

	function request(url, options) {
		return fetch(NKG_DATA.restUrl + url, options).then(function (response) {
			if (!response.ok) {
				return response.json().then(function (data) {
					throw new Error(data.message || 'Request failed');
				});
			}
			return response.json();
		});
	}

	function createProfile(nickname, studentCode, className) {
		return request('players', {
			method: 'POST',
			headers: headers(),
			body: JSON.stringify({
				nickname: nickname,
				institution_id: state.institutionId,
				student_code: studentCode,
				class_name: className
			})
		}).then(function (data) {
			state.id = Number(data.id);
			state.token = data.token;
			localStorage.setItem('nkg_player_id', String(state.id));
			localStorage.setItem('nkg_player_token', state.token);
			localStorage.setItem('nkg_player_class', data.player && data.player.class_name ? data.player.class_name : '');
			window.dispatchEvent(new CustomEvent('nkg:profile-created', { detail: data }));
			return data;
		});
	}

	function startSession(gameKey, difficulty) {
		return request('sessions/start', {
			method: 'POST',
			headers: headers(),
			body: JSON.stringify({ player_id: state.id, game_key: gameKey, difficulty: difficulty, token: state.token })
		});
	}

	function finishSession(sessionId, payload) {
		payload.player_id = state.id;
		payload.token = state.token;
		return request('sessions/' + sessionId + '/finish', {
			method: 'POST',
			headers: headers(),
			body: JSON.stringify(payload)
		});
	}

	function score(root, value) {
		root.querySelector('.nkg-game__score').textContent = String(value);
	}


	function launchEngineGame(root, sessionId) {
		if (!window.NKGEngine || !window.NKG_GAME_MODULES) {
			throw new Error('Game engine is not available.');
		}

		const runtime = root.querySelector('.nkg-engine-runtime');
		const board = root.querySelector('.nkg-board');
		runtime.innerHTML = '';
		runtime.hidden = false;
		board.hidden = false;

		const engine = NKGEngine.create(runtime, {
			gameKey: root.dataset.nkgGame,
			difficulty: root.dataset.nkgDifficulty
		});

		const module = NKG_GAME_MODULES.create(root.dataset.nkgGame, engine, {
			root: root,
			board: board,
			sessionId: sessionId,
			difficulty: root.dataset.nkgDifficulty,
			onFinish: function () {}
		});

		engine.events.on('game:finished', function (result) {
			finishSession(sessionId, result).then(function (data) {
				result = result || {};
				result.score = data.score;
				result.xp = data.xp;
				board.innerHTML = '';
				result.completed = true;
				root.querySelector('.nkg-result').textContent =
					'🎉 Game complete! +' + data.score + ' points';
				root.querySelector('.nkg-result').hidden = false;
				score(root, data.score);
				window.dispatchEvent(new CustomEvent('nkg:game-completed', { detail: data }));
			}).catch(function (error) {
				root.querySelector('.nkg-message').textContent =
					error.message || 'Could not save your result.';
			});
		});

		engine.start('game', {});
		module.start();
	}

	function initGame(root) {
		const startButton = root.querySelector('.nkg-start');
		const message = root.querySelector('.nkg-message');

		function syncPlayerState() {
			const hasProfile = !!(state.id && state.token);
			startButton.disabled = !hasProfile;
			root.querySelector('.nkg-profile-required').textContent = hasProfile
				? 'Profile ready. You can start this game.'
				: 'A player profile is required before you can play.';
		}

		startButton.addEventListener('click', function () {
			if (!state.id || !state.token) {
				message.textContent = 'Create a player profile before starting a game.';
				return;
			}

			startButton.disabled = true;
			message.textContent = 'Starting…';

			startSession(root.dataset.nkgGame, root.dataset.nkgDifficulty)
				.then(function (data) {
					root.querySelector('.nkg-player-start').hidden = true;
					message.textContent = '';
					launchEngineGame(root, data.session_id);
				})
				.catch(function (error) {
					startButton.disabled = false;
					message.textContent = error.message || 'Something went wrong.';
				});
		});

		syncPlayerState();
		window.addEventListener('nkg:profile-created', syncPlayerState);
	}

	function loadProfile(root) {
		if (!state.id || !state.token) return;

		request('players/' + state.id, {
			method: 'GET',
			headers: headers()
		}).then(function (data) {
			root.querySelector('.nkg-profile__empty').hidden = true;
			root.querySelector('.nkg-profile__content').hidden = false;
			root.querySelector('.nkg-profile__name').textContent = data.player.nickname;
			root.querySelector('.nkg-profile__level').textContent = 'Level ' + data.player.level;
			root.querySelector('.nkg-profile__institution').textContent = data.institution ? data.institution.name : '';
			root.querySelector('.nkg-profile__class').textContent = data.player.class_name ? 'Class ' + data.player.class_name : '';
			root.querySelector('.nkg-xp').textContent = data.player.xp;
			root.querySelector('.nkg-played').textContent = data.stats.games_played;
			root.querySelector('.nkg-completed').textContent = data.stats.completed_games;
			root.querySelector('.nkg-score').textContent = data.stats.total_score;

			const badges = root.querySelector('.nkg-badges');
			badges.innerHTML = '';
			(data.badges || []).forEach(function (badge) {
				const item = document.createElement('span');
				item.className = 'nkg-badge';
				item.textContent = '🏆 ' + badge.title;
				badges.appendChild(item);
			});

			const recent = root.querySelector('.nkg-recent');
			recent.innerHTML = '';
			(data.recent || []).forEach(function (item) {
				const row = document.createElement('div');
				row.className = 'nkg-recent__row';
				row.textContent = item.game_key + ' — ' + item.score + ' points';
				recent.appendChild(row);
			});
		}).catch(function () {
			localStorage.removeItem('nkg_player_id');
			localStorage.removeItem('nkg_player_token');
			state.id = 0;
			state.token = '';
			root.querySelector('.nkg-profile__content').hidden = true;
			root.querySelector('.nkg-profile__create').hidden = false;
		});
	}

	function initProfile(root) {
		const form = root.querySelector('.nkg-profile__create');
		const codeInput = root.querySelector('.nkg-institution-code');
		const findButton = root.querySelector('.nkg-find-institution');
		const institutionConfirm = root.querySelector('.nkg-institution-confirm');
		const institutionName = root.querySelector('.nkg-institution-name');
		const institutionCodeLabel = root.querySelector('.nkg-institution-code-label');
		const studentFields = root.querySelector('.nkg-student-fields');
		const input = root.querySelector('.nkg-profile-name');
		const studentCode = root.querySelector('.nkg-student-code');
		const classSelect = root.querySelector('.nkg-class-name');
		const button = root.querySelector('.nkg-create-profile');
		const message = root.querySelector('.nkg-profile__message');

		function findInstitution() {
			const code = codeInput.value.trim();
			if (!code) {
				message.textContent = 'Enter your institution code.';
				return;
			}
			findButton.disabled = true;
			message.textContent = 'Checking institution…';
			request('institutions/lookup?code=' + encodeURIComponent(code), {
				method: 'GET',
				headers: headers()
			}).then(function (data) {
				state.institutionId = Number(data.institution.id);
				state.institutionCode = data.institution.code;
				localStorage.setItem('nkg_institution_id', String(state.institutionId));
				localStorage.setItem('nkg_institution_code', state.institutionCode);
				institutionName.textContent = data.institution.name;
				institutionCodeLabel.textContent = 'Code: ' + data.institution.code;
				institutionConfirm.hidden = false;
				studentFields.hidden = false;
				classSelect.innerHTML = '<option value="">Select class</option>';
				(data.institution.classes || []).forEach(function (className) {
					const option = document.createElement('option');
					option.value = className;
					option.textContent = className;
					classSelect.appendChild(option);
				});
				message.textContent = 'Institution verified. Complete your student profile.';
			}).catch(function (error) {
				state.institutionId = 0;
				state.institutionCode = '';
				localStorage.removeItem('nkg_institution_id');
				localStorage.removeItem('nkg_institution_code');
				institutionConfirm.hidden = true;
				studentFields.hidden = true;
				message.textContent = error.message || 'Institution not found.';
			}).finally(function () {
				findButton.disabled = false;
			});
		}

		findButton.addEventListener('click', findInstitution);
		codeInput.addEventListener('keydown', function (event) {
			if ('Enter' === event.key) {
				event.preventDefault();
				findButton.click();
			}
		});

		button.addEventListener('click', function () {
			const nickname = input.value.trim();
			const id = studentCode.value.trim();
			const selectedClass = classSelect.value;

			if (!state.institutionId) {
				message.textContent = 'Verify your institution before creating a profile.';
				return;
			}
			if (!nickname) {
				message.textContent = 'Enter a student name.';
				return;
			}
			if (!id) {
				message.textContent = 'Enter the student ID.';
				return;
			}

			button.disabled = true;
			message.textContent = 'Creating profile…';
			createProfile(nickname, id, selectedClass).then(function () {
				input.value = '';
				studentCode.value = '';
				message.textContent = 'Profile created. You can now play games.';
				loadProfile(root);
			}).catch(function (error) {
				button.disabled = false;
				message.textContent = error.message || 'Could not create profile.';
			});
		});

		input.addEventListener('keydown', function (event) {
			if ('Enter' === event.key) {
				event.preventDefault();
				button.click();
			}
		});

		if (state.institutionId && state.institutionCode) {
			codeInput.value = state.institutionCode;
			findInstitution();
		}
	}
	document.addEventListener('DOMContentLoaded', function () {
		document.querySelectorAll('[data-nkg-game]').forEach(initGame);
		document.querySelectorAll('[data-nkg-profile]').forEach(function (root) { initProfile(root); loadProfile(root); });
		window.addEventListener('nkg:game-completed', function () {
			document.querySelectorAll('[data-nkg-profile]').forEach(function (root) { initProfile(root); loadProfile(root); });
		});
	});
})();

(function () {
	'use strict';

	function request(path, options) {
		options = options || {};
		options.headers = Object.assign({
			'Content-Type': 'application/json',
			'X-WP-Nonce': (window.NKG && window.NKG.nonce) || ''
		}, options.headers || {});
		return fetch((window.NKG && window.NKG.restUrl ? window.NKG.restUrl : '/wp-json/nkg/v1/') + path, options)
			.then(function (response) {
				return response.json().then(function (data) {
					if (!response.ok) {
						throw new Error(data.message || 'Request failed.');
					}
					return data;
				});
			});
	}

	function initInstitutionDashboard(root) {
		var institutionId = Number(localStorage.getItem('nkg_institution_id') || 0);
		var className = localStorage.getItem('nkg_player_class') || '';
		var list = root.querySelector('.nkg-assignment-list');

		if (!institutionId) {
			list.innerHTML = '<p>Please create an institution-linked student profile first.</p>';
			return;
		}

		request('assignments?institution_id=' + encodeURIComponent(institutionId) + '&class_name=' + encodeURIComponent(className))
			.then(function (data) {
				if (!data.assignments || !data.assignments.length) {
					list.innerHTML = '<p>No games have been assigned yet.</p>';
					return;
				}
				list.innerHTML = '';
				data.assignments.forEach(function (assignment) {
					var card = document.createElement('article');
					card.className = 'nkg-assignment-card';
					card.innerHTML =
						'<h4></h4><p></p><span></span>';
					card.querySelector('h4').textContent = assignment.title;
					card.querySelector('p').textContent = assignment.game_key + ' · ' + assignment.difficulty;
					card.querySelector('span').textContent = assignment.class_name || 'All classes';
					list.appendChild(card);
				});
			})
			.catch(function (error) {
				list.innerHTML = '<p>' + (error.message || 'Could not load assignments.') + '</p>';
			});
	}

	window.addEventListener('DOMContentLoaded', function () {
		document.querySelectorAll('[data-nkg-institution-dashboard]').forEach(initInstitutionDashboard);
	});
}());
