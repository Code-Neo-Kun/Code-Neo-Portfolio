# WP API Builder

WP API Builder is a developer-focused WordPress plugin for visually defining REST APIs and generating secure PHP CRUD boilerplate.

## Version 1.0.0

### Included

- API configuration
- Namespace and endpoint configuration
- Database table configuration
- Dynamic field builder
- Field validation definitions
- CRUD method selection
- Capability-based permissions
- PHP REST route generation
- GET collection/single handlers
- POST create handler
- PUT/PATCH update handler
- DELETE handler
- Pagination boilerplate
- WordPress `$wpdb` CRUD methods
- Input validation/sanitization
- Copy generated code
- Download generated PHP
- Save/edit/delete API definitions

## Requirements

- WordPress 6.0+
- PHP 8.0+

## Installation

1. Upload the `wp-api-builder` directory to `wp-content/plugins/`.
2. Activate **WP API Builder**.
3. Open **Tools → WP API Builder**.
4. Define an API.
5. Generate or save the API.

## Important

Generated code is boilerplate. Review table names, database schema, validation rules, permissions, indexes, and application-specific business rules before deploying generated code to production.

## License

GPL-2.0-or-later.


## API Tester

Open **Tools → API Tester** to:

- Select a saved API definition.
- Choose GET, POST, PUT, PATCH, or DELETE.
- Edit the endpoint URL.
- Send JSON request bodies.
- Inspect status, response time, headers, and response body.

Free v1 restricts the tester to the current WordPress site's host to avoid turning the admin endpoint into an SSRF proxy.

## Dynamic API Schema (v1.1)

API definitions are schema-driven. Database table names, primary keys, fields, field types, validation constraints, defaults, enum values, and CRUD methods are configured per API definition rather than hardcoded.

Supported field types:
- string
- text
- integer
- number
- boolean
- email
- url
- date
- datetime
- enum
- json

Each field can define required/nullable state, defaults, length/value limits, and enum values. The generator consumes the saved schema when producing REST CRUD boilerplate.

The API Tester continues to test endpoints that are actually registered on the WordPress installation.
