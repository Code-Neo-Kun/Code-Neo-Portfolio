document.addEventListener('DOMContentLoaded', () => {
	const fields = document.getElementById('wab-fields');
	const output = document.getElementById('wab-output');
	const status = document.getElementById('wab-status');
	const savedApis = document.getElementById('wab-saved-apis');
	const apiBase = WPApiBuilder.restUrl;

	const request = async (path, options = {}) => {
		const response = await fetch(`${apiBase}${path}`, {
			...options,
			headers: {
				'Content-Type': 'application/json',
				'X-WP-Nonce': WPApiBuilder.nonce,
				...(options.headers || {})
			}
		});

		const data = await response.json();

		if (!response.ok) {
			throw new Error(data.message || 'Request failed.');
		}

		return data;
	};

	const addField = (field = {}) => {
		const row = document.createElement('div');
		row.className = 'wab-field';
		row.innerHTML = `
			<input type="text" class="wab-field-name" placeholder="field_name">
			<select class="wab-field-type">
				<option value="string">string</option>
				<option value="integer">integer</option>
				<option value="number">number</option>
				<option value="boolean">boolean</option>
				<option value="email">email</option>
				<option value="url">url</option>
				<option value="date">date</option>
				<option value="datetime">datetime</option>
				<option value="enum">enum</option>
				<option value="textarea">textarea</option>
			</select>
			<input type="text" class="wab-field-enum" placeholder="enum: new,active">
			<label><input type="checkbox" class="wab-field-required"> Required</label>
			<button type="button" class="button-link-delete wab-remove-field">Remove</button>
		`;

		row.querySelector('.wab-field-name').value = field.name || '';
		row.querySelector('.wab-field-type').value = field.type || 'string';
		row.querySelector('.wab-field-enum').value = Array.isArray(field.enum) ? field.enum.join(', ') : '';
		row.querySelector('.wab-field-required').checked = !!field.required;

		row.querySelector('.wab-remove-field').addEventListener('click', () => row.remove());
		fields.appendChild(row);
	};

	const clearFields = () => {
		fields.innerHTML = '';
	};

	const collect = () => ({
		id: document.getElementById('wab-id').value,
		name: document.getElementById('wab-name').value,
		namespace: document.getElementById('wab-namespace').value,
		endpoint: document.getElementById('wab-endpoint').value,
		table: document.getElementById('wab-table').value,
		capability: document.getElementById('wab-capability').value,
		methods: [...document.querySelectorAll('.wab-methods input:checked')].map((el) => el.value),
		fields: [...document.querySelectorAll('.wab-field')].map((row) => ({
			name: row.querySelector('.wab-field-name').value,
			type: row.querySelector('.wab-field-type').value,
			enum: row.querySelector('.wab-field-enum').value,
			required: row.querySelector('.wab-field-required').checked
		})).filter((field) => field.name.trim() !== '')
	});

	const populate = (api) => {
		document.getElementById('wab-id').value = api.id || '';
		document.getElementById('wab-name').value = api.name || '';
		document.getElementById('wab-namespace').value = api.namespace || '';
		document.getElementById('wab-endpoint').value = api.endpoint || '';
		document.getElementById('wab-table').value = api.table || '';
		document.getElementById('wab-capability').value = api.capability || 'manage_options';

		document.querySelectorAll('.wab-methods input').forEach((input) => {
			input.checked = (api.methods || []).includes(input.value);
		});

		clearFields();
		(api.fields || []).forEach(addField);
		output.value = '';
	};

	const renderSaved = async () => {
		try {
			const apis = await request('/apis');
			savedApis.innerHTML = '';

			if (!apis.length) {
				savedApis.innerHTML = '<p>No saved APIs yet.</p>';
				return;
			}

			apis.forEach((api) => {
				const item = document.createElement('div');
				item.className = 'wab-saved-item';
				item.innerHTML = `
					<div>
						<strong></strong>
						<small></small>
					</div>
					<div class="wab-saved-actions">
						<button type="button" class="button button-small wab-edit">Edit</button>
						<button type="button" class="button button-small button-link-delete wab-delete">Delete</button>
					</div>
				`;

				item.querySelector('strong').textContent = api.name;
				item.querySelector('small').textContent = `/${api.namespace}/${api.endpoint}`;
				item.querySelector('.wab-edit').addEventListener('click', () => populate(api));
				item.querySelector('.wab-delete').addEventListener('click', async () => {
					if (!window.confirm(`Delete "${api.name}"?`)) return;

					try {
						await request(`/apis/${encodeURIComponent(api.id)}`, { method: 'DELETE' });
						status.textContent = 'API deleted.';
						renderSaved();
					} catch (error) {
						status.textContent = error.message;
					}
				});

				savedApis.appendChild(item);
			});
		} catch (error) {
			status.textContent = error.message;
		}
	};

	document.getElementById('wab-add-field').addEventListener('click', () => addField());

	document.getElementById('wab-generate').addEventListener('click', async () => {
		status.textContent = 'Generating...';

		try {
			const data = await request('/generate', {
				method: 'POST',
				body: JSON.stringify(collect())
			});

			output.value = data.code || '';
			status.textContent = WPApiBuilder.strings.generated;
		} catch (error) {
			status.textContent = error.message;
		}
	});

	document.getElementById('wab-save').addEventListener('click', async () => {
		status.textContent = 'Saving...';

		try {
			const data = await request('/apis', {
				method: 'POST',
				body: JSON.stringify(collect())
			});

			document.getElementById('wab-id').value = data.id || '';
			status.textContent = WPApiBuilder.strings.saved;
			renderSaved();
		} catch (error) {
			status.textContent = error.message;
		}
	});

	document.getElementById('wab-new').addEventListener('click', () => {
		document.getElementById('wab-id').value = '';
		document.getElementById('wab-name').value = 'Customer API';
		document.getElementById('wab-namespace').value = 'myplugin/v1';
		document.getElementById('wab-endpoint').value = 'customers';
		document.getElementById('wab-table').value = 'wp_customers';
		document.getElementById('wab-capability').value = 'manage_options';
		document.querySelectorAll('.wab-methods input').forEach((input) => {
			input.checked = ['GET', 'POST', 'PUT', 'DELETE'].includes(input.value);
		});
		clearFields();
		addField({ name: 'name', type: 'string', required: true });
		addField({ name: 'email', type: 'email', required: true });
		addField({ name: 'phone', type: 'string' });
		output.value = '';
		status.textContent = '';
	});

	document.getElementById('wab-copy').addEventListener('click', async () => {
		if (!output.value) return;

		try {
			await navigator.clipboard.writeText(output.value);
			status.textContent = WPApiBuilder.strings.copied;
		} catch (error) {
			output.select();
			document.execCommand('copy');
			status.textContent = WPApiBuilder.strings.copied;
		}
	});

	document.getElementById('wab-download').addEventListener('click', () => {
		if (!output.value) return;

		const blob = new Blob([output.value], { type: 'text/plain;charset=utf-8' });
		const url = URL.createObjectURL(blob);
		const link = document.createElement('a');

		link.href = url;
		link.download = 'generated-rest-api.php';
		document.body.appendChild(link);
		link.click();
		link.remove();

		URL.revokeObjectURL(url);
	});

	clearFields();
	addField({ name: 'name', type: 'string', required: true });
	addField({ name: 'email', type: 'email', required: true });
	addField({ name: 'phone', type: 'string' });
	renderSaved();
});


// API Tester.
(() => {
	const apiSelect = document.getElementById('wab-tester-api');
	const methodSelect = document.getElementById('wab-tester-method');
	const urlInput = document.getElementById('wab-tester-url');
	const bodyInput = document.getElementById('wab-tester-body');
	const sendButton = document.getElementById('wab-send-test');
	const output = document.getElementById('wab-tester-output');
	const status = document.getElementById('wab-tester-status');
	const responseStatus = document.getElementById('wab-response-status');
	const responseTime = document.getElementById('wab-response-time');

	if (!apiSelect || !sendButton) {
		return;
	}

	const testerRequest = async (path, options = {}) => {
		const response = await fetch(`${WPApiBuilder.restUrl}${path}`, {
			...options,
			headers: {
				'Content-Type': 'application/json',
				'X-WP-Nonce': WPApiBuilder.nonce,
				...(options.headers || {})
			}
		});

		const data = await response.json();

		if (!response.ok) {
			throw new Error(data.message || 'Request failed.');
		}

		return data;
	};

	const loadApis = async () => {
		try {
			const apis = await testerRequest('/apis');
			apis.forEach((api) => {
				const option = document.createElement('option');
				option.value = api.id;
				option.textContent = api.name;
				option.dataset.api = JSON.stringify(api);
				apiSelect.appendChild(option);
			});
		} catch (error) {
			status.textContent = error.message;
		}
	};

	apiSelect.addEventListener('change', () => {
		const option = apiSelect.selectedOptions[0];
		if (!option || !option.dataset.api) {
			return;
		}

		const api = JSON.parse(option.dataset.api);
		const path = `/wp-json/${api.namespace}/${api.endpoint}`.replace(/\/+/g, '/');

		urlInput.value = `${window.location.origin}${path}`;

		if (Array.isArray(api.methods) && api.methods.length) {
			methodSelect.value = api.methods.includes('GET') ? 'GET' : api.methods[0];
		}

		const body = {};
		(api.fields || []).forEach((field) => {
			if (field.name) {
				body[field.name] = field.type === 'integer' ? 1 : '';
			}
		});
		bodyInput.value = JSON.stringify(body, null, 2);
	});

	methodSelect.addEventListener('change', () => {
		const method = methodSelect.value;
		const needsBody = ['POST', 'PUT', 'PATCH'].includes(method);
		bodyInput.disabled = !needsBody;
	});

	sendButton.addEventListener('click', async () => {
		const method = methodSelect.value;
		const url = urlInput.value.trim();

		status.textContent = WPApiBuilder.strings.requesting;
		responseStatus.textContent = '—';
		responseTime.textContent = '—';
		output.textContent = '';

		try {
			const data = await testerRequest('/test', {
				method: 'POST',
				body: JSON.stringify({
					method,
					url,
					body: bodyInput.value
				})
			});

			const response = data.response || {};
			responseStatus.textContent = `${response.status || 0} ${response.status_text || ''}`.trim();
			responseTime.textContent = `${response.time_ms ?? '—'} ms`;
			output.textContent = JSON.stringify(response.body, null, 2);
			status.textContent = '';
		} catch (error) {
			status.textContent = error.message;
			output.textContent = error.message;
		}
	});

	methodSelect.dispatchEvent(new Event('change'));
	loadApis();
})();
