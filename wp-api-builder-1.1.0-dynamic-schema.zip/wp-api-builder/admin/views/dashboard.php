<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="wrap wab-wrap">
	<h1><?php esc_html_e( 'WP API Builder', 'wp-api-builder' ); ?></h1>
	<p class="description"><?php esc_html_e( 'Define a REST API and generate WordPress PHP CRUD boilerplate.', 'wp-api-builder' ); ?></p>

	<div class="wab-layout">
		<section class="wab-panel">
			<h2><?php esc_html_e( 'API Configuration', 'wp-api-builder' ); ?></h2>

			<input type="hidden" id="wab-id" value="">

			<label class="wab-control">
				<span><?php esc_html_e( 'API Name', 'wp-api-builder' ); ?></span>
				<input id="wab-name" type="text" value="Customer API" class="regular-text">
			</label>

			<label class="wab-control">
				<span><?php esc_html_e( 'Namespace', 'wp-api-builder' ); ?></span>
				<input id="wab-namespace" type="text" value="myplugin/v1" class="regular-text">
			</label>

			<label class="wab-control">
				<span><?php esc_html_e( 'Endpoint', 'wp-api-builder' ); ?></span>
				<input id="wab-endpoint" type="text" value="customers" class="regular-text">
			</label>

			<label class="wab-control">
				<span><?php esc_html_e( 'Database Table', 'wp-api-builder' ); ?></span>
				<input id="wab-table" type="text" value="wp_customers" class="regular-text">
			</label>

			<label class="wab-control">
				<span><?php esc_html_e( 'Required Capability', 'wp-api-builder' ); ?></span>
				<input id="wab-capability" type="text" value="manage_options" class="regular-text">
			</label>

			<h2><?php esc_html_e( 'CRUD Methods', 'wp-api-builder' ); ?></h2>
			<div class="wab-methods">
				<label><input type="checkbox" value="GET" checked> GET</label>
				<label><input type="checkbox" value="POST" checked> POST</label>
				<label><input type="checkbox" value="PUT" checked> PUT</label>
				<label><input type="checkbox" value="PATCH"> PATCH</label>
				<label><input type="checkbox" value="DELETE" checked> DELETE</label>
			</div>

			<div class="wab-section-heading">
				<h2><?php esc_html_e( 'Fields', 'wp-api-builder' ); ?></h2>
				<button type="button" class="button" id="wab-add-field"><?php esc_html_e( '+ Add Field', 'wp-api-builder' ); ?></button>
			</div>

			<div id="wab-fields"></div>

			<div class="wab-actions">
				<button type="button" class="button button-primary button-large" id="wab-generate"><?php esc_html_e( 'Generate PHP', 'wp-api-builder' ); ?></button>
				<button type="button" class="button button-large" id="wab-save"><?php esc_html_e( 'Save API', 'wp-api-builder' ); ?></button>
				<button type="button" class="button button-large" id="wab-new"><?php esc_html_e( 'New', 'wp-api-builder' ); ?></button>
			</div>
			<p id="wab-status" class="wab-status" aria-live="polite"></p>

			<h2><?php esc_html_e( 'Saved APIs', 'wp-api-builder' ); ?></h2>
			<div id="wab-saved-apis" class="wab-saved-apis"></div>
		</section>

		<section class="wab-panel wab-output-panel">
			<div class="wab-output-header">
				<h2><?php esc_html_e( 'Generated PHP', 'wp-api-builder' ); ?></h2>
				<div>
					<button type="button" class="button" id="wab-copy"><?php esc_html_e( 'Copy', 'wp-api-builder' ); ?></button>
					<button type="button" class="button" id="wab-download"><?php esc_html_e( 'Download PHP', 'wp-api-builder' ); ?></button>
				</div>
			</div>
			<textarea id="wab-output" spellcheck="false" readonly placeholder="<?php esc_attr_e( 'Generated PHP will appear here...', 'wp-api-builder' ); ?>"></textarea>
		</section>
	</div>
</div>
