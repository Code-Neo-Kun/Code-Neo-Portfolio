<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="wrap wab-wrap">
	<h1><?php esc_html_e( 'WP API Tester', 'wp-api-builder' ); ?></h1>
	<p class="description"><?php esc_html_e( 'Send test requests to REST APIs on this WordPress site and inspect the response.', 'wp-api-builder' ); ?></p>

	<div class="wab-layout wab-tester-layout">
		<section class="wab-panel">
			<h2><?php esc_html_e( 'Request', 'wp-api-builder' ); ?></h2>

			<label class="wab-control">
				<span><?php esc_html_e( 'Saved API', 'wp-api-builder' ); ?></span>
				<select id="wab-tester-api">
					<option value=""><?php esc_html_e( 'Select a saved API...', 'wp-api-builder' ); ?></option>
				</select>
			</label>

			<label class="wab-control">
				<span><?php esc_html_e( 'Method', 'wp-api-builder' ); ?></span>
				<select id="wab-tester-method">
					<option>GET</option>
					<option>POST</option>
					<option>PUT</option>
					<option>PATCH</option>
					<option>DELETE</option>
				</select>
			</label>

			<label class="wab-control">
				<span><?php esc_html_e( 'Endpoint URL', 'wp-api-builder' ); ?></span>
				<input id="wab-tester-url" type="url" class="large-text" value="<?php echo esc_attr( rest_url( 'myplugin/v1/customers' ) ); ?>">
			</label>

			<label class="wab-control">
				<span><?php esc_html_e( 'Request Body (JSON)', 'wp-api-builder' ); ?></span>
				<textarea id="wab-tester-body" class="wab-json-input" spellcheck="false">{}</textarea>
			</label>

			<p class="description"><?php esc_html_e( 'For security, Free v1 only allows requests to this WordPress site.', 'wp-api-builder' ); ?></p>

			<button type="button" class="button button-primary button-large" id="wab-send-test">
				<?php esc_html_e( 'Send Request', 'wp-api-builder' ); ?>
			</button>

			<p id="wab-tester-status" class="wab-status" aria-live="polite"></p>
		</section>

		<section class="wab-panel">
			<div class="wab-output-header">
				<h2><?php esc_html_e( 'Response', 'wp-api-builder' ); ?></h2>
				<div class="wab-response-meta">
					<span id="wab-response-status">—</span>
					<span id="wab-response-time">—</span>
				</div>
			</div>

			<pre id="wab-tester-output" class="wab-response-output"><?php esc_html_e( 'Response will appear here.', 'wp-api-builder' ); ?></pre>
		</section>
	</div>
</div>
