<?php
/**
 * API definition registry.
 *
 * @package WP_API_Builder
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WP_API_Builder_API_Registry {

	const OPTION_KEY = 'wp_api_builder_definitions';

	/**
	 * Get all saved API definitions.
	 *
	 * @return array
	 */
	public static function get_all() {
		$definitions = get_option( self::OPTION_KEY, array() );

		return is_array( $definitions ) ? $definitions : array();
	}

	/**
	 * Get a definition by ID.
	 *
	 * @param string $id Definition ID.
	 * @return array|null
	 */
	public static function get( $id ) {
		$definitions = self::get_all();

		return isset( $definitions[ $id ] ) && is_array( $definitions[ $id ] )
			? $definitions[ $id ]
			: null;
	}

	/**
	 * Save a definition after normalization.
	 *
	 * @param array $definition API definition.
	 * @return string
	 */
	public static function save( $definition ) {
		$definitions = self::get_all();
		$definition  = self::normalize( $definition );

		if ( empty( $definition['id'] ) ) {
			$definition['id'] = 'api_' . wp_generate_uuid4();
		}

		$definitions[ $definition['id'] ] = $definition;
		update_option( self::OPTION_KEY, $definitions, false );

		return $definition['id'];
	}

	/**
	 * Delete a definition.
	 *
	 * @param string $id Definition ID.
	 * @return bool
	 */
	public static function delete( $id ) {
		$definitions = self::get_all();

		if ( ! isset( $definitions[ $id ] ) ) {
			return false;
		}

		unset( $definitions[ $id ] );
		update_option( self::OPTION_KEY, $definitions, false );

		return true;
	}

	/**
	 * Normalize and sanitize the schema.
	 *
	 * @param array $definition Raw definition.
	 * @return array
	 */
	public static function normalize( $definition ) {
		$definition = is_array( $definition ) ? $definition : array();

		$fields = array();
		foreach ( (array) ( $definition['fields'] ?? array() ) as $field ) {
			if ( ! is_array( $field ) ) {
				continue;
			}

			$name   = sanitize_key( $field['name'] ?? '' );
			$column = sanitize_key( $field['column'] ?? $name );

			if ( '' === $name || '' === $column ) {
				continue;
			}

			$type = sanitize_key( $field['type'] ?? 'string' );
			$allowed_types = array(
				'string',
				'text',
				'integer',
				'number',
				'boolean',
				'email',
				'url',
				'date',
				'datetime',
				'enum',
				'json',
			);

			if ( ! in_array( $type, $allowed_types, true ) ) {
				$type = 'string';
			}

			$enum_values = array();
			foreach ( (array) ( $field['enum_values'] ?? array() ) as $value ) {
				$enum_values[] = sanitize_text_field( $value );
			}

			$fields[] = array(
				'name'         => $name,
				'column'       => $column,
				'type'         => $type,
				'required'     => ! empty( $field['required'] ),
				'nullable'     => ! empty( $field['nullable'] ),
				'default'      => isset( $field['default'] ) ? sanitize_text_field( $field['default'] ) : '',
				'min_length'   => max( 0, absint( $field['min_length'] ?? 0 ) ),
				'max_length'   => max( 0, absint( $field['max_length'] ?? 0 ) ),
				'min_value'    => isset( $field['min_value'] ) ? sanitize_text_field( $field['min_value'] ) : '',
				'max_value'    => isset( $field['max_value'] ) ? sanitize_text_field( $field['max_value'] ) : '',
				'enum_values'  => array_values( array_unique( $enum_values ) ),
				'sanitize'     => sanitize_key( $field['sanitize'] ?? 'default' ),
			);
		}

		$methods = array();
		foreach ( (array) ( $definition['methods'] ?? array( 'GET' ) ) as $method ) {
			$method = strtoupper( sanitize_key( $method ) );
			if ( in_array( $method, array( 'GET', 'POST', 'PUT', 'PATCH', 'DELETE' ), true ) ) {
				$methods[] = $method;
			}
		}

		$namespace = sanitize_text_field( $definition['namespace'] ?? 'wp-api-builder/v1' );
		$namespace = trim( preg_replace( '/[^a-zA-Z0-9_\/-]/', '', $namespace ), '/' );

		$route = '/' . ltrim( sanitize_text_field( $definition['route'] ?? '' ), '/' );

		return array(
			'id'            => sanitize_key( $definition['id'] ?? '' ),
			'name'          => sanitize_text_field( $definition['name'] ?? '' ),
			'namespace'     => $namespace ?: 'wp-api-builder/v1',
			'version'       => sanitize_key( $definition['version'] ?? 'v1' ),
			'route'         => $route,
			'table'         => sanitize_text_field( $definition['table'] ?? '' ),
			'primary_key'   => sanitize_key( $definition['primary_key'] ?? 'id' ),
			'methods'       => array_values( array_unique( $methods ) ),
			'auth_required' => ! empty( $definition['auth_required'] ),
			'capability'    => sanitize_key( $definition['capability'] ?? 'manage_options' ),
			'fields'        => $fields,
			'updated_at'    => current_time( 'mysql' ),
		);
	}
}
