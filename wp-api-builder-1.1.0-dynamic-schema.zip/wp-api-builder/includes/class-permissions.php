<?php
/**
 * Permission helper used by generated code.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class WP_API_Builder_Permissions {

	public static function check( string $capability ): bool {
		return current_user_can( $capability );
	}
}
