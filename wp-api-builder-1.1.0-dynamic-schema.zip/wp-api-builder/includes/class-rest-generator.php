<?php
/**
 * REST endpoints used by the builder UI.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class WP_API_Builder_REST_Generator {

	public function init(): void {
		add_action( 'rest_api_init', array( $this, 'register_routes' ) );
	}

	public function register_routes(): void {
		register_rest_route(
			'wp-api-builder/v1',
			'/generate',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'generate' ),
				'permission_callback' => array( $this, 'permission' ),
			)
		);

		register_rest_route(
			'wp-api-builder/v1',
			'/test',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'test_api' ),
				'permission_callback' => array( $this, 'permission' ),
			)
		);

		register_rest_route(
			'wp-api-builder/v1',
			'/apis',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( $this, 'list_apis' ),
				'permission_callback' => array( $this, 'permission' ),
			)
		);

		register_rest_route(
			'wp-api-builder/v1',
			'/apis',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'save_api' ),
				'permission_callback' => array( $this, 'permission' ),
			)
		);

		register_rest_route(
			'wp-api-builder/v1',
			'/apis/(?P<id>[a-z0-9_-]+)',
			array(
				'methods'             => WP_REST_Server::DELETABLE,
				'callback'            => array( $this, 'delete_api' ),
				'permission_callback' => array( $this, 'permission' ),
			)
		);
	}

	public function permission(): bool {
		return current_user_can( 'manage_options' );
	}

	public function generate( WP_REST_Request $request ): WP_REST_Response|WP_Error {
		$validator = new WP_API_Builder_API_Validator();
		$config    = $validator->validate( (array) $request->get_json_params() );

		if ( is_wp_error( $config ) ) {
			return $config;
		}

		$generator = new WP_API_Builder_PHP_Generator();

		return new WP_REST_Response(
			array(
				'code' => $generator->generate( $config ),
				'api'  => $config,
			),
			200
		);
	}

	public function test_api( WP_REST_Request $request ): WP_REST_Response|WP_Error {
		$method = strtoupper( sanitize_key( (string) $request->get_param( 'method' ) ) );
		$url    = esc_url_raw( (string) $request->get_param( 'url' ) );
		$body   = $request->get_param( 'body' );

		$allowed_methods = array( 'GET', 'POST', 'PUT', 'PATCH', 'DELETE' );

		if ( ! in_array( $method, $allowed_methods, true ) ) {
			return new WP_Error( 'invalid_method', __( 'Unsupported HTTP method.', 'wp-api-builder' ), array( 'status' => 400 ) );
		}

		if ( '' === $url || ! wp_http_validate_url( $url ) ) {
			return new WP_Error( 'invalid_url', __( 'Enter a valid HTTP or HTTPS URL.', 'wp-api-builder' ), array( 'status' => 400 ) );
		}

		$parts = wp_parse_url( $url );

		if ( empty( $parts['host'] ) ) {
			return new WP_Error( 'invalid_url', __( 'The URL must include a host.', 'wp-api-builder' ), array( 'status' => 400 ) );
		}

		// Only allow testing this site's own REST API from the admin tester.
		$site_host = wp_parse_url( home_url(), PHP_URL_HOST );
		if ( strtolower( (string) $parts['host'] ) !== strtolower( (string) $site_host ) ) {
			return new WP_Error(
				'external_url_blocked',
				__( 'For security, the tester only sends requests to this WordPress site.', 'wp-api-builder' ),
				array( 'status' => 403 )
			);
		}

		$args = array(
			'method'      => $method,
			'timeout'     => 15,
			'redirection' => 2,
			'headers'     => array(
				'Accept' => 'application/json',
			),
		);

		if ( in_array( $method, array( 'POST', 'PUT', 'PATCH' ), true ) ) {
			$decoded = null;

			if ( is_string( $body ) && '' !== trim( $body ) ) {
				$decoded = json_decode( wp_unslash( $body ), true );

				if ( JSON_ERROR_NONE !== json_last_error() ) {
					return new WP_Error(
						'invalid_json',
						__( 'Request body must contain valid JSON.', 'wp-api-builder' ),
						array( 'status' => 400 )
					);
				}
			}

			$args['headers']['Content-Type'] = 'application/json';
			$args['body'] = wp_json_encode( is_array( $decoded ) ? $decoded : new stdClass() );
		}

		$started  = microtime( true );
		$response = wp_remote_request( $url, $args );
		$duration = round( ( microtime( true ) - $started ) * 1000, 2 );

		if ( is_wp_error( $response ) ) {
			return new WP_Error(
				'request_failed',
				$response->get_error_message(),
				array( 'status' => 502 )
			);
		}

		$code    = wp_remote_retrieve_response_code( $response );
		$message = wp_remote_retrieve_response_message( $response );
		$headers = wp_remote_retrieve_headers( $response );
		$body    = wp_remote_retrieve_body( $response );

		$decoded_body = json_decode( $body, true );

		return new WP_REST_Response(
			array(
				'request' => array(
					'method' => $method,
					'url'    => $url,
				),
				'response' => array(
					'status'      => $code,
					'status_text' => $message,
					'time_ms'     => $duration,
					'headers'     => $headers,
					'body'       => null !== $decoded_body ? $decoded_body : $body,
				),
			),
			200
		);
	}

	public function list_apis(): WP_REST_Response {
		$registry = new WP_API_Builder_API_Registry();
		return new WP_REST_Response( array_values( $registry->all() ), 200 );
	}

	public function save_api( WP_REST_Request $request ): WP_REST_Response|WP_Error {
		$validator = new WP_API_Builder_API_Validator();
		$config    = $validator->validate( (array) $request->get_json_params() );

		if ( is_wp_error( $config ) ) {
			return $config;
		}

		$registry = new WP_API_Builder_API_Registry();
		$id       = $registry->save( $config );
		$config   = $registry->get( $id );

		return new WP_REST_Response( $config, 201 );
	}

	public function delete_api( WP_REST_Request $request ): WP_REST_Response|WP_Error {
		$id = sanitize_key( (string) $request['id'] );

		$registry = new WP_API_Builder_API_Registry();

		if ( ! $registry->delete( $id ) ) {
			return new WP_Error(
				'not_found',
				__( 'API definition not found.', 'wp-api-builder' ),
				array( 'status' => 404 )
			);
		}

		return new WP_REST_Response( array( 'deleted' => true ), 200 );
	}
}
