<?php
/**
 * Validates and normalizes API definitions.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class WP_API_Builder_API_Validator {

	private const METHODS = array( 'GET', 'POST', 'PUT', 'PATCH', 'DELETE' );

	private const TYPES = array(
		'string',
		'integer',
		'number',
		'boolean',
		'email',
		'url',
		'date',
		'datetime',
		'enum',
		'textarea',
	);

	public function validate( array $input ): array|WP_Error {
		$name       = sanitize_text_field( $input['name'] ?? '' );
		$namespace  = $this->namespace( $input['namespace'] ?? '' );
		$endpoint   = $this->endpoint( $input['endpoint'] ?? '' );
		$table      = $this->table( $input['table'] ?? '' );
		$capability = sanitize_key( $input['capability'] ?? 'manage_options' );

		if ( '' === $name || '' === $namespace || '' === $endpoint || '' === $table ) {
			return new WP_Error(
				'invalid_api',
				__( 'API name, namespace, endpoint, and database table are required.', 'wp-api-builder' ),
				array( 'status' => 400 )
			);
		}

		if ( '' === $capability ) {
			$capability = 'manage_options';
		}

		$methods = array();
		foreach ( (array) ( $input['methods'] ?? array( 'GET' ) ) as $method ) {
			$method = strtoupper( sanitize_key( (string) $method ) );
			if ( in_array( $method, self::METHODS, true ) && ! in_array( $method, $methods, true ) ) {
				$methods[] = $method;
			}
		}

		if ( empty( $methods ) ) {
			return new WP_Error(
				'invalid_methods',
				__( 'Select at least one CRUD method.', 'wp-api-builder' ),
				array( 'status' => 400 )
			);
		}

		$fields = array();

		foreach ( (array) ( $input['fields'] ?? array() ) as $field ) {
			if ( ! is_array( $field ) ) {
				continue;
			}

			$field_name = sanitize_key( $field['name'] ?? '' );
			$type       = sanitize_key( $field['type'] ?? 'string' );

			if ( '' === $field_name || ! in_array( $type, self::TYPES, true ) ) {
				continue;
			}

			$fields[] = array(
				'name'     => $field_name,
				'type'     => $type,
				'required' => ! empty( $field['required'] ),
				'enum'     => $this->enum_values( $field['enum'] ?? '' ),
			);
		}

		return array(
			'id'         => sanitize_key( $input['id'] ?? '' ),
			'name'       => $name,
			'namespace'  => $namespace,
			'endpoint'   => $endpoint,
			'table'      => $table,
			'capability' => $capability,
			'methods'    => $methods,
			'fields'     => $fields,
		);
	}

	private function namespace( string $value ): string {
		$value = strtolower( trim( $value ) );
		$value = preg_replace( '/[^a-z0-9_-]+/', '', str_replace( '/', '/', $value ) );
		$value = preg_replace( '#/+#', '/', $value );

		return trim( $value, '/' );
	}

	private function endpoint( string $value ): string {
		$value = strtolower( trim( $value ) );
		return preg_replace( '/[^a-z0-9_-]+/', '-', $value );
	}

	private function table( string $value ): string {
		return preg_replace( '/[^A-Za-z0-9_]+/', '', trim( $value ) );
	}

	private function enum_values( string $value ): array {
		$values = array();

		foreach ( explode( ',', $value ) as $item ) {
			$item = sanitize_text_field( trim( $item ) );
			if ( '' !== $item ) {
				$values[] = $item;
			}
		}

		return array_values( array_unique( $values ) );
	}
}
