<?php
/**
 * Admin UI.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class WP_API_Builder_Admin {

	public function init(): void {
		add_action( 'admin_menu', array( $this, 'register_menu' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );
	}

	public function register_menu(): void {
		add_management_page(
			__( 'WP API Builder', 'wp-api-builder' ),
			__( 'WP API Builder', 'wp-api-builder' ),
			'manage_options',
			'wp-api-builder',
			array( $this, 'render_page' )
		);

		add_management_page(
			__( 'API Tester', 'wp-api-builder' ),
			__( 'API Tester', 'wp-api-builder' ),
			'manage_options',
			'wp-api-builder-tester',
			array( $this, 'render_tester_page' )
		);
	}

	public function enqueue_assets( string $hook ): void {
		if ( ! in_array( $hook, array( 'tools_page_wp-api-builder', 'tools_page_wp-api-builder-tester' ), true ) ) {
			return;
		}

		wp_enqueue_style(
			'wp-api-builder-admin',
			WP_API_BUILDER_URL . 'admin/css/admin.css',
			array(),
			WP_API_BUILDER_VERSION
		);

		wp_enqueue_script(
			'wp-api-builder-admin',
			WP_API_BUILDER_URL . 'admin/js/admin.js',
			array(),
			WP_API_BUILDER_VERSION,
			true
		);

		wp_localize_script(
			'wp-api-builder-admin',
			'WPApiBuilder',
			array(
				'restUrl' => esc_url_raw( rest_url( 'wp-api-builder/v1' ) ),
				'nonce'   => wp_create_nonce( 'wp_rest' ),
				'strings' => array(
					'generated' => __( 'PHP generated.', 'wp-api-builder' ),
					'saved'    => __( 'API saved.', 'wp-api-builder' ),
					'copied'   => __( 'Copied!', 'wp-api-builder' ),
					'requesting' => __( 'Sending request...', 'wp-api-builder' ),
				),
			)
		);
	}

	public function render_page(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'wp-api-builder' ) );
		}

		include WP_API_BUILDER_DIR . 'admin/views/dashboard.php';
	}

	public function render_tester_page(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'wp-api-builder' ) );
		}

		include WP_API_BUILDER_DIR . 'admin/views/api-tester.php';
	}
}
