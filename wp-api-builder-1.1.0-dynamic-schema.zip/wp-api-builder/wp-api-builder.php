<?php
/**
 * Plugin Name: WP API Builder
 * Description: Build custom WordPress REST API definitions and generate secure PHP CRUD boilerplate.
 * Version: 1.1.0
 * Author: Uddhav Shrimali
 * Requires at least: 6.0
 * Requires PHP: 8.0
 * License: GPL-2.0-or-later
 * Text Domain: wp-api-builder
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'WP_API_BUILDER_VERSION', '1.0.0' );
define( 'WP_API_BUILDER_FILE', __FILE__ );
define( 'WP_API_BUILDER_DIR', plugin_dir_path( __FILE__ ) );
define( 'WP_API_BUILDER_URL', plugin_dir_url( __FILE__ ) );

require_once WP_API_BUILDER_DIR . 'includes/class-plugin.php';
require_once WP_API_BUILDER_DIR . 'includes/class-api-registry.php';
require_once WP_API_BUILDER_DIR . 'includes/class-api-validator.php';
require_once WP_API_BUILDER_DIR . 'includes/class-permissions.php';
require_once WP_API_BUILDER_DIR . 'includes/class-php-generator.php';
require_once WP_API_BUILDER_DIR . 'includes/class-rest-generator.php';
require_once WP_API_BUILDER_DIR . 'includes/class-admin.php';

add_action(
	'plugins_loaded',
	static function () {
		WP_API_Builder_Plugin::instance()->init();
	}
);
