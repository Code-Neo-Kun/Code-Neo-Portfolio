=== WP API Builder ===
Contributors: uddhavshrimali
Tags: rest api, api, developer tools, wordpress development
Requires at least: 6.0
Requires PHP: 8.0
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Build WordPress REST API definitions visually and generate PHP CRUD boilerplate.

== Description ==

WP API Builder helps WordPress developers define REST API endpoints, fields, CRUD operations, and permissions from an admin interface.

== Features ==

* API configuration
* Dynamic field builder
* CRUD method selection
* Capability-based permissions
* WordPress REST route generation
* PHP CRUD boilerplate
* Input validation and sanitization
* Copy generated code
* Download generated PHP
* Save and manage API definitions
* Built-in API Tester for this WordPress site

== Installation ==

1. Upload the plugin to `/wp-content/plugins/`.
2. Activate the plugin.
3. Go to Tools > WP API Builder.

== Requirements ==

* WordPress 6.0+
* PHP 8.0+

== License ==

GPL-2.0-or-later.
