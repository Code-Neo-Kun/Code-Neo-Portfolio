<?php
/**
 * Uninstall WP API Builder.
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

delete_option( 'wp_api_builder_apis' );
