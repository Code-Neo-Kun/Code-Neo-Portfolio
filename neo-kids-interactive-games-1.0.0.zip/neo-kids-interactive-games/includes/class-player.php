<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

class NKG_Player {
	public static function init() {}

	public static function token_hash( $token ) {
		return hash_hmac( 'sha256', (string) $token, wp_salt( 'auth' ) );
	}

	public static function create( $nickname, $token = '', $user_id = 0 ) {
		global $wpdb;
		$t = NKG_Database::tables();
		$nickname = sanitize_text_field( $nickname );
		if ( '' === $nickname || strlen( $nickname ) > 100 ) {
			return new WP_Error( 'invalid_nickname', __( 'Please enter a valid player name.', 'neo-kids-games' ) );
		}

		$token = $token ? sanitize_text_field( $token ) : wp_generate_uuid4() . wp_generate_uuid4();
		$hash = self::token_hash( $token );
		$existing = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$t['players']} WHERE player_token_hash = %s", $hash ) );

		if ( $existing ) {
			$wpdb->update(
				$t['players'],
				array( 'nickname' => $nickname, 'updated_at' => current_time( 'mysql' ) ),
				array( 'id' => absint( $existing ) ),
				array( '%s', '%s' ),
				array( '%d' )
			);
			return array( 'id' => (int) $existing, 'token' => $token );
		}

		$ok = $wpdb->insert(
			$t['players'],
			array(
				'user_id' => $user_id ? absint( $user_id ) : null,
				'player_token_hash' => $hash,
				'nickname' => $nickname,
				'avatar' => '',
				'level' => 1,
				'xp' => 0,
				'created_at' => current_time( 'mysql' ),
				'updated_at' => current_time( 'mysql' ),
			),
			array( '%d', '%s', '%s', '%s', '%d', '%d', '%s', '%s' )
		);

		if ( ! $ok ) {
			return new WP_Error( 'player_create_failed', __( 'Could not create the player.', 'neo-kids-games' ) );
		}

		return array( 'id' => (int) $wpdb->insert_id, 'token' => $token );
	}

	public static function get( $id ) {
		global $wpdb;
		$t = NKG_Database::tables();
		return $wpdb->get_row(
			$wpdb->prepare( "SELECT id, user_id, nickname, avatar, level, xp, created_at, updated_at FROM {$t['players']} WHERE id = %d", absint( $id ) ),
			ARRAY_A
		);
	}

	public static function authenticate( $id, $token ) {
		global $wpdb;
		$t = NKG_Database::tables();
		$hash = self::token_hash( $token );
		return (bool) $wpdb->get_var(
			$wpdb->prepare( "SELECT id FROM {$t['players']} WHERE id = %d AND player_token_hash = %s", absint( $id ), $hash )
		);
	}

	public static function add_xp( $id, $amount ) {
		global $wpdb;
		$t = NKG_Database::tables();
		$player = self::get( $id );
		if ( ! $player ) { return false; }
		$xp = absint( $player['xp'] ) + absint( $amount );
		$level = max( 1, (int) floor( $xp / 100 ) + 1 );
		return false !== $wpdb->update(
			$t['players'],
			array( 'xp' => $xp, 'level' => $level, 'updated_at' => current_time( 'mysql' ) ),
			array( 'id' => absint( $id ) ),
			array( '%d', '%d', '%s' ),
			array( '%d' )
		);
	}

	public static function stats( $id ) {
		global $wpdb;
		$t = NKG_Database::tables();
		$row = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT COUNT(*) games_played, COALESCE(SUM(score),0) total_score,
				COALESCE(SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END),0) completed_games
				FROM {$t['sessions']} WHERE player_id = %d",
				absint( $id )
			),
			ARRAY_A
		);
		return $row ? $row : array( 'games_played' => 0, 'total_score' => 0, 'completed_games' => 0 );
	}

	public static function recent_sessions( $id, $limit = 10 ) {
		global $wpdb;
		$t = NKG_Database::tables();
		$limit = min( 20, max( 1, absint( $limit ) ) );
		return $wpdb->get_results(
			$wpdb->prepare(
				"SELECT game_key, difficulty, score, duration, status, started_at, completed_at
				FROM {$t['sessions']} WHERE player_id = %d ORDER BY id DESC LIMIT %d",
				absint( $id ), $limit
			),
			ARRAY_A
		);
	}
}
