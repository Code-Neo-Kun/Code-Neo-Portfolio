<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

class NKG_Frontend {
	public static function init() {
		add_shortcode( 'nkg_game', array( __CLASS__, 'game_shortcode' ) );
		add_shortcode( 'nkg_player_profile', array( __CLASS__, 'profile_shortcode' ) );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'register_assets' ) );
	}

	public static function register_assets() {
		wp_register_style( 'nkg-games', NKG_URL . 'assets/css/games.css', array(), NKG_VERSION );
		wp_register_script( 'nkg-games', NKG_URL . 'assets/js/games.js', array(), NKG_VERSION, true );
		wp_localize_script(
			'nkg-games',
			'NKG_DATA',
			array(
				'restUrl' => esc_url_raw( rest_url( 'nkg/v1/' ) ),
				'nonce' => wp_create_nonce( 'wp_rest' ),
			)
		);
	}

	public static function game_shortcode( $atts ) {
		$atts = shortcode_atts(
			array( 'type' => 'memory', 'difficulty' => 'easy' ),
			$atts,
			'nkg_game'
		);
		$key = sanitize_key( $atts['type'] );
		$game = NKG_Game_Registry::get( $key );
		if ( ! $game ) { return ''; }

		$difficulty = sanitize_key( $atts['difficulty'] );
		if ( ! in_array( $difficulty, $game->get_difficulties(), true ) ) { $difficulty = 'easy'; }

		wp_enqueue_style( 'nkg-games' );
		wp_enqueue_script( 'nkg-games' );

		ob_start();
		?>
		<section class="nkg-game" data-nkg-game="<?php echo esc_attr( $key ); ?>" data-nkg-difficulty="<?php echo esc_attr( $difficulty ); ?>">
			<header class="nkg-game__header">
				<div>
					<h3 class="nkg-game__title"><?php echo esc_html( $game->get_name() ); ?></h3>
					<p><?php echo esc_html( $game->get_description() ); ?></p>
				</div>
				<div class="nkg-game__score" aria-live="polite">0</div>
			</header>

			<div class="nkg-player-start">
				<label for="nkg-player-name-<?php echo esc_attr( wp_rand( 1000, 9999 ) ); ?>"><?php esc_html_e( 'Player name', 'neo-kids-games' ); ?></label>
				<div class="nkg-player-start__row">
					<input class="nkg-player-name" maxlength="100" type="text" autocomplete="nickname">
					<button class="nkg-button nkg-start" type="button"><?php esc_html_e( 'Start Game', 'neo-kids-games' ); ?></button>
				</div>
				<p class="nkg-message" aria-live="polite"></p>
			</div>

			<div class="nkg-board" hidden></div>
			<div class="nkg-result" hidden aria-live="polite"></div>
		</section>
		<?php
		return ob_get_clean();
	}

	public static function profile_shortcode() {
		wp_enqueue_style( 'nkg-games' );
		wp_enqueue_script( 'nkg-games' );
		ob_start();
		?>
		<section class="nkg-profile" data-nkg-profile>
			<h3><?php esc_html_e( 'Player Profile', 'neo-kids-games' ); ?></h3>
			<p class="nkg-profile__empty"><?php esc_html_e( 'Play a game first to create your profile.', 'neo-kids-games' ); ?></p>
			<div class="nkg-profile__content" hidden>
				<div class="nkg-profile__identity">
					<strong class="nkg-profile__name"></strong>
					<span class="nkg-profile__level"></span>
				</div>
				<div class="nkg-profile__stats">
					<div><strong class="nkg-xp">0</strong><span>XP</span></div>
					<div><strong class="nkg-played">0</strong><span><?php esc_html_e( 'Games', 'neo-kids-games' ); ?></span></div>
					<div><strong class="nkg-completed">0</strong><span><?php esc_html_e( 'Completed', 'neo-kids-games' ); ?></span></div>
					<div><strong class="nkg-score">0</strong><span><?php esc_html_e( 'Score', 'neo-kids-games' ); ?></span></div>
				</div>
				<h4><?php esc_html_e( 'Achievements', 'neo-kids-games' ); ?></h4>
				<div class="nkg-badges"></div>
				<h4><?php esc_html_e( 'Recent Games', 'neo-kids-games' ); ?></h4>
				<div class="nkg-recent"></div>
			</div>
		</section>
		<?php
		return ob_get_clean();
	}
}
