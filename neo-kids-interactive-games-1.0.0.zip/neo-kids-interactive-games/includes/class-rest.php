<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

class NKG_REST {
	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
	}

	public static function routes() {
		register_rest_route( 'nkg/v1', '/players', array(
			'methods' => WP_REST_Server::CREATABLE,
			'callback' => array( __CLASS__, 'create_player' ),
			'permission_callback' => '__return_true',
			'args' => array(
				'nickname' => array( 'required' => true, 'sanitize_callback' => 'sanitize_text_field' ),
				'token' => array( 'required' => false, 'sanitize_callback' => 'sanitize_text_field' ),
			),
		) );

		register_rest_route( 'nkg/v1', '/players/(?P<id>\d+)', array(
			'methods' => WP_REST_Server::READABLE,
			'callback' => array( __CLASS__, 'get_player' ),
			'permission_callback' => '__return_true',
		) );

		register_rest_route( 'nkg/v1', '/sessions/start', array(
			'methods' => WP_REST_Server::CREATABLE,
			'callback' => array( __CLASS__, 'start_session' ),
			'permission_callback' => '__return_true',
		) );

		register_rest_route( 'nkg/v1', '/sessions/(?P<id>\d+)/finish', array(
			'methods' => WP_REST_Server::CREATABLE,
			'callback' => array( __CLASS__, 'finish_session' ),
			'permission_callback' => '__return_true',
		) );
	}

	private static function token_from_request( WP_REST_Request $request ) {
		$token = $request->get_header( 'X-NKG-Player-Token' );
		if ( ! $token ) {
			$body = $request->get_json_params();
			$token = isset( $body['token'] ) ? sanitize_text_field( $body['token'] ) : '';
		}
		return $token;
	}

	public static function create_player( WP_REST_Request $request ) {
		$nickname = $request->get_param( 'nickname' );
		$token = $request->get_param( 'token' );
		$result = NKG_Player::create( $nickname, $token, get_current_user_id() );
		if ( is_wp_error( $result ) ) {
			return $result;
		}
		return new WP_REST_Response(
			array(
				'id' => $result['id'],
				'token' => $result['token'],
				'player' => NKG_Player::get( $result['id'] ),
			),
			201
		);
	}

	public static function get_player( WP_REST_Request $request ) {
		$id = absint( $request['id'] );
		$token = self::token_from_request( $request );
		if ( ! $token || ! NKG_Player::authenticate( $id, $token ) ) {
			return new WP_Error( 'forbidden', __( 'Player authentication failed.', 'neo-kids-games' ), array( 'status' => 403 ) );
		}
		return new WP_REST_Response(
			array(
				'player' => NKG_Player::get( $id ),
				'stats' => NKG_Player::stats( $id ),
				'recent' => NKG_Player::recent_sessions( $id ),
				'badges' => NKG_Reward::badges( $id ),
			),
			200
		);
	}

	public static function start_session( WP_REST_Request $request ) {
		$data = $request->get_json_params();
		$player_id = isset( $data['player_id'] ) ? absint( $data['player_id'] ) : 0;
		$token = self::token_from_request( $request );
		$game = isset( $data['game_key'] ) ? sanitize_key( $data['game_key'] ) : '';
		$difficulty = isset( $data['difficulty'] ) ? sanitize_key( $data['difficulty'] ) : 'easy';

		if ( ! $player_id || ! $token || ! NKG_Player::authenticate( $player_id, $token ) ) {
			return new WP_Error( 'forbidden', __( 'Player authentication failed.', 'neo-kids-games' ), array( 'status' => 403 ) );
		}

		$session = NKG_Game_Session::start( $player_id, $game, $difficulty );
		if ( is_wp_error( $session ) ) {
			return $session;
		}
		return new WP_REST_Response( array( 'session_id' => $session ), 201 );
	}

	public static function finish_session( WP_REST_Request $request ) {
		$data = $request->get_json_params();
		$session_id = absint( $request['id'] );
		$player_id = isset( $data['player_id'] ) ? absint( $data['player_id'] ) : 0;
		$token = self::token_from_request( $request );

		if ( ! $player_id || ! $token || ! NKG_Player::authenticate( $player_id, $token ) ) {
			return new WP_Error( 'forbidden', __( 'Player authentication failed.', 'neo-kids-games' ), array( 'status' => 403 ) );
		}

		$result = NKG_Game_Session::finish( $session_id, $player_id, $data );
		if ( is_wp_error( $result ) ) {
			return $result;
		}
		return new WP_REST_Response( $result, 200 );
	}
}
