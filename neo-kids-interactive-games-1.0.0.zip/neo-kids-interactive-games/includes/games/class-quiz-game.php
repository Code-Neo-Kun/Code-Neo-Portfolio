<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

class NKG_Quiz_Game implements NKG_Game_Interface {
	public function get_key() { return 'quiz'; }
	public function get_name() { return __( 'Quick Quiz', 'neo-kids-games' ); }
	public function get_description() { return __( 'Answer short educational questions.', 'neo-kids-games' ); }
	public function get_difficulties() { return array( 'easy', 'medium', 'hard' ); }

	public function get_frontend_config( $difficulty ) {
		$questions = array(
			array( 'q' => __( 'Which animal says “meow”?', 'neo-kids-games' ), 'a' => array( '🐶 Dog', '🐱 Cat', '🐮 Cow' ), 'correct' => 1 ),
			array( 'q' => __( 'Which one is a fruit?', 'neo-kids-games' ), 'a' => array( '🚗 Car', '🍎 Apple', '🏠 House' ), 'correct' => 1 ),
			array( 'q' => __( 'Which color is usually associated with grass?', 'neo-kids-games' ), 'a' => array( '🍃 Green', '🌊 Blue', '🍋 Yellow' ), 'correct' => 0 ),
		);

		if ( 'medium' === $difficulty ) {
			$questions[] = array( 'q' => __( 'How many legs does a dog usually have?', 'neo-kids-games' ), 'a' => array( '2', '4', '6' ), 'correct' => 1 );
		}
		if ( 'hard' === $difficulty ) {
			$questions[] = array( 'q' => __( 'Which planet do we live on?', 'neo-kids-games' ), 'a' => array( 'Mars', 'Earth', 'Jupiter' ), 'correct' => 1 );
		}

		return array( 'questions' => $questions );
	}

	public function validate_result( array $result, $difficulty ) {
		$config = $this->get_frontend_config( $difficulty );
		$total = count( $config['questions'] );
		$correct = isset( $result['correct'] ) ? min( $total, max( 0, absint( $result['correct'] ) ) ) : 0;
		$completed = ! empty( $result['completed'] ) && $correct === $total;

		return array(
			'completed' => $completed,
			'score' => $correct * 10,
			'mistakes' => max( 0, $total - $correct ),
			'metadata' => array( 'correct' => $correct, 'total' => $total ),
		);
	}
}
