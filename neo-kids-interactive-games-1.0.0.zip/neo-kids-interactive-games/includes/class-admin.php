<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

class NKG_Admin {
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_init', array( __CLASS__, 'settings' ) );
	}

	public static function menu() {
		add_menu_page( __( 'Kids Games', 'neo-kids-games' ), __( 'Kids Games', 'neo-kids-games' ), 'manage_options', 'nkg-dashboard', array( __CLASS__, 'dashboard' ), 'dashicons-games', 25 );
		add_submenu_page( 'nkg-dashboard', __( 'Games', 'neo-kids-games' ), __( 'Games', 'neo-kids-games' ), 'manage_options', 'nkg-games', array( __CLASS__, 'games' ) );
		add_submenu_page( 'nkg-dashboard', __( 'Players', 'neo-kids-games' ), __( 'Players', 'neo-kids-games' ), 'manage_options', 'nkg-players', array( __CLASS__, 'players' ) );
		add_submenu_page( 'nkg-dashboard', __( 'Settings', 'neo-kids-games' ), __( 'Settings', 'neo-kids-games' ), 'manage_options', 'nkg-settings', array( __CLASS__, 'settings_page' ) );
	}

	public static function settings() {
		register_setting(
			'nkg_settings',
			'nkg_settings',
			array(
				'type' => 'array',
				'sanitize_callback' => function( $value ) {
					return array(
						'sound' => ! empty( $value['sound'] ) ? 1 : 0,
						'default_difficulty' => isset( $value['default_difficulty'] ) ? sanitize_key( $value['default_difficulty'] ) : 'easy',
					);
				},
				'default' => array( 'sound' => 1, 'default_difficulty' => 'easy' ),
			)
		);
	}

	public static function dashboard() {
		global $wpdb;
		$t = NKG_Database::tables();
		$players = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$t['players']}" );
		$sessions = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$t['sessions']}" );
		$completed = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$t['sessions']} WHERE status = 'completed'" );
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Neo Kids Interactive Games', 'neo-kids-games' ); ?></h1>
			<p><?php esc_html_e( 'Game engine dashboard.', 'neo-kids-games' ); ?></p>
			<div style="display:flex;gap:16px;flex-wrap:wrap">
				<div class="postbox" style="padding:18px;min-width:180px"><strong><?php echo esc_html( $players ); ?></strong><br><?php esc_html_e( 'Players', 'neo-kids-games' ); ?></div>
				<div class="postbox" style="padding:18px;min-width:180px"><strong><?php echo esc_html( $sessions ); ?></strong><br><?php esc_html_e( 'Sessions', 'neo-kids-games' ); ?></div>
				<div class="postbox" style="padding:18px;min-width:180px"><strong><?php echo esc_html( $completed ); ?></strong><br><?php esc_html_e( 'Completed', 'neo-kids-games' ); ?></div>
			</div>
			<h2><?php esc_html_e( 'Embedding', 'neo-kids-games' ); ?></h2>
			<p><code>[nkg_game type="memory" difficulty="easy"]</code></p>
			<p><code>[nkg_player_profile]</code></p>
		</div>
		<?php
	}

	public static function games() {
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Game Library', 'neo-kids-games' ); ?></h1>
			<table class="widefat striped">
				<thead><tr><th><?php esc_html_e( 'Game', 'neo-kids-games' ); ?></th><th><?php esc_html_e( 'Description', 'neo-kids-games' ); ?></th><th><?php esc_html_e( 'Difficulties', 'neo-kids-games' ); ?></th></tr></thead>
				<tbody>
				<?php foreach ( NKG_Game_Registry::all() as $game ) : ?>
					<tr>
						<td><strong><?php echo esc_html( $game->get_name() ); ?></strong><br><code><?php echo esc_html( $game->get_key() ); ?></code></td>
						<td><?php echo esc_html( $game->get_description() ); ?></td>
						<td><?php echo esc_html( implode( ', ', $game->get_difficulties() ) ); ?></td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
		</div>
		<?php
	}

	public static function players() {
		global $wpdb;
		$t = NKG_Database::tables();
		$rows = $wpdb->get_results( "SELECT id, nickname, level, xp, created_at FROM {$t['players']} ORDER BY id DESC LIMIT 100", ARRAY_A );
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Players', 'neo-kids-games' ); ?></h1>
			<table class="widefat striped">
				<thead><tr><th>ID</th><th><?php esc_html_e( 'Nickname', 'neo-kids-games' ); ?></th><th><?php esc_html_e( 'Level', 'neo-kids-games' ); ?></th><th>XP</th><th><?php esc_html_e( 'Created', 'neo-kids-games' ); ?></th></tr></thead>
				<tbody>
				<?php foreach ( $rows as $row ) : ?>
					<tr>
						<td><?php echo esc_html( $row['id'] ); ?></td>
						<td><?php echo esc_html( $row['nickname'] ); ?></td>
						<td><?php echo esc_html( $row['level'] ); ?></td>
						<td><?php echo esc_html( $row['xp'] ); ?></td>
						<td><?php echo esc_html( $row['created_at'] ); ?></td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
		</div>
		<?php
	}

	public static function settings_page() {
		$options = get_option( 'nkg_settings', array( 'sound' => 1, 'default_difficulty' => 'easy' ) );
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Kids Games Settings', 'neo-kids-games' ); ?></h1>
			<form method="post" action="options.php">
				<?php settings_fields( 'nkg_settings' ); ?>
				<table class="form-table">
					<tr><th><?php esc_html_e( 'Sound effects', 'neo-kids-games' ); ?></th><td><label><input type="checkbox" name="nkg_settings[sound]" value="1" <?php checked( ! empty( $options['sound'] ) ); ?>> <?php esc_html_e( 'Enable sound effects where supported.', 'neo-kids-games' ); ?></label></td></tr>
					<tr><th><?php esc_html_e( 'Default difficulty', 'neo-kids-games' ); ?></th><td><select name="nkg_settings[default_difficulty]"><option value="easy" <?php selected( $options['default_difficulty'] ?? 'easy', 'easy' ); ?>>Easy</option><option value="medium" <?php selected( $options['default_difficulty'] ?? '', 'medium' ); ?>>Medium</option><option value="hard" <?php selected( $options['default_difficulty'] ?? '', 'hard' ); ?>>Hard</option></select></td></tr>
				</table>
				<?php submit_button(); ?>
			</form>
		</div>
		<?php
	}
}
