(function () {
	'use strict';

	const state = {
		id: Number(localStorage.getItem('nkg_player_id') || 0),
		token: localStorage.getItem('nkg_player_token') || ''
	};

	function headers() {
		return {
			'Content-Type': 'application/json',
			'X-WP-Nonce': NKG_DATA.nonce,
			'X-NKG-Player-Token': state.token
		};
	}

	function request(url, options) {
		return fetch(NKG_DATA.restUrl + url, options).then(function (response) {
			if (!response.ok) {
				return response.json().then(function (data) {
					throw new Error(data.message || 'Request failed');
				});
			}
			return response.json();
		});
	}

	function createOrLoadPlayer(nickname) {
		return request('players', {
			method: 'POST',
			headers: headers(),
			body: JSON.stringify({ nickname: nickname, token: state.token })
		}).then(function (data) {
			state.id = Number(data.id);
			state.token = data.token;
			localStorage.setItem('nkg_player_id', String(state.id));
			localStorage.setItem('nkg_player_token', state.token);
			return data;
		});
	}

	function startSession(gameKey, difficulty) {
		return request('sessions/start', {
			method: 'POST',
			headers: headers(),
			body: JSON.stringify({ player_id: state.id, game_key: gameKey, difficulty: difficulty, token: state.token })
		});
	}

	function finishSession(sessionId, payload) {
		payload.player_id = state.id;
		payload.token = state.token;
		return request('sessions/' + sessionId + '/finish', {
			method: 'POST',
			headers: headers(),
			body: JSON.stringify(payload)
		});
	}

	function score(root, value) {
		root.querySelector('.nkg-game__score').textContent = String(value);
	}

	function renderMemory(root, sessionId, difficulty) {
		const board = root.querySelector('.nkg-board');
		const result = root.querySelector('.nkg-result');
		const pairs = difficulty === 'hard' ? 8 : difficulty === 'medium' ? 6 : 4;
		const icons = ['🐶','🐱','🐸','🦁','🐼','🐵','🐰','🦊'].slice(0, pairs);
		const deck = icons.concat(icons).sort(function () { return Math.random() - 0.5; });
		let first = null, locked = false, matches = 0, mistakes = 0;
		const started = Date.now();

		board.innerHTML = '';
		board.hidden = false;

		deck.forEach(function (icon) {
			const card = document.createElement('button');
			card.type = 'button';
			card.className = 'nkg-card';
			card.textContent = '?';
			card.dataset.icon = icon;

			card.addEventListener('click', function () {
				if (locked || card.classList.contains('is-open') || card.classList.contains('is-match')) return;
				card.classList.add('is-open');
				card.textContent = icon;

				if (!first) {
					first = card;
					return;
				}

				if (first.dataset.icon === card.dataset.icon) {
					first.classList.add('is-match');
					card.classList.add('is-match');
					matches++;
					score(root, Math.max(0, matches * 10 - mistakes));
					first = null;

					if (matches === pairs) {
						finishSession(sessionId, {
							completed: true,
							matches: matches,
							mistakes: mistakes,
							duration: Math.round((Date.now() - started) / 1000)
						}).then(function (data) {
							result.textContent = '🎉 Great job! +' + data.score + ' points';
							result.hidden = false;
							score(root, data.score);
							window.dispatchEvent(new CustomEvent('nkg:game-completed'));
						});
					}
				} else {
					mistakes++;
					locked = true;
					setTimeout(function () {
						first.classList.remove('is-open');
						card.classList.remove('is-open');
						first.textContent = '?';
						card.textContent = '?';
						first = null;
						locked = false;
						score(root, Math.max(0, matches * 10 - mistakes));
					}, 650);
				}
			});
			board.appendChild(card);
		});
	}

	function renderQuiz(root, sessionId, difficulty) {
		const board = root.querySelector('.nkg-board');
		const result = root.querySelector('.nkg-result');
		const base = [
			{ q: 'Which animal says “meow”?', a: ['🐶 Dog', '🐱 Cat', '🐮 Cow'], correct: 1 },
			{ q: 'Which one is a fruit?', a: ['🚗 Car', '🍎 Apple', '🏠 House'], correct: 1 },
			{ q: 'Which color is usually associated with grass?', a: ['🍃 Green', '🌊 Blue', '🍋 Yellow'], correct: 0 }
		];
		if (difficulty === 'medium' || difficulty === 'hard') base.push({ q: 'How many legs does a dog usually have?', a: ['2', '4', '6'], correct: 1 });
		if (difficulty === 'hard') base.push({ q: 'Which planet do we live on?', a: ['Mars', 'Earth', 'Jupiter'], correct: 1 });

		let index = 0, correct = 0;
		const started = Date.now();

		function showQuestion() {
			const item = base[index];
			board.innerHTML = '';
			const q = document.createElement('div');
			q.className = 'nkg-question';
			q.textContent = item.q;
			board.appendChild(q);

			item.a.forEach(function (answer, answerIndex) {
				const button = document.createElement('button');
				button.type = 'button';
				button.className = 'nkg-answer';
				button.textContent = answer;
				button.addEventListener('click', function () {
					if (answerIndex === item.correct) correct++;
					index++;

					if (index === base.length) {
						finishSession(sessionId, {
							completed: true,
							correct: correct,
							duration: Math.round((Date.now() - started) / 1000)
						}).then(function (data) {
							board.innerHTML = '';
							result.textContent = '🎉 Quiz complete! +' + data.score + ' points';
							result.hidden = false;
							score(root, data.score);
							window.dispatchEvent(new CustomEvent('nkg:game-completed'));
						});
					} else {
						showQuestion();
					}
				});
				board.appendChild(button);
			});
		}
		showQuestion();
	}

	function initGame(root) {
		const start = root.querySelector('.nkg-start');
		const input = root.querySelector('.nkg-player-name');
		const message = root.querySelector('.nkg-message');

		start.addEventListener('click', function () {
			const nickname = input.value.trim();
			if (!nickname) {
				message.textContent = 'Please enter a player name.';
				return;
			}

			start.disabled = true;
			message.textContent = 'Starting…';

			createOrLoadPlayer(nickname)
				.then(function () {
					return startSession(root.dataset.nkgGame, root.dataset.nkgDifficulty);
				})
				.then(function (data) {
					root.querySelector('.nkg-player-start').hidden = true;
					message.textContent = '';
					if (root.dataset.nkgGame === 'quiz') {
						renderQuiz(root, data.session_id, root.dataset.nkgDifficulty);
					} else {
						renderMemory(root, data.session_id, root.dataset.nkgDifficulty);
					}
				})
				.catch(function (error) {
					start.disabled = false;
					message.textContent = error.message || 'Something went wrong.';
				});
		});
	}

	function loadProfile(root) {
		if (!state.id || !state.token) return;

		request('players/' + state.id, {
			method: 'GET',
			headers: headers()
		}).then(function (data) {
			root.querySelector('.nkg-profile__empty').hidden = true;
			root.querySelector('.nkg-profile__content').hidden = false;
			root.querySelector('.nkg-profile__name').textContent = data.player.nickname;
			root.querySelector('.nkg-profile__level').textContent = 'Level ' + data.player.level;
			root.querySelector('.nkg-xp').textContent = data.player.xp;
			root.querySelector('.nkg-played').textContent = data.stats.games_played;
			root.querySelector('.nkg-completed').textContent = data.stats.completed_games;
			root.querySelector('.nkg-score').textContent = data.stats.total_score;

			const badges = root.querySelector('.nkg-badges');
			badges.innerHTML = '';
			(data.badges || []).forEach(function (badge) {
				const item = document.createElement('span');
				item.className = 'nkg-badge';
				item.textContent = '🏆 ' + badge.title;
				badges.appendChild(item);
			});

			const recent = root.querySelector('.nkg-recent');
			recent.innerHTML = '';
			(data.recent || []).forEach(function (item) {
				const row = document.createElement('div');
				row.className = 'nkg-recent__row';
				row.textContent = item.game_key + ' — ' + item.score + ' points';
				recent.appendChild(row);
			});
		}).catch(function () {});
	}

	document.addEventListener('DOMContentLoaded', function () {
		document.querySelectorAll('[data-nkg-game]').forEach(initGame);
		document.querySelectorAll('[data-nkg-profile]').forEach(loadProfile);
		window.addEventListener('nkg:game-completed', function () {
			document.querySelectorAll('[data-nkg-profile]').forEach(loadProfile);
		});
	});
})();
