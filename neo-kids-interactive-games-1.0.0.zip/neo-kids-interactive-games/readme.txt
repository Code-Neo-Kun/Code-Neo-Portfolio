=== Neo Kids Interactive Games ===
Contributors: neo
Tags: kids, games, education, children, interactive, gutenberg, elementor
Requires at least: 6.3
Requires PHP: 8.0
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Tested up to: 6.9

A lightweight, extensible WordPress game engine for children's mini-games with custom player profiles, progress, XP, achievements, Gutenberg, Elementor, and shortcode support.

== Description ==

Neo Kids Interactive Games provides a reusable game engine rather than a collection of unrelated games. The first release includes Memory Match and Quick Quiz.

Player records, game sessions, progress, achievements, and game definitions are stored in dedicated custom database tables.

Guest players receive a random local player token stored by the browser. The raw token is not stored in the database; only a salted hash is stored.

== Features ==

* Custom database tables for plugin data.
* Individual player profiles.
* Guest player identity with persistent browser token.
* WordPress user association when a logged-in user creates a profile.
* Game Registry and Game Interface architecture.
* Memory Match game.
* Quick Quiz game.
* Difficulty levels.
* Server-side result validation.
* Game sessions and progress tracking.
* XP and level progression.
* Achievement/badge foundation.
* Gutenberg block.
* Elementor widget when Elementor is active.
* Shortcodes.
* WordPress Privacy exporter and eraser integration.
* No external tracking or executable remote code.
* GPL-2.0-or-later.

== Shortcodes ==

[nkg_game type="memory" difficulty="easy"]

[nkg_game type="quiz" difficulty="medium"]

[nkg_player_profile]

== Database ==

The plugin creates:

* wp_nkg_players
* wp_nkg_games
* wp_nkg_sessions
* wp_nkg_progress
* wp_nkg_achievements
* wp_nkg_player_badges

The wp_ prefix is replaced by the site's actual WordPress database prefix.

== Privacy ==

The plugin stores player nickname, a hashed guest token, optional WordPress user association, game sessions, progress, scores, XP, levels, and achievements.

Site owners should provide appropriate privacy information for their site and should only collect information necessary for their use case. WordPress privacy exporter/eraser hooks are included for profiles associated with WordPress user accounts.

Guest profiles are browser-local identities. Clearing browser storage or changing browsers will not automatically recover a guest profile.

== Compatibility ==

Elementor is optional. Gutenberg support is included through the WordPress Block API. The plugin uses WordPress APIs and does not require a page builder.

== Development ==

Author: Neo
Author URL: https://code-neo-portfolio.vercel.app/

The plugin source is intentionally human-readable. It does not download or execute remote code.

== Installation ==

1. Upload the ZIP through Plugins > Add New > Upload Plugin.
2. Activate the plugin.
3. Open Kids Games in wp-admin.
4. Add a Gutenberg block, Elementor widget, or shortcode.

== Changelog ==

= 1.0.0 =
* Rebuilt around a game-engine architecture.
* Added custom player, game, session, progress, achievement, and badge tables.
* Added persistent guest player profiles.
* Added server-side game result validation.
* Added XP and level progression.
* Added achievements.
* Added privacy exporter and eraser hooks.
* Added Gutenberg and Elementor integrations.
* Added Memory Match and Quick Quiz reference games.
